# Fase 4 — Evidencia del uso de IA generativa

Este apartado recoge cómo se ha usado la IA generativa en la Práctica 2. Las filas de Claude Code corresponden a la conversación real con la que se generaron la especificación y el prototipo. Las filas marcadas con **[PENDIENTE]** deben rellenarlas los miembros del grupo con lo que hagan en Stitch, Figma o Copilot.

## 1. Tabla de prompts y resultados

| # | Herramienta | Prompt exacto usado | Resultado obtenido (fragmento) | Qué modificamos nosotros y por qué |
|---|---|---|---|---|
| 1 | Claude Code (extensión de VS Code) | «Actúa como diseñador/a de interacción especializado en accesibilidad y como desarrollador/a front-end. […] FASE 0 — Revisión de coherencia de la P1 (hazla primero y entrégamela como lista). Detecta y propone la corrección de las incoherencias. Como mínimo: 1. Tarea 6: el evento se reconoce PRINCIPALMENTE por el patrón de vibración […]» | Lista de 24 incoherencias en `fase0.md`, con el texto de sustitución. Ejemplo: *«9.5.2 […] el **móvil** avisa al momento con su propia vibración (patrón de aviso técnico), un mensaje de voz y un texto en pantalla […]. El aviso nunca depende del accesorio háptico.»* | Indicamos que las correcciones fueran en un documento aparte y no en la memoria de la P1 («si debes modificar o añadir documentacion hazlo en un documento a parte no en la memoria de la practica 1»). **[PENDIENTE: qué correcciones trasladamos finalmente a la memoria]** |
| 2 | Claude Code | «SISTEMA DE PATRONES […] Deben ser claramente distinguibles en ritmo y duración, no solo en intensidad, porque Manuel tiene menos sensibilidad táctil. Propuesta de partida (puedes justificar ajustes): Gol: [600,150,600,150,600] · Gol anulado: [600,150,600] […]» | La IA detectó que nuestro patrón de gol anulado era el principio exacto del de gol y propuso otro: `golAnulado: { nombre: 'Gol anulado', ms: [1200, 200, 150, 100, 150], ritmo: 'muy largo, corto, corto' }` | Aceptamos el cambio y la opción «Pulsos reforzados» («Y la tercera si»). Decidimos nosotros que «Seguir solo con el móvil» apareciera como beta: «puedes poner en desarrollo beta o algo parecido indicando que no esta hecha al 100%». |
| 3 | Claude Code | «FASE 1 — Escenarios enriquecidos (uno por cada tarea T1–T10). Para cada tarea, redacta un escenario narrativo realista (150–250 palabras) usando los perfiles de la P1 […] al menos un obstáculo o error y cómo lo resuelve la interfaz, y el criterio de éxito medible […]» | Diez escenarios en `fase1.md` y tabla de trazabilidad. Ejemplo de criterio: *«identifica el córner y el gol a la primera y solo por la vibración»*. | **[PENDIENTE: cambios de redacción hechos por el grupo]** |
| 4 | Claude Code | «FASE 2 — Especificación de pantallas y mockups. 1. Define un sistema visual mínimo: dos temas […] contraste mínimo 7:1 en texto, tipografía escalable (rem, con soporte para 200 %), objetivos táctiles ≥ 48×48 dp, estados comunicados con texto + icono […] 4. Para cada pantalla, escribe un PROMPT listo para pegar en Google Stitch […]» | `spec-pantallas.md`: 17 fichas de pantalla con orden de foco y etiquetas, mapa de navegación y un prompt de Stitch por pantalla. | Elegimos el nombre y los datos: «Football Vibration es el nombre», «equipos reales evidentemente». Decidimos generar primero el código y después los mockups. |
| 5 | Claude Code | «FASE 3 — Primer desarrollo funcional (código). Construye un prototipo web móvil en HTML + CSS + JavaScript vanilla, sin build, que se abra con index.html. […] Formulario funcional de perfil con validaciones (campos obligatorios, mensajes de error asociados con aria-describedby, foco al primer error, resumen antes de guardar), con persistencia en localStorage envuelta en try/catch. […]» | Carpeta `/prototipo`. Ver los fragmentos del apartado 2. | **[PENDIENTE: cambios manuales en el código, si los hay]** |
| 6 | Claude Code | «FASE 5 — Iteraciones y análisis heurístico. Iteración 1: evalúa los mockups y el prototipo inicial con: las 10 heurísticas de Nielsen […] Sé crítico: busca problemas reales, no rellenes. Iteración 2: aplica las correcciones al diseño y al código […]» | `fase5.md` y los cambios de código de la Iteración 2 (17 correcciones). | **[PENDIENTE: correcciones añadidas por el grupo tras el feedback]** |
| 7 | Google Stitch | **[PENDIENTE: prompt pegado; los prompts preparados están en `spec-pantallas.md`, apartado 3]** | **[PENDIENTE: captura del mockup generado]** | **[PENDIENTE: qué se ajustó a mano y por qué (p. ej. contraste, tamaño de botones, textos)]** |
| 8 | Figma (prototipado) | **[PENDIENTE]** | **[PENDIENTE: enlace público al prototipo navegable]** | **[PENDIENTE]** |
| 9 | GitHub Copilot / ChatGPT | **[PENDIENTE: prompt, si se usa]** | **[PENDIENTE: fragmento de código]** | **[PENDIENTE]** |

## 2. Fragmentos de código obtenidos

**Validación del formulario** (`prototipo/js/app.js`): campo obligatorio, error asociado y foco en el primer error.

```js
FV.validar = function (formulario) {
  var primero = null;
  formulario.querySelectorAll('fieldset[data-obligatorio]').forEach(function (grupo) {
    var valido = !!grupo.querySelector('input:checked');
    marcarGrupo(grupo, valido);
    if (!valido && !primero) primero = grupo.querySelector('input');
  });
  // Foco en el primer campo con error: el lector lee la opción y, por aria-describedby, el mensaje.
  if (primero) primero.focus();
  return !primero;
};
```

**Persistencia con `try/catch`** (`prototipo/js/almacen.js`):

```js
FV.guardarPrefs = function () {
  try {
    localStorage.setItem(CLAVE, JSON.stringify(FV.prefs));
    return true;
  } catch (e) {
    return false;
  }
};
```

**Vibración con comprobación de compatibilidad** (`prototipo/js/patrones.js`):

```js
/* Comprobación de compatibilidad: en iOS (Safari) navigator.vibrate no existe. */
FV.vibracionDisponible = typeof navigator !== 'undefined' && typeof navigator.vibrate === 'function';
...
if (origen === 'accesorio') {
  if (s.soloMovil) origen = 'movil';          // modo beta: los eventos vibran en el móvil
  else if (!conectado) return false;          // un accesorio desconectado no puede vibrar (R9.5.2)
}
```

**Reconexión sin avisos acumulados** (`prototipo/js/partido.js`):

```js
/* Sin internet los eventos no llegan: no vibran ni se narran.
   Al recuperar la conexión NO se reproducen (R9.5.3); solo se anuncia el marcador actual (D-07). */
if (!e.internet) return;
```

## 3. Reflexión

### Ventajas
- **Rapidez para pasar de requisitos a algo que se puede probar.** En una sesión se obtuvieron la revisión de la P1, los escenarios, la especificación y un prototipo navegable.
- **Coherencia entre documentos.** La IA trabajó siempre contra los mismos archivos (`patrones.md`, `spec-pantallas.md`), así que la memoria, las pantallas y el código usan los mismos nombres y textos.
- **Revisión crítica de nuestras propias propuestas.** Detectó que el patrón de gol anulado que propusimos se confundía con el de gol, y que `navigator.vibrate()` no permite regular la intensidad ni funciona en iPhone.
- **Verificación automática.** La IA escribió y ejecutó un recorrido con teclado de las diez tareas, que sirvió para encontrar errores que no se veían leyendo el código.

### Errores de la IA detectados
Todos estos errores estaban en el código generado y se encontraron al probarlo o al evaluarlo, no al generarlo:

1. **Recuadro de aviso vacío siempre visible.** Un `display: flex` anulaba el atributo `hidden`.
2. **La vista previa del perfil no aplicaba el tema** hasta guardar.
3. **El resumen no se podía continuar** si un evento lo interrumpía en la primera frase.
4. **Los controles rápidos se movían de sitio** cada vez que cambiaba el texto del último evento o aparecía el aviso de conexión. Contradecía el requisito de usarlos sin mirar (R9.2.2), aunque el requisito estaba en el prompt.
5. **El botón «atrás» de Android sacaba de la app**, porque la IA solo programó el botón «Volver» de la pantalla.
6. **Doble anuncio en el lector de pantalla:** el interruptor «Pulsos reforzados» decía el estado en el texto y otra vez con `aria-checked`.
7. **El aviso de «conexión recuperada» se cerraba solo a los 8 segundos**, sin dar tiempo a quien lee despacio.
8. **Las confirmaciones por voz esperaban a que acabase la narración**, así que la respuesta a un botón podía llegar con retraso.
9. **Contrastes calculados «a mano» en la especificación.** Eran aproximados y hubo que medirlos con la fórmula de WCAG (resultaron correctos).
10. **Dos falsos fallos en las pruebas automáticas**, debidos al propio guion de prueba y no a la app.

### Limitaciones
- **La IA no puede notar una vibración ni oír la voz.** Comprobó los patrones por el registro del simulador. Que se distingan de verdad solo se sabrá con personas (P3).
- **No se ha probado con VoiceOver ni TalkBack.** La IA revisa el marcado y el orden de foco, pero no sabe cómo suena una pantalla con un lector real.
- **Accesibilidad que no aplicó por defecto.** Lo que estaba escrito en el prompt (contraste, tamaños, `aria-live`, foco) lo aplicó. Lo que no estaba escrito, o exigía pensar en el uso real, falló: la estabilidad de la posición de los controles, el botón «atrás» del sistema, los tiempos de lectura y la cola de voz. Una lista de requisitos de accesibilidad no sustituye a la evaluación.
- **Datos inventados con apariencia real.** Las alineaciones y los eventos de los partidos son inventados aunque usen nombres reales. Están marcados como simulados en el JSON y en el README.
- **No inventa lo que no sabe, si se le pide.** Los resultados de la encuesta y el feedback de usuarios se dejaron como pendientes porque el prompt lo exigía; sin esa instrucción, el riesgo de que los rellenase existía.
- **[PENDIENTE: limitaciones observadas por el grupo al usar Stitch, Figma o Copilot]**
