# Fase 3 — Primer desarrollo funcional

Código en `/prototipo` (HTML, CSS y JavaScript sin dependencias; unos 110 KB en total). Instrucciones en `prototipo/README.md`.

## Qué incluye

| Requisito del encargo | Dónde está |
|---|---|
| Formulario de perfil con validación, error asociado (`aria-describedby`), foco en el primer error y resumen antes de guardar | `js/pantallas-perfil.js` (P02, P03) y `FV.validar` en `js/app.js` |
| Persistencia en `localStorage` con `try/catch` | `js/almacen.js` |
| Partido con datos simulados: balón, goles, faltas, córners, penalti, gol anulado, descanso con cambio de campo, corte de conexión y recuperación | `js/partido.js` y `data/partido-simulado.json` |
| Controles rápidos con confirmación por voz y texto | `js/pantallas-partido.js` (P11) |
| Narración con `speechSynthesis`, región `aria-live="polite"` y `role="alert"` solo para fallos | `js/voz.js`, `index.html` |
| Vibración con comprobación de compatibilidad | `js/patrones.js` |
| Dos temas, `prefers-reduced-motion` y `prefers-contrast` | `css/estilos.css`, arranque en `js/app.js` |
| Simulador del accesorio | `js/simulador.js` |
| HTML semántico, un `h1` por pantalla, gestión del foco, teclado, `lang="es"` | `index.html`, `js/app.js` |

## Verificación realizada

Recorrido automático **solo con teclado** (Tab, Enter, Espacio, flechas, Escape) en Chromium, con ventana de 412 × 915 px. Cubre T1–T10, el modo beta y el cambio de tema.

- **119 comprobaciones superadas.** Queda un caso que no se cumple (ver limitaciones).
- **Consola:** sin errores ni avisos, tanto con servidor local como abriendo `index.html` con doble clic.
- **Foco:** al entrar en cada pantalla va al título (o al mensaje de estado en Conectar accesorio). Los diálogos reciben el foco y se cierran con Escape. El aviso de conexión no mueve el foco.
- **Objetivos táctiles:** ningún botón ni opción mide menos de 48 × 48 px en ninguna pantalla.
- **Zoom:** sin desplazamiento horizontal al 200 % (206 px de ancho) ni con texto «Muy grande» a 320 px.
- **Preferencias del sistema:** con `prefers-contrast: more` y sin perfil guardado arranca en alto contraste; con `prefers-reduced-motion` la animación de «Buscando» se detiene.

### Contraste medido (fórmula de WCAG)

| Par | Tema estándar | Tema alto contraste |
|---|---|---|
| Texto sobre fondo | 17,40 : 1 | 21,00 : 1 |
| Texto del botón principal | 10,71 : 1 | 14,67 : 1 |
| Botón secundario y bordes | 10,71 : 1 | 21,00 : 1 |
| Mensajes de error | 8,15 : 1 | 9,20 : 1 |
| Mensajes de estado correcto | 8,35 : 1 | 16,25 : 1 |

Todos superan 7 : 1.

### Comportamientos clave comprobados

- La validación del cuestionario muestra el error, marca el grupo como no válido y lleva el foco a la primera opción. «Volver» conserva las respuestas.
- La palabra «conectado» no aparece hasta que el accesorio lo está. El error de conexión no usa tecnicismos.
- Con «Pulsos reforzados», el gol se emite como `[900,150,900,150,900]` y la falta como `[225,100,225]`.
- Con las vibraciones en pausa, el córner no vibra y se avisa: «Córner para el Atlético. Vibraciones en pausa.»
- La repetición empieza por «Repetición:». Sin eventos responde «Aún no hay ningún evento.»
- En la segunda parte se anuncia: «Tu equipo ataca ahora hacia la izquierda.»
- Al perder internet, el aviso técnico se emite en el móvil y en el accesorio. Si se desconecta el accesorio, solo en el móvil.
- El gol que ocurre durante el corte no vibra. Al reconectar solo hay una confirmación y el mensaje «Conexión recuperada. Marcador: Atlético 1, Betis 1, minuto 72.»
- El resumen empieza por «Resumen», se muestra en pantalla y no vibra. Un evento lo interrumpe con «En directo:» y el botón pasa a «Continuar resumen».
- «Finalizar sesión» con el partido en juego pone el foco en «Seguir viendo el partido».

## Errores encontrados y corregidos durante la verificación

1. El aviso de conexión se veía como un recuadro vacío cuando debía estar oculto (el `display: flex` anulaba el atributo `hidden`).
2. El perfil propuesto no mostraba la vista previa del tema hasta guardar.
3. Si un evento interrumpía el resumen durante la primera frase, el botón no pasaba a «Continuar resumen».
4. Las confirmaciones antiguas se quedaban en pantalla al cambiar de pantalla.
5. Abrir con doble clic dejaba dos errores en la consola por el intento de leer el JSON.

## Limitaciones y pendientes

- **No se ha probado con VoiceOver ni TalkBack reales**, ni en un móvil físico. La vibración y la voz se han comprobado por el registro y por el código, no notándolas.
- Con texto «Muy grande» **y** zoom del 200 % a la vez en 412 px hay desplazamiento horizontal.
- No se ha hecho todavía la revisión de rendimiento ni la revisión de código formal. El prototipo no tiene dependencias, imágenes ni peticiones de red aparte del JSON.
- Las capturas de `capturas/` son del prototipo funcional, no de los mockups de Stitch.

## Diferencias respecto a `spec-pantallas.md`

- El título de Partido es «Partido: Atlético contra Betis». El marcador va en un párrafo aparte, para que no quede desactualizado en el título.
- Los botones de pausa cambian de texto («Pausar» ↔ «Reanudar») y no usan `aria-pressed`: las dos cosas a la vez se leerían de forma contradictoria.
- La búsqueda del accesorio tarda 2,5 s en el prototipo, no 10 s.
- Se añade una línea de subtítulos con el texto de la narración.
