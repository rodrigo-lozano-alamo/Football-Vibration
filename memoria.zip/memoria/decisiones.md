# Registro de decisiones de diseño (P2)

Formato: decisión · alternativa descartada y motivo · requisito o heurística relacionada.

| Id | Fecha | Decisión | Alternativa descartada y motivo | Relación |
|---|---|---|---|---|
| D-01 | 2026-11-14 | Se ofrece **«Seguir solo con el móvil»**: los eventos vibran en el móvil y se mantiene la narración, sin posición táctil del balón. En esta entrega se marca como **«Beta · en desarrollo»**. | Exigir siempre el accesorio. Se descarta porque deja fuera a Lucía, para quien T2 solo es «relevante». | R9.3.1, R9.4.2, diseño universal (flexibilidad) |
| D-02 | 2026-11-14 | Gol anulado → `[1200,200,150,100,150]`. | `[600,150,600]`: es el principio del patrón de gol y obliga a notar la ausencia de un pulso. | R9.3.2, perfil de Manuel |
| D-03 | 2026-11-14 | La intensidad se simula con la duración. Se añade la opción **«Pulsos reforzados»** (pulsos ×1,5). | Un control de intensidad real: `navigator.vibrate()` no lo admite. | R9.4.1, R9.3.2 |
| D-04 | 2026-11-14 | El objetivo de **< 2 min** se aplica al **uso habitual** (abrir → conectar → partido → iniciar). El primer acceso se mide aparte. | Incluir el primer acceso: no es realista y contradice el §3 de la P1. | R9.2.1 |
| D-05 | 2026-11-14 | «Pausar vibraciones», «Pausar narración», volumen, nivel de narración y «Repetir último evento» están **siempre visibles** en la pantalla Partido, sin menú intermedio. | Un panel desplegable de «Controles rápidos»: supone dos toques e incumple el criterio de Lucía. | R9.2.2, R9.2.4, R9.6.1 |
| D-06 | 2026-11-14 | El entorno se cambia en «Ajustes del partido», no en los controles rápidos. | Añadirlo a los controles rápidos: más opciones durante el juego, mal para Manuel. | R9.2.4 |
| D-07 | 2026-11-14 | Al reconectar no se reproducen los patrones atrasados, pero se anuncia **una vez** el estado actual (marcador y minuto). | Silencio total: el usuario podría perderse un gol ocurrido durante el corte. | R9.5.3 |
| D-09 | 2026-11-14 | Los mensajes de la interfaz van a regiones `aria-live` (los lee el lector de pantalla). La app solo los lee con su propia voz si el usuario contestó que **no usa lector**. | Leerlos siempre con la voz de la app: con VoiceOver o TalkBack activos se oirían dos voces a la vez. | R9.1.1, R9.3.1 |
| D-10 | 2026-11-14 | Intensidad y volumen se ajustan con botones − y +, no con deslizadores. | Deslizadores: difíciles con lector de pantalla y con poca precisión (Manuel). | R9.1.1, R9.2.2 |
| D-11 | 2026-11-14 | El aviso de conexión es un bloque dentro de Partido (`role="alert"`), no una pantalla aparte, y no mueve el foco. | Pantalla o diálogo modal: saca al usuario del partido y es un cambio de pantalla inesperado. | R9.2.3, R9.5.2 |
| D-12 | 2026-11-14 | La práctica incluye 5 patrones (se añade el gol anulado). | Mantener 4: el gol anulado es el patrón menos intuitivo y quedaría sin practicar. | R9.3.3 |
| D-13 | 2026-11-14 | Los botones de pausa cambian de texto («Pausar» ↔ «Reanudar») y **no** llevan `aria-pressed`. | Texto cambiante más `aria-pressed`: el lector diría «Reanudar narración, pulsado», que es contradictorio. | Nielsen 1 (visibilidad del estado), R9.1.1 |
| D-14 | 2026-11-14 | La narración se muestra además como **subtítulo** visible, sin ser región viva. | Región viva: el lector de pantalla repetiría lo que ya dice la voz. Sin texto: quien tiene el volumen bajo (Lucía en el bar) no se entera. | R9.6.1, R9.1.2 |
| D-15 | 2026-11-14 | El marcador y el minuto **no** se anuncian en cada cambio; solo se actualiza el texto. | Región viva en el marcador: interrumpiría al usuario cada minuto. | R9.3.1 (sin sobrecarga) |
| D-16 | 2026-11-14 | Prototipo sin compilación ni módulos, con una copia del JSON en `datos-respaldo.js`. | Módulos ES y `fetch` únicamente: no funcionan al abrir `index.html` con doble clic. | Requisito de entrega de la Fase 3 |
| D-17 | 2026-11-14 | **Iteración 2.** En Partido, la información de tamaño variable (último evento, estado de datos, pausas) y el aviso de conexión van **debajo** de los controles rápidos. | Mantenerlos arriba (más visibles): desplazaban los controles en cada evento y rompían el uso sin mirar. | Nielsen 4 y 6, R9.2.2 |
| D-18 | 2026-11-14 | **Iteración 2.** El botón «atrás» del sistema equivale a «Volver» y en Partido pide confirmación. | Ignorarlo: sacaba de la app y se perdía el partido. | Nielsen 3, R9.2.3 |
| D-19 | 2026-11-14 | **Iteración 2.** La primera vez, tras emparejar, la acción principal es practicar los patrones; se puede saltar. | Obligar a practicar: quita control al usuario. No recomendarlo: se llega al partido sin conocer el canal principal. | Nielsen 10, R9.3.3 |
| D-20 | 2026-11-14 | **Iteración 2.** Las confirmaciones por voz interrumpen la narración en curso. | Ponerlas en cola: la respuesta a una acción llegaba tarde. | Nielsen 1, R9.2.3 |
| D-21 | 2026-11-14 | **Iteración 2.** Los avisos de conexión no se cierran solos. | Cierre a los 8 s: quien lee despacio no llega a leerlos (WCAG 2.2.1). | R9.5.3 |
| D-08 | 2026-11-14 | Un evento se repite reproduciendo **el patrón y la narración**, que empieza por «Repetición:». | Repetir solo la narración: no sirve para resolver dudas sobre el patrón (T6). | R9.5.4 |
