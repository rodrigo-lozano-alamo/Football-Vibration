# Fase 2 — Especificación de pantallas y mockups

Referencia única para los mockups (Stitch/Figma) y para el código de `/prototipo`. Si algo cambia, se cambia primero aquí.
Documentos relacionados: `fase1.md` (escenarios), `patrones.md` (vibraciones), `decisiones.md` (decisiones D-xx).

## 0. Supuestos

1. El prototipo funcional es una **web móvil** (HTML, CSS y JavaScript sin framework ni compilación), pensada para Chrome en Android. Se ve también en escritorio dentro de un marco de móvil.
2. La vibración usa `navigator.vibrate()`. En iPhone no existe: allí solo se ve el registro del simulador.
3. La narración del partido usa la síntesis de voz del navegador (`speechSynthesis`). Los mensajes de la interfaz se envían a regiones `aria-live`, para que los lea el lector de pantalla. Si el usuario contestó que **no usa lector**, la app los lee además con su propia voz (D-09).
4. Los datos del partido salen de un JSON local con una línea de tiempo acelerada.
5. La práctica tiene **5 patrones** (se añade el gol anulado), así que el resultado es «X de 5 aciertos», no «3 de 4».
6. En los mockups se entregan los dos temas de las pantallas clave (Inicio, Partido, Conectar accesorio y Sesión finalizada) y el resto solo en el tema de alto contraste.

## 1. Sistema visual mínimo

Si la estética choca con la accesibilidad, gana la accesibilidad.

### 1.1 Temas

| Token | Tema estándar (perfil ceguera total) | Tema alto contraste (perfil baja visión) |
|---|---|---|
| Fondo | `#FFFFFF` | `#000000` |
| Texto | `#1A1A1A` (≈17:1) | `#FFFFFF` (21:1) |
| Acción principal (fondo del botón) | `#0A3D7A`, texto blanco (≈10,7:1) | `#FFD400`, texto negro (≈14,7:1) |
| Acción secundaria | borde 2 px `#0A3D7A`, texto `#0A3D7A` | borde 3 px `#FFFFFF`, texto `#FFFFFF` |
| Error | `#9B1C1C` (≈8:1) | `#FF8A80` (≈9:1) |
| Correcto | `#0F5A2A` (≈8:1) | `#7CFC9A` (≈15:1) |
| Foco | contorno 3 px `#0A3D7A` + separación 2 px | contorno 4 px `#00E5FF` + separación 2 px |

- El tema estándar existe porque un acompañante puede mirar la pantalla y porque Andrés puede enseñar el móvil. Cumple también 7:1 en texto.
- Las relaciones de contraste son calculadas a mano. **Se verificarán con una herramienta en la Fase 3** y se corregirá el color si alguna baja de 7:1.
- Los dos temas se pueden cambiar en Configuración. La app respeta también `prefers-contrast` y `prefers-color-scheme` como valor inicial.

### 1.2 Tipografía
- Fuente: **Atkinson Hyperlegible** (diseñada para baja visión), con `system-ui` como alternativa.
- Tamaños en `rem`: texto 1,125; botones 1,25; título de pantalla (h1) 1,75; marcador 2,5. Interlineado 1,5.
- Tamaño de texto de la app: Normal / Grande (×1,25) / Muy grande (×1,5), además del zoom del sistema.
- **Soporte del 200 %:** una sola columna, sin alturas fijas, sin texto truncado ni puntos suspensivos. Los botones crecen en alto y el texto pasa a varias líneas. Nunca hay desplazamiento horizontal.

### 1.3 Controles
- Objetivo táctil mínimo **48×48 px**. Botones principales: ancho completo y 56 px de alto como mínimo. Separación mínima entre controles: 12 px.
- **Máximo 3–4 acciones principales por pantalla.** Excepciones justificadas: Partido (controles rápidos fijos, D-05) y Configuración (lista de apartados).
- **Posiciones fijas:** «Volver» siempre arriba a la izquierda; «Estado» siempre arriba a la derecha. Inicio y Partido no tienen «Volver» (son pantallas raíz) y ese hueco queda vacío. La acción principal va siempre la última, abajo, a ancho completo.
- **Estados con texto e icono, nunca solo con color:** ✓ «Conectado», ⚠ «Sin conexión», ⏸ «En pausa», ● «Seleccionado». Los iconos son decorativos (`aria-hidden`); el texto lleva la información.
- Los botones de pausa cambian de texto («Pausar narración» ↔ «Reanudar narración») y usan `aria-pressed`.

### 1.4 Movimiento y foco
- Sin animaciones decorativas. Los cambios de pantalla son inmediatos. La única animación es el indicador «Buscando…», que se desactiva con `prefers-reduced-motion` y siempre lleva texto.
- Al cambiar de pantalla, el foco va al **título (h1)**, que el lector lee como «Nombre de la pantalla».
- Dos regiones de avisos en todas las pantallas: `aria-live="polite"` para confirmaciones y `role="alert"` para fallos de conexión.
- Cada pantalla tiene `<title>` propio: «Partido · Football Vibration».

## 2. Pantallas

Formato de cada ficha: objetivo · tareas · contenido por orden de jerarquía · **orden de foco con la etiqueta exacta que lee el lector** · estados y mensajes · prompt de Stitch.
En el orden de foco, `[b]` = botón, `[r]` = opción de un grupo de selección única, `[t]` = texto, `[h1]` = título.

### P01 · Bienvenida
- **Objetivo:** explicar en una frase qué hace la app y empezar el cuestionario. **Tareas:** T1.
- **Contenido:** nombre de la app · frase de bienvenida · botón principal.
- **Foco:**
  1. `[h1]` «Bienvenida a Football Vibration»
  2. `[t]` «Vamos a adaptar la app a tu forma de ver. Son tres preguntas y tardarás menos de un minuto.»
  3. `[b]` «Empezar»
- **Estados:** solo normal. Si ya hay un perfil guardado, esta pantalla no aparece y se abre Inicio.

### P02 · Cuestionario inicial (una pregunta por pantalla)
- **Objetivo:** recoger las tres respuestas que determinan el perfil. **Tareas:** T1. **Es el formulario real con validación del prototipo.**
- **Contenido:** indicador de paso · pregunta · opciones · «Siguiente».
- **Preguntas y opciones:**
  1. «¿Cuál es tu grado de visión?» → «No veo nada» / «Veo con dificultad» / «Otra situación»
  2. «¿Dónde sueles seguir los partidos?» → «En el estadio» / «En casa» / «En un bar» / «En varios sitios»
  3. «¿Usas lector de pantalla, como VoiceOver o TalkBack?» → «Sí, siempre» / «A veces» / «No»
- **Foco:**
  1. `[b]` «Volver» (en el paso 1 vuelve a Bienvenida; en los demás, al paso anterior con la respuesta conservada)
  2. `[h1]` «Paso 1 de 3. ¿Cuál es tu grado de visión?»
  3. `[r]` «No veo nada, opción 1 de 3» … (grupo con `fieldset` y `legend`)
  4. `[b]` «Siguiente»
- **Estados:**
  - Error (pulsar «Siguiente» sin elegir): el foco va al mensaje «⚠ Elige una opción para continuar», que queda asociado al grupo (`aria-describedby`, `aria-invalid`).
  - Éxito: pasa al siguiente paso. No hay avance automático al elegir.

### P03 · Perfil propuesto
- **Objetivo:** revisar el resumen, aceptar el perfil o personalizarlo, y guardar. **Tareas:** T1.
- **Contenido:** nombre del perfil propuesto · resumen de respuestas · qué cambia en la app · acciones.
- **Foco:**
  1. `[b]` «Volver» (al paso 3)
  2. `[h1]` «Tu perfil propuesto: baja visión»
  3. `[t]` «Tus respuestas: veo con dificultad; en un bar; lector de pantalla a veces.»
  4. `[t]` «La app usará alto contraste, letra grande, narración normal y vibración para los eventos.»
  5. `[b]` «Aceptar y guardar»
  6. `[b]` «Personalizar»
- **Personalizar** (misma pantalla, ampliada): tema (Estándar / Alto contraste), tamaño de texto (Normal / Grande / Muy grande), voz de la app (Activada / Desactivada), y «Guardar preferencias».
- **Estados:** éxito → vibración de confirmación + «Preferencias guardadas» y pasa a Inicio.

### P04 · Inicio
- **Objetivo:** punto de partida de cada uso; muestra el estado del accesorio y el siguiente paso. **Tareas:** T2, T4, T9.
- **Contenido:** estado del accesorio · acción principal (cambia según el estado) · acciones secundarias.
- **Foco:**
  1. `[b]` «Estado del sistema»
  2. `[h1]` «Inicio»
  3. `[t]` «Accesorio sin conectar» o «✓ Accesorio conectado. Batería al 90 %»
  4. `[b]` «Conectar accesorio» (si está conectado, este botón pasa a ser «Elegir partido» y es el principal)
  5. `[b]` «Seguir solo con el móvil, beta, función en desarrollo»
  6. `[b]` «Configuración»
- **Estados:** sin conectar / conectado. Con el accesorio conectado, «Elegir partido» ocupa el primer lugar.
- **Beta:** al pulsar «Seguir solo con el móvil» se muestra el aviso «Función en desarrollo. Notarás los eventos en el móvil. La posición del balón necesita el accesorio.» con «Continuar» y «Volver».

### P05 · Conectar accesorio
- **Objetivo:** emparejar (primera vez) o conectar (usos siguientes) sin tecnicismos. **Tareas:** T2.
- **Estados y foco** (el h1 es siempre «Conectar accesorio»; «Volver» siempre primero):

| Estado | Lo que lee el lector, en orden | Acciones |
|---|---|---|
| Buscando | «Buscando tu accesorio. Enciéndelo y déjalo cerca del móvil.» | «Cancelar» |
| Lista (solo la primera vez) | «He encontrado 2 accesorios. Elige el tuyo.» · «Accesorio Táctil 4F21» · «Accesorio Táctil 9A03» | uno por botón |
| Vibración de prueba (solo la primera vez) | «Tu accesorio acaba de vibrar. ¿La has notado?» | «Sí, la he notado» · «No la he notado» · «Repetir vibración» |
| Conectado | «✓ Accesorio conectado. Batería al 90 %.» + vibración de confirmación | «Usar mis ajustes y elegir partido» · «Ajustar vibración y narración» |
| Error: no encontrado | «⚠ No encuentro tu accesorio. Comprueba que está encendido y cerca del móvil.» | «Reintentar» · «Volver» |
| Error: Bluetooth apagado | «⚠ El móvil no puede buscar accesorios. Activa el Bluetooth en los ajustes del móvil.» | «Reintentar» · «Volver» |
| «No la he notado» | «Sube la intensidad o prueba otra vez.» | «Repetir vibración» · «Subir intensidad» · «Volver» |

- **Regla:** la palabra «conectado» no aparece hasta el estado Conectado. En los usos siguientes se pasa de Buscando a Conectado sin lista ni prueba.
- Cada cambio de estado mueve el foco al mensaje del nuevo estado.

### P06 · Vibración y narración (calibración)
- **Objetivo:** ajustar los canales y entrar en la práctica. **Tareas:** T3.
- **Contenido:** intensidad · pulsos reforzados · volumen · nivel de narración · práctica · guardar.
- **Foco:**
  1. `[b]` «Volver»  2. `[b]` «Estado del sistema»
  3. `[h1]` «Vibración y narración»
  4. Intensidad: `[b]` «Bajar intensidad» · `[t]` «Intensidad 3 de 5» · `[b]` «Subir intensidad» · `[b]` «Probar vibración»
  5. `[b]` «Pulsos reforzados, desactivado» (interruptor; ayuda: «Vibraciones más largas, para notarlas mejor»)
  6. Volumen: `[b]` «Bajar volumen» · `[t]` «Volumen 3 de 5» · `[b]` «Subir volumen»
  7. Nivel de narración: `[r]` «Mínima: solo los eventos» / «Normal» / «Detallada»
  8. `[b]` «Practicar patrones»
  9. `[b]` «Guardar ajustes»
- Se usan botones − y + en lugar de deslizadores: son más fáciles con lector de pantalla y con poca precisión.
- **Estados:** cada cambio → vibración de confirmación + «Intensidad 4 de 5». Guardar → «Ajustes guardados».
- **Salir sin guardar:** diálogo «Tienes cambios sin guardar» con «Guardar», «Descartar» y «Seguir editando».

### P07 · Práctica de patrones
- **Objetivo:** aprender a distinguir los cinco patrones. **Tareas:** T3 (y prepara T6).
- **Contenido:** progreso · reproducir · cinco respuestas · resultado.
- **Foco (durante la práctica):**
  1. `[b]` «Volver»
  2. `[h1]` «Práctica. Patrón 2 de 5»
  3. `[b]` «Reproducir patrón»
  4. `[t]` «¿Qué evento es?»
  5. `[b]` «Gol» · «Gol anulado» · «Falta» · «Córner» · «Penalti»
- **Feedback por respuesta:** «✓ Correcto, era córner» o «✗ Era córner. Has elegido falta.» y botón «Siguiente».
- **Resultado:** `[h1]` «Resultado: 4 de 5 aciertos» · `[t]` «Has confundido falta y córner.» (si el fallo se repite: «Puedes activar Pulsos reforzados.») · `[b]` «Repetir los fallados» · `[b]` «Escuchar todos los patrones» · `[b]` «Terminar».
- Antes de practicar hay un modo de aprendizaje: lista de los cinco eventos, cada uno con su botón «Notar el patrón de gol», etc.

### P08 · Elegir partido
- **Objetivo:** elegir el encuentro y confirmar equipos y hora. **Tareas:** T4, T8.
- **Foco:**
  1. `[b]` «Volver»  2. `[b]` «Estado del sistema»
  3. `[h1]` «Elegir partido»
  4. `[b]` «Atlético contra Betis. Hoy a las 21:00. Aún no ha empezado.»
  5. `[b]` «Sevilla contra Valencia. En juego, minuto 34.»
- **Confirmación** (al elegir): «Has elegido Atlético contra Betis, hoy a las 21:00.» · «¿Con qué equipo vas?» `[r]` «Atlético» / «Betis» / «Ninguno» · `[b]` «Confirmar partido» · `[b]` «Elegir otro».
- **Estados:** cargando («Cargando partidos…»), vacío («Hoy no hay partidos disponibles»), error («⚠ No puedo cargar los partidos. Comprueba tu conexión.» + «Reintentar»).

### P09 · Entorno y canales
- **Objetivo:** indicar dónde se ve el partido y aceptar la configuración propuesta. **Tareas:** T4.
- **Foco:**
  1. `[b]` «Volver»  2. `[b]` «Estado del sistema»
  3. `[h1]` «¿Dónde vas a seguir el partido?»
  4. `[r]` «En el estadio» / «En casa» / «En un bar» (preseleccionado el lugar habitual del perfil)
  5. `[t]` «Propuesta para el estadio: vibración fuerte, narración mínima, volumen alto.»
  6. `[b]` «Ajustar»
  7. `[b]` «Iniciar seguimiento»
- **Propuestas:** Estadio → intensidad 5, narración Mínima, volumen 5. Casa → intensidad 3, narración Detallada, volumen 3. Bar → intensidad 4, narración Mínima, volumen 2.
- **Estados:** al cambiar de entorno, la propuesta se actualiza y se anuncia (`aria-live`). No se avanza sola.

### P10 · Ponerse al día
- **Objetivo:** resumen y alineaciones opcionales cuando el partido ya ha empezado. **Tareas:** T8.
- **Foco:**
  1. `[b]` «Volver»  2. `[b]` «Estado del sistema»
  3. `[h1]` «El partido ya ha empezado. Minuto 34»
  4. `[t]` «Sevilla 1, Valencia 0.»
  5. `[b]` «Escuchar resumen»
  6. `[b]` «Escuchar alineaciones»
  7. `[b]` «Ir al directo»
- **Estados:**
  - Reproduciendo: el botón pasa a «Detener resumen». La voz empieza por «Resumen». **No vibra.** El texto del resumen se muestra también en pantalla.
  - Interrupción: si hay un evento, el resumen se detiene, suena el patrón y la voz dice «En directo: falta del Valencia». El botón pasa a «Continuar resumen».

### P11 · Partido
- **Objetivo:** pantalla principal durante el encuentro; ajustes rápidos sin mirar. **Tareas:** T5, T6, T7, T9.
- **Contenido:** marcador y minuto · estado de los datos · último evento · controles rápidos en rejilla fija de 2 columnas · acciones de salida.
- **Foco:**
  1. `[b]` «Estado del sistema»
  2. `[h1]` «Partido. Atlético 1, Betis 0. Minuto 63»
  3. `[t]` «Datos en directo» o «⚠ Sin actualizar desde el minuto 70»
  4. `[t]` «Último evento: córner para el Atlético, minuto 63»
  5. `[b]` «Repetir último evento» (ancho completo, el más grande)
  6. `[b]` «Pausar vibraciones» ↔ «Reanudar vibraciones»
  7. `[b]` «Pausar narración» ↔ «Reanudar narración»
  8. `[b]` «Bajar volumen» · `[b]` «Subir volumen» (entre ambos, «Volumen 3 de 5»)
  9. `[b]` «Nivel de narración: normal. Cambiar»
  10. `[b]` «Ajustes del partido»
  11. `[b]` «Finalizar sesión»
- **Avisos (`aria-live`):**
  - Evento: «Córner para el Atlético» + patrón. Con vibraciones en pausa: «Córner para el Atlético. Vibraciones en pausa.»
  - Repetición: «Repetición: córner para el Atlético» + patrón. Sin eventos: «Aún no hay ningún evento.»
  - Pausas: «Narración en pausa. Las vibraciones siguen activas.» / «Vibraciones en pausa.»
  - Descanso: «Descanso.» · «Empieza la segunda parte. Tu equipo ataca ahora hacia la izquierda.»
- El marcador **no** se anuncia cada minuto: solo cambia el texto. Así el lector no interrumpe continuamente.
- **Modo beta:** bajo el título aparece «Beta: solo móvil. Sin posición del balón.»
- **Finalizar con el partido en juego:** diálogo «El partido sigue en juego. ¿Quieres salir?» con «Seguir viendo el partido» (foco inicial) y «Finalizar sesión».

### P12 · Ajustes del partido
- **Objetivo:** cambios menos frecuentes durante el partido, separados de los controles rápidos. **Tareas:** T4, T7.
- **Foco:** `[b]` «Volver» · `[b]` «Estado del sistema» · `[h1]` «Ajustes del partido» · `[r]` entorno: «En el estadio» / «En casa» / «En un bar» · `[b]` «Vibración y narración» · `[b]` «Guardar y volver al partido».
- **Estados:** el seguimiento no se detiene mientras se está aquí. Guardar → «Ajustes guardados» y vuelve a Partido.

### P13 · Estado del sistema
- **Objetivo:** saber en cualquier momento si todo funciona. **Tareas:** T9.
- **Foco:**
  1. `[b]` «Volver»
  2. `[h1]` «Estado del sistema»
  3. `[t]` «Accesorio: ✓ conectado»
  4. `[t]` «Batería del accesorio: 62 %»
  5. `[t]` «Vibraciones: activas»
  6. `[t]` «Datos del partido: ⚠ sin actualizar desde el minuto 70»
  7. `[b]` «Reintentar conexión» (solo si algo falla)
- **Estados:** todo correcto / fallo de internet / accesorio desconectado («Accesorio: ⚠ desconectado» + «Volver a conectar el accesorio») / sin partido activo. Batería por debajo del 20 %: «⚠ Batería baja: 15 %».

### P14 · Aviso de conexión
- **Objetivo:** avisar del fallo sin que el usuario lo consulte y ofrecer la recuperación. **Tareas:** T9.
- **Forma:** bloque fijo en la parte superior de Partido (`role="alert"`), no una pantalla aparte. No roba el foco, pero queda el primero en el orden de lectura tras el título.

| Variante | Texto que se anuncia | Vibración | Acciones |
|---|---|---|---|
| Falla internet | «⚠ Sin conexión a internet. Los datos del partido no se están actualizando. Intentando reconectar. El accesorio sigue conectado.» | Aviso técnico en el **móvil** y en el accesorio | «Reintentar» · «Finalizar sesión» |
| Falla el accesorio | «⚠ El accesorio se ha desconectado. Seguirás oyendo la narración.» | Aviso técnico **solo en el móvil** | «Volver a conectar el accesorio» · «Seguir solo con el móvil (beta)» · «Finalizar sesión» |
| Reintento fallido | «Todavía sin conexión.» | ninguna | las mismas |
| Recuperada | «✓ Conexión recuperada. Marcador: uno a uno, minuto 72.» | Confirmación | el aviso se cierra solo a los 8 s o con «Cerrar aviso» |

- No se reproducen los patrones atrasados (D-07). Se conservan el partido y los ajustes.

### P15 · Final del partido
- **Objetivo:** anunciar el final y ofrecer el resumen. **Tareas:** T10.
- **Foco:** `[b]` «Estado del sistema» · `[h1]` «Final del partido. Atlético 2, Betis 1» · `[b]` «Escuchar resumen» · `[b]` «Finalizar sesión».
- **Estados:** resumen reproduciéndose («Detener resumen»; empieza por «Resumen»; no vibra; texto visible). «Finalizar sesión» → diálogo «¿Finalizar la sesión?» con «Finalizar» y «Cancelar».

### P16 · Sesión finalizada
- **Objetivo:** confirmar el cierre. **Tareas:** T10. **Es la pantalla de confirmación de cierre de tarea.**
- **Foco:** `[h1]` «Sesión finalizada» · `[t]` «✓ Ajustes guardados. El accesorio está desconectado. Recuerda apagarlo.» · `[b]` «Volver al inicio».
- **Estados:** solo éxito. Vibración de confirmación al entrar.

### P17 · Configuración
- **Objetivo:** ajustes avanzados, separados de los controles rápidos. **Tareas:** T1, T3.
- **Foco:** `[b]` «Volver» · `[b]` «Estado del sistema» · `[h1]` «Configuración» · `[b]` «Mi perfil: baja visión» (→ P03 Personalizar) · `[b]` «Vibración y narración» (→ P06) · `[b]` «Practicar patrones» (→ P07) · `[b]` «Accesorio: Táctil 4F21» (olvidar o emparejar otro) · `[b]` «Repetir el cuestionario».
- **Estados:** «Repetir el cuestionario» pide confirmación: «Se sustituirá tu perfil actual.»

### SIM · Simulador del accesorio (herramienta de prueba)
- **Objetivo:** probar sin hardware. **No forma parte del producto** y no se incluye en los mockups de la app.
- **Forma:** panel separado, debajo de la app en móvil y al lado en escritorio, con borde discontinuo y la etiqueta fija «HERRAMIENTA DE PRUEBA · no forma parte de la app». Plegable. Va **después** de la app en el orden de foco.
- **Contenido:**
  - Mini campo con la posición del balón (dibujo decorativo) y su equivalente en texto: «Balón: campo rival, banda derecha».
  - Registro textual de patrones (`role="log"`): «22:10:05 · Accesorio · Córner · [150,100,500]».
  - Botones para lanzar eventos: «Gol», «Gol anulado», «Falta», «Córner», «Penalti».
  - Botones de fallos: «Cortar internet», «Recuperar internet», «Desconectar accesorio», «Apagar accesorio antes de conectar».
  - «Reproducir partido» / «Pausar partido» y «Borrar registro».
- Reproduce cada patrón con la vibración del móvil cuando el navegador lo permite. Si no, lo indica: «Este navegador no vibra; mira el registro».

## 3. Prompts para Google Stitch

Cada prompt se pega **precedido del bloque base** del tema que se quiera generar.

### Bloque base — tema alto contraste
```
Design a mobile app screen (Android, 412x915) for "Football Vibration", an accessible app that lets blind and low-vision football fans follow a match through a haptic accessory, vibration patterns and audio description. All UI text must be in Spanish (Spain), exactly as given.
Style: accessibility-first, extremely simple, no decoration. Pure black background #000000, white text #FFFFFF, primary buttons filled yellow #FFD400 with black text, secondary buttons black with a 3px white outline. Font: Atkinson Hyperlegible, body 18px, buttons 20px bold, screen title 28px bold. Single column, generous spacing, no cards inside cards, no images, no gradients, no shadows.
Every button is full width, at least 56px tall, with a text label (icons only as a small complement, never alone). Never use colour alone to show a state: always text plus an icon.
Fixed top bar: "Volver" button with left arrow at top left, "Estado" button at top right, both at least 48x48px with visible text. The main action is always the last button at the bottom. Maximum 4 main actions.
```

### Bloque base — tema estándar
```
Same as above, but with this palette: white background #FFFFFF, text #1A1A1A, primary buttons filled dark blue #0A3D7A with white text, secondary buttons white with a 2px #0A3D7A outline and #0A3D7A text.
```
(Pegar el bloque de alto contraste y, a continuación, este párrafo.)

### Prompts por pantalla
```
P01 Bienvenida — No top bar. Title "Bienvenida a Football Vibration". Paragraph "Vamos a adaptar la app a tu forma de ver. Son tres preguntas y tardarás menos de un minuto." One primary button at the bottom: "Empezar".
```
```
P02 Cuestionario — Top bar with "Volver" only. Small text "Paso 1 de 3" with a 3-step text indicator. Title "¿Cuál es tu grado de visión?". Three large radio options as full-width rows with a big radio circle and text: "No veo nada", "Veo con dificultad" (selected, shown with a thick border, filled radio and the word "Seleccionado"), "Otra situación". Primary button "Siguiente". Also generate an error variant: no option selected and a message with a warning icon "Elige una opción para continuar" above the options.
```
```
P03 Perfil propuesto — Top bar with "Volver". Title "Tu perfil propuesto: baja visión". Section "Tus respuestas" with three lines: "Veo con dificultad", "En un bar", "Lector de pantalla: a veces". Paragraph "La app usará alto contraste, letra grande, narración normal y vibración para los eventos." Primary button "Aceptar y guardar", secondary button "Personalizar".
```
```
P04 Inicio — Top bar with only "Estado" at top right (no "Volver"). Title "Inicio". Status line with warning icon: "Accesorio sin conectar". Primary button "Conectar accesorio". Secondary button "Seguir solo con el móvil" with a small text tag "Beta · en desarrollo". Secondary button "Configuración". Also generate a variant where the status line is "Accesorio conectado · Batería 90 %" with a check icon and the primary button is "Elegir partido".
```
```
P05 Conectar accesorio — Top bar "Volver" and "Estado". Title "Conectar accesorio". Generate five state variants of the same screen:
(1) Searching: text "Buscando tu accesorio…" and "Enciéndelo y déjalo cerca del móvil.", secondary button "Cancelar".
(2) Test vibration: text "Tu accesorio acaba de vibrar. ¿La has notado?", primary button "Sí, la he notado", secondary buttons "No la he notado" and "Repetir vibración".
(3) Connected: check icon and text "Accesorio conectado. Batería al 90 %.", primary button "Usar mis ajustes y elegir partido", secondary "Ajustar vibración y narración".
(4) Error: warning icon and text "No encuentro tu accesorio. Comprueba que está encendido y cerca del móvil.", primary button "Reintentar", secondary "Volver".
(5) List: text "He encontrado 2 accesorios. Elige el tuyo." and two full-width buttons "Accesorio Táctil 4F21" and "Accesorio Táctil 9A03".
```
```
P06 Vibración y narración — Top bar "Volver" and "Estado". Title "Vibración y narración". Row "Intensidad" with a large minus button, the text "3 de 5" and a large plus button, and a secondary button "Probar vibración". A large toggle row "Pulsos reforzados" showing the text "Desactivado" and helper text "Vibraciones más largas, para notarlas mejor". Row "Volumen" with minus button, "3 de 5", plus button. Radio group "Nivel de narración": "Mínima: solo los eventos", "Normal" (selected, with the word "Seleccionado"), "Detallada". Secondary button "Practicar patrones". Primary button "Guardar ajustes". No sliders.
```
```
P07 Práctica de patrones — Top bar "Volver". Title "Práctica · Patrón 2 de 5". Large primary button "Reproducir patrón". Text "¿Qué evento es?". Five full-width secondary buttons: "Gol", "Gol anulado", "Falta", "Córner", "Penalti". Also generate a result variant: title "Resultado: 4 de 5 aciertos", text "Has confundido falta y córner.", secondary buttons "Repetir los fallados" and "Escuchar todos los patrones", primary button "Terminar".
```
```
P08 Elegir partido — Top bar "Volver" and "Estado". Title "Elegir partido". Two large full-width buttons, each with two lines of text: "Atlético – Betis" / "Hoy, 21:00 · Aún no ha empezado" and "Sevilla – Valencia" / "En juego · Minuto 34". No club logos. Also generate a confirmation variant: text "Has elegido Atlético – Betis, hoy a las 21:00.", radio group "¿Con qué equipo vas?" with "Atlético", "Betis", "Ninguno", primary button "Confirmar partido", secondary "Elegir otro".
```
```
P09 Entorno y canales — Top bar "Volver" and "Estado". Title "¿Dónde vas a seguir el partido?". Three large radio rows with text and a small icon: "En el estadio" (selected, thick border and the word "Seleccionado"), "En casa", "En un bar". Bordered text block "Propuesta para el estadio: vibración fuerte, narración mínima, volumen alto." Secondary button "Ajustar". Primary button "Iniciar seguimiento".
```
```
P10 Ponerse al día — Top bar "Volver" and "Estado". Title "El partido ya ha empezado · Minuto 34". Large score text "Sevilla 1 – Valencia 0". Secondary buttons "Escuchar resumen" and "Escuchar alineaciones". Primary button "Ir al directo". Also a variant while playing: the first button reads "Detener resumen" and a text block shows "Resumen. Minuto 12: gol de Isaac Romero, uno a cero."
```
```
P11 Partido — Top bar with only "Estado" at top right. Title "Partido". Very large score "Atlético 1 – Betis 0" and "Minuto 63". Status line with check icon "Datos en directo". Bordered block "Último evento: córner para el Atlético, minuto 63". Then the quick controls, always in this order: one full-width primary button "Repetir último evento"; a 2-column row with "Pausar vibraciones" and "Pausar narración"; a row with a large minus button, the text "Volumen 3 de 5" and a large plus button; a full-width secondary button "Nivel de narración: Normal". At the bottom two smaller secondary buttons side by side: "Ajustes del partido" and "Finalizar sesión". Also generate a variant with narration paused: the button reads "Reanudar narración" with a pause icon and a message "Narración en pausa. Las vibraciones siguen activas."
```
```
P12 Ajustes del partido — Top bar "Volver" and "Estado". Title "Ajustes del partido". Radio group "Entorno": "En el estadio", "En casa", "En un bar" (selected, with the word "Seleccionado"). Secondary button "Vibración y narración". Primary button "Guardar y volver al partido".
```
```
P13 Estado del sistema — Top bar "Volver" only. Title "Estado del sistema". Four large rows, each with label, icon and status text: "Accesorio: conectado" (check icon), "Batería del accesorio: 62 %", "Vibraciones: activas", "Datos del partido: sin actualizar desde el minuto 70" (warning icon). Primary button "Reintentar conexión".
```
```
P14 Aviso de conexión — Same layout as the P11 Partido screen, but with a bordered alert block at the top, under the title, with a warning icon and the text "Sin conexión a internet. Los datos del partido no se están actualizando. Intentando reconectar. El accesorio sigue conectado." and two buttons inside it: "Reintentar" (primary) and "Finalizar sesión" (secondary). The status line reads "Sin actualizar desde el minuto 70" with a warning icon. Also generate two variants of the alert: (a) "El accesorio se ha desconectado. Seguirás oyendo la narración." with buttons "Volver a conectar el accesorio" and "Finalizar sesión"; (b) a success alert with check icon "Conexión recuperada. Marcador: 1 – 1, minuto 72." and a button "Cerrar aviso".
```
```
P15 Final del partido — Top bar with only "Estado". Title "Final del partido". Very large score "Atlético 2 – Betis 1". Secondary button "Escuchar resumen". Primary button "Finalizar sesión". Also generate a confirmation dialog variant: text "¿Finalizar la sesión?" with primary button "Finalizar" and secondary "Cancelar", and a second dialog "El partido sigue en juego. ¿Quieres salir?" with primary button "Seguir viendo el partido" and secondary "Finalizar sesión".
```
```
P16 Sesión finalizada — No top bar. Large check icon. Title "Sesión finalizada". Text "Ajustes guardados. El accesorio está desconectado. Recuerda apagarlo." Primary button "Volver al inicio".
```
```
P17 Configuración — Top bar "Volver" and "Estado". Title "Configuración". A simple list of five full-width rows, each a button with a title and a second line with the current value: "Mi perfil" / "Baja visión", "Vibración y narración" / "Intensidad 3 · Narración normal", "Practicar patrones" / "Última práctica: 5 de 5", "Accesorio" / "Táctil 4F21", "Repetir el cuestionario". No toggles on this screen.
```

## 4. Mapa de navegación (para enlazar el prototipo)

| Origen | Acción | Destino | Feedback |
|---|---|---|---|
| P01 | «Empezar» | P02 paso 1 | foco en la pregunta |
| P02 paso n | «Siguiente» con opción elegida | P02 paso n+1 (o P03 tras el paso 3) | — |
| P02 paso n | «Siguiente» sin opción | P02 paso n | «Elige una opción para continuar» |
| P02 paso n | «Volver» | paso anterior (o P01) | respuestas conservadas |
| P03 | «Aceptar y guardar» / «Guardar preferencias» | P04 | vibración + «Preferencias guardadas» |
| P03 | «Volver» | P02 paso 3 | — |
| P04 | «Conectar accesorio» | P05 buscando | «Buscando tu accesorio» |
| P04 | «Elegir partido» (accesorio conectado) | P08 | — |
| P04 | «Seguir solo con el móvil (beta)» → «Continuar» | P08 | aviso de función en desarrollo |
| P04 | «Configuración» | P17 | — |
| cualquiera | «Estado» | P13 | «Volver» regresa al origen |
| P05 buscando | encontrado, primera vez | P05 lista → P05 prueba | el accesorio vibra |
| P05 prueba | «Sí, la he notado» | P05 conectado | vibración + «Accesorio conectado» |
| P05 prueba | «No la he notado» | P05 ayuda | «Sube la intensidad o prueba otra vez» |
| P05 buscando | encontrado, ya emparejado | P05 conectado | vibración + «Accesorio conectado» |
| P05 buscando | no encontrado (10 s) | P05 error | «No encuentro tu accesorio…» |
| P05 error | «Reintentar» | P05 buscando | — |
| P05 error | «Volver» | P04 | — |
| P05 conectado | «Usar mis ajustes y elegir partido» | P08 | — |
| P05 conectado | «Ajustar vibración y narración» | P06 | — |
| P06 | «Practicar patrones» | P07 | — |
| P06 | «Guardar ajustes» | pantalla de origen (P05, P09, P12 o P17) | «Ajustes guardados» |
| P06 | «Volver» con cambios | diálogo de guardar | «Tienes cambios sin guardar» |
| P07 | «Terminar» | P06 | resultado guardado |
| P08 | elegir partido → «Confirmar partido» | P09 | «Has elegido…» |
| P09 | «Ajustar» | P06 | — |
| P09 | «Iniciar seguimiento» (partido sin empezar) | P11 | «Seguimiento iniciado» |
| P09 | «Iniciar seguimiento» (partido empezado) | P10 | «El partido ya ha empezado» |
| P10 | «Ir al directo» | P11 | — |
| P11 | controles rápidos | P11 | vibración + mensaje de confirmación |
| P11 | «Ajustes del partido» | P12 | el seguimiento continúa |
| P12 | «Guardar y volver al partido» | P11 | «Ajustes guardados» |
| P11 | fallo de internet o del accesorio | P11 + P14 | aviso técnico en el móvil + voz + texto |
| P14 | «Reintentar» | P11 (o P14 «Todavía sin conexión») | «Conexión recuperada. Marcador…» |
| P14 | «Volver a conectar el accesorio» | P05 buscando → P11 | se conserva el partido |
| P11 | «Finalizar sesión» (en juego) | diálogo → P11 o P15 | «El partido sigue en juego» |
| P11 | final del partido | P15 | «Final del partido. Atlético 2, Betis 1» |
| P15 | «Finalizar sesión» → «Finalizar» | P16 | vibración + «Sesión finalizada» |
| P16 | «Volver al inicio» | P04 | accesorio sin conectar |
| P17 | cada apartado | P03 / P06 / P07 / P05 / P02 | — |

**Recorridos mínimos del prototipo navegable:** primer acceso (P01 → P04), uso habitual (P04 → P05 → P08 → P09 → P11), partido empezado (P09 → P10 → P11), fallo y recuperación (P11 → P14 → P11) y cierre (P11 → P15 → P16).

## 5. Prototipo funcional: estructura y límites

- **Estructura prevista:** `/prototipo/index.html`, `css/`, `js/` (un módulo por pantalla más `patrones.js`, `voz.js`, `partido.js`, `simulador.js`), `data/partido-simulado.json`. Se abre con un servidor estático local; no hay compilación ni dependencias.
- **Preferencias:** `localStorage` (R9.4.3).
- **Siempre:** HTML semántico, todo operable con teclado, foco visible, textos de esta especificación sin cambios, comprobación de cada pantalla antes de pasar a la siguiente.
- **Preguntar antes:** añadir librerías, cambiar textos o el orden de los controles, añadir pantallas.
- **Nunca:** backend real, Bluetooth real, datos de partidos reales, animaciones decorativas, estados solo con color.

## 6. Criterios de aceptación

1. Los recorridos T1–T10 se completan solo con teclado y con lector de pantalla.
2. Contraste de texto ≥ 7:1 en los dos temas, verificado con herramienta.
3. Al 200 % de zoom no hay texto cortado ni desplazamiento horizontal a 360 px de ancho.
4. Todos los objetivos táctiles miden al menos 48×48 px.
5. Cada cambio de estado tiene texto y se anuncia en una región `aria-live`.
6. Los patrones emitidos coinciden con `patrones.md` y aparecen en el registro del simulador.
7. Sin errores en la consola. Uso habitual en menos de 2 minutos.

## 7. Preguntas abiertas

1. **Nombre de la app:** se ha usado «Football Vibration» como nombre provisional. ¿Tenéis otro?
2. **Equipos y jugadores de ejemplo:** se usan nombres reales (Atlético, Betis, Sevilla, Valencia). ¿Preferís equipos inventados?
3. **Mockups:** ¿los vais a generar en Stitch y me pasáis capturas, o construyo el código directamente desde esta especificación?

## 8. Cambios de la Iteración 2

Esta especificación describe la Iteración 1. Tras la evaluación heurística (fase5.md) cambian estos puntos, que **prevalecen** sobre las fichas anteriores y deben reflejarse en los mockups:

- **P11 Partido, nuevo orden:** título → marcador → minuto → «Repetir último evento» → «Pausar vibraciones» y «Pausar narración» → volumen → «Nivel de narración: normal · Pulsa para cambiar» → último evento → estado de los datos → línea «⏸ Vibraciones en pausa» (si aplica) → «Ajustes del partido» → «Finalizar sesión» (sola y separada).
- **P14 Aviso de conexión:** aparece **debajo** de la pantalla, no encima. No se cierra solo. Nueva variante: «Batería del accesorio baja: 15 %. Puede apagarse antes de que acabe el partido.»
- **P05 Conectar accesorio, estado Conectado (primera vez):** mensaje «Aún no has practicado los patrones de vibración.» y botones «Ajustar vibración y narración», «Elegir partido sin practicar» y «Practicar los patrones (recomendado)» como principal.
- **P07 Práctica:** si se responde sin reproducir: «Primero pulsa «Reproducir patrón».»
- **P08 Elegir partido:** el equipo elegido la última vez viene marcado.
- **P12 Ajustes del partido:** nuevo botón «Recordar los patrones».
- **P14, reintento fallido:** «Todavía sin conexión. Sigo intentándolo; te avisaré cuando vuelva.»
- **Botón «atrás» del sistema:** equivale a «Volver»; en Partido abre la confirmación de salida.

En los prompts de Stitch de P11, P14 y P05 hay que aplicar este orden y estos textos.
