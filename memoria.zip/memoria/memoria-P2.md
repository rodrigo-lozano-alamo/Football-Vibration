# Memoria de la Práctica 2 — Football Vibration

**Asignatura:** Interacción Persona Ordenador · Universidad Francisco de Vitoria, Grado en Ingeniería Informática
**Participantes:** Rodrigo Lozano, Javier Sesmero, Antonio Zarza, Walter Dybek, Enrique González y Marcos Chimeno
**Práctica 2:** diseño de la interfaz, mockups y prototipado interactivo

> Este documento continúa la memoria de la Práctica 1 (apartados 1 a 9). Por eso la numeración empieza en el 10 y las referencias R9.x remiten a los requisitos del apartado 9 de la P1.

## 10. Introducción a la Práctica 2 y cambios respecto a la Práctica 1

### 10.1 Objetivo y alcance

En la Práctica 1 definimos el problema, los usuarios (Andrés, Lucía y Manuel), diez tareas, el contexto de uso, los flujos y los requisitos. En esta práctica convertimos esa base en una interfaz: escenarios de uso, sistema visual, especificación de pantallas, mockups, un prototipo navegable y un primer desarrollo funcional, con dos iteraciones de diseño.

La app se llama **Football Vibration**. El alcance no cambia respecto a la P1:

- **Diseñamos solo la app móvil** que configura y controla el accesorio háptico. No diseñamos el accesorio, ni su forma, ni su firmware: se asume que existe y que se conecta por Bluetooth.
- Quedan fuera la visión por computador, el servidor en tiempo real, los pagos, las entradas, la geolocalización y las tiendas.
- **Los datos del partido son simulados** (un archivo JSON local).
- Para probar sin hardware, el prototipo incluye un **simulador del accesorio**, marcado como herramienta de prueba. No forma parte del producto.

### 10.2 Revisión de coherencia de la Práctica 1

Antes de diseñar revisamos la memoria de la P1 y encontramos incoherencias entre tareas, flujos, storyboards y requisitos. La P2 parte de las versiones corregidas. El detalle y los textos de sustitución completos están en el documento de trabajo `fase0.md`.

| Nº | Dónde (P1) | Incoherencia | Corrección adoptada en la P2 |
|---|---|---|---|
| 1 | Tarea 6 | Decía que el evento se reconoce «mediante la narración y los efectos de sonido». Contradecía sus propios pasos, el apartado 2 y R9.3.1. | El evento se reconoce **principalmente por el patrón de vibración**. La narración (equipo y jugador) es complementaria. |
| 2 | R9.5.2 y R9.3.2 | El aviso de desconexión era «un patrón vibratorio» sin decir de dónde salía. Un accesorio desconectado no puede vibrar. | El aviso sale **siempre del móvil** (vibración, voz y texto). El accesorio solo lo repite si sigue conectado y lo que falla es internet. |
| 3 | Tabla 4.6 y apartado 5 | Las diez tareas tenían nombres distintos en la tabla y en el análisis. | Nombres unificados (ver 10.3). |
| 4 | Apartado 2 | «autodescripción». | «audiodescripción». |
| 5 | Apartado 4.1 | Marcador sin rellenar sobre la encuesta. Falta el apartado 4.2. | **[PENDIENTE: nº respuestas y canal]**. No se inventan resultados. |
| 6 | Apartados 2, 6 y R9.2.1 | El límite de 2 minutos incluía a veces el emparejamiento y el perfil, que solo se hacen una vez. | El límite se aplica al **uso habitual**: abrir, conectar el accesorio ya emparejado, elegir partido y entorno e iniciar. El primer acceso se mide aparte. |
| 7 | Apartado 2 | El criterio del 95 % omitía el penalti. | Mismos eventos en todo el documento: gol, gol anulado, falta, córner y penalti. |
| 8 | Perfil de Manuel | Citaba R9.3.3 para la intensidad de vibración. | El requisito correcto es R9.4.1. |
| 9 | Varios | «Dispositivo háptico», «accesorio», «dispositivo táctil» y «Tablet háptica» como sinónimos. | Se usa siempre **«accesorio háptico»**. «Tablet» describía un hardware que no diseñamos. |
| 10 | Apartado 6 | «Suponemos que el usuario tiene un móvil con lector de pantalla». Manuel no lo usa y Lucía solo de noche. | La app debe funcionar igual con lector de pantalla y sin él. |
| 11 | Apartado 4 y R9.1.4 | Tres perfiles de usuario frente a dos perfiles en la app. | Hay 3 personas y 2 perfiles de accesibilidad. Manuel parte del de baja visión, sin lector y con pulsos reforzados. |
| 12 | Tarea 2 | Precondición «dispositivo encendido» y primer paso «Encender el dispositivo». | Se elimina la precondición. |
| 13 | Tarea 2 y storyboard | No quedaba claro si la vibración de prueba se confirma siempre. | Solo en el emparejamiento inicial. Después, la app confirma la conexión sin pedir respuesta. |
| 14 | Tarea 4 | El entorno se cambiaba «desde los controles rápidos», que no lo incluían. | Se cambia en «Ajustes del partido», separado de los controles rápidos (R9.2.4). |
| 15 | Perfil de Lucía y Tarea 7 | «Pausar la narración en un toque» frente a «abrir los controles rápidos». | Los controles rápidos están siempre visibles en la pantalla Partido. |
| 16 | Storyboard y Tarea 6 | No se definía qué se repite con «Repetir último evento». | Se repiten el patrón y la narración, que empieza por «Repetición:». |
| 17 | Tarea 5 | La posición del balón se describía como «vibración», el mismo canal que los eventos. | La posición es un **punto táctil**; la vibración queda para los eventos (R9.3.1). |
| 18 | Tarea 6 y patrones | El gol anulado propuesto era el principio del patrón de gol. La web no permite regular la intensidad. | Nuevo patrón de gol anulado y opción «Pulsos reforzados» (apartado 12.2). |
| 19 | Tarea 3 | La práctica servía para «mejorar la narración». | Sirve para que el usuario aprenda los patrones (R9.3.3). El resultado es «X de 5 aciertos». |
| 20 | Tarea 9 y R9.5.3 | Si había un gol durante un corte, el usuario no se enteraba. | Al reconectar no se reproducen patrones atrasados, pero se anuncia una vez el marcador y el minuto. |
| 21 | Tareas 7, 8 y 10 | Faltaban precondiciones. | Añadidas. |
| 22 | Apartado 8 | Los storyboards se llamaban «Tarea 1…4» sin corresponder a T1…T4. | Pasan a llamarse Escenario A–D. La P2 añade un escenario por cada tarea. |
| 23 | Tabla 4.6 y Tarea 4 | T2 solo era «relevante» para Lucía, pero T4 exigía el accesorio conectado. | Se añade **«Seguir solo con el móvil»**, marcado como **beta, en desarrollo**. |
| 24 | Índice y texto | Faltaba el 9.1 en el índice; varias erratas. | Corregidas en la versión final de la memoria. |

### 10.3 Tareas con su nombre definitivo

T1 Configurar el perfil inicial · T2 Emparejar y conectar el accesorio · T3 Calibrar y practicar los patrones · T4 Seleccionar partido y entorno · T5 Seguir la posición del balón · T6 Identificar un evento · T7 Realizar ajustes rápidos · T8 Ponerse al día en un partido empezado · T9 Consultar el estado y recuperar la conexión · T10 Finalizar: resumen y desconexión.

## 11. Escenarios

Hay un escenario por cada tarea. Cada uno indica quién, dónde y cuándo, el objetivo, la interacción con las pantallas y botones reales del diseño, un obstáculo y cómo lo resuelve la interfaz, y un criterio de éxito medible. Los partidos y los eventos son simulados.

### E1 · T1 Configurar el perfil inicial — Lucía

**Jueves, 22:40, en su habitación, con la luz apagada y en silencio.** Lucía acaba de instalar la app para el partido del sábado. De noche su retinosis le deja ver muy poco, así que ha activado TalkBack. Tiene el móvil con el texto al 200 % y alto contraste. Quiere dejar el perfil hecho sin pedir ayuda a su compañera de piso.

Abre la app y TalkBack lee: «Bienvenida. Vamos a adaptar la app a tu forma de ver. Son tres preguntas». Pulsa **«Empezar»**. En **Cuestionario inicial** escucha «Pregunta 1 de 3. ¿Cuál es tu grado de visión?» y elige «Baja visión». Pulsa **«Siguiente»**. En la segunda pregunta, «¿Dónde sueles seguir los partidos?», desliza demasiado rápido y marca «Estadio».

**Obstáculo.** Se da cuenta en la pantalla **Perfil propuesto**, que lee el resumen completo: «Perfil de baja visión. Lugar habitual: estadio. Lector de pantalla: a veces». Pulsa **«Atrás»**: la app vuelve a la pregunta 2 con las demás respuestas intactas. Cambia a «Bar» y regresa al resumen. Pulsa **«Aceptar perfil»** y luego **«Guardar preferencias»**. El móvil da un toque de confirmación y TalkBack anuncia: «Preferencias guardadas. Estás en Inicio».

Ningún texto se ha cortado al 200 % y no ha tenido que hacer zoom.

**Criterio de éxito:** perfil guardado en menos de 2 minutos, sin ayuda, corrigiendo un error sin volver a contestar las otras preguntas.

---

### E2 · T2 Emparejar y conectar el accesorio — Andrés

**Sábado, 20:45, en su asiento del estadio, quince minutos antes del inicio. Unos 85 dB de ambiente y megafonía.** Andrés lleva el accesorio sobre las rodillas y un auricular abierto en el oído derecho. Ya lo emparejó en casa. Hoy solo quiere conectarlo y tener el partido listo antes del saque inicial.

Abre la app. VoiceOver anuncia «Inicio. Accesorio sin conectar». Hace doble toque en **«Conectar accesorio»**. La pantalla **Conectar accesorio** dice «Buscando tu accesorio…» y, a los diez segundos: «No encuentro tu accesorio. Comprueba que está encendido y cerca del móvil».

**Obstáculo.** Con las prisas no lo había encendido. El mensaje no habla de Bluetooth ni de códigos de error y le ofrece dos botones: **«Reintentar»** y **«Volver»**. Enciende el accesorio y pulsa **«Reintentar»**. Esta vez el accesorio vibra una vez y VoiceOver lee «Accesorio conectado. Batería al 90 %». Como ya estaba emparejado, no tiene que elegirlo en la lista ni contestar a la vibración de prueba. La app no ha dicho «conectado» en ningún momento antes de que lo estuviera.

Vuelve a **Inicio**, donde el estado ha cambiado a «Accesorio conectado», y sigue con **«Elegir partido»**.

**Criterio de éxito:** accesorio conectado y partido en seguimiento en menos de 2 minutos desde que abre la app, sin ayuda de su amigo, incluido el reintento.

---

### E3 · T3 Calibrar y practicar los patrones — Manuel

**Domingo, 11:00, en el salón de su casa, con buena luz y la televisión apagada.** Su nieto le emparejó el accesorio ayer. Hoy Manuel quiere aprender las vibraciones él solo antes del partido de la tarde. Tiene menos sensibilidad en los dedos y teme «tocar algo y estropearlo».

En **Inicio** pulsa **«Configuración»** y después **«Vibración y narración»**. La pantalla tiene pocos controles y letra grande. Sube **«Intensidad»** a 4 y pulsa **«Probar vibración»**: la nota. Deja **«Nivel de narración»** en «Normal» y pulsa **«Practicar patrones»**.

En **Práctica de patrones** pulsa **«Reproducir patrón»**, nota la vibración y elige una de las cinco respuestas. Acierta el gol y el penalti, pero confunde la falta con el córner: las dos empiezan con un pulso corto que apenas percibe.

**Obstáculo.** Al terminar, la app dice en voz y texto: «3 de 5 aciertos. Has confundido falta y córner. Puedes activar Pulsos reforzados para notarlos mejor». Manuel vuelve atrás, activa **«Pulsos reforzados»** y pulsa **«Repetir los fallados»**. Ahora los pulsos duran más y distingue el final largo del córner. Resultado: «5 de 5 aciertos».

Pulsa **«Guardar ajustes»**. Antes ha intentado salir con «Atrás» y la app le ha preguntado: «Tienes cambios sin guardar. ¿Guardar o descartar?». Eso le tranquiliza: no ha perdido ni roto nada.

**Criterio de éxito:** al menos 4 de 5 aciertos en la segunda ronda y ajustes guardados sin ayuda en menos de 5 minutos.

---

### E4 · T4 Seleccionar partido y entorno — Lucía

**Sábado, 20:55, en un bar con luz tenue, reflejos en las mesas y unos 70 dB de conversación.** Lucía está con cuatro amigos. No tiene accesorio: quiere que el móvil, boca abajo en la mesa, le avise de los eventos que se le escapan en la tele. No quiere llamar la atención.

Abre la app con el tema de alto contraste. En **Inicio** pulsa **«Seguir solo con el móvil (beta)»**. Un texto breve le avisa: «Función en desarrollo. Notarás los eventos en el móvil. La posición del balón necesita el accesorio». Acepta y llega a **Elegir partido**. Cada partido es un botón grande con los dos equipos y la hora en texto. Elige el de las 21:00.

En **Entorno y canales** quiere pulsar «Bar», pero con el reflejo toca **«Casa»**.

**Obstáculo.** La app no avanza sola: muestra la propuesta para casa («Narración detallada, volumen medio») y Lucía ve que no es lo que quiere. La opción elegida se distingue por un borde grueso y el texto «Seleccionado», no solo por el color. Pulsa **«Bar»** y la propuesta cambia a «Narración mínima, volumen bajo, vibración en el móvil». Antes de empezar, la pantalla confirma «Vas a seguir: Atlético – Betis, hoy a las 21:00, en un bar». Pulsa **«Iniciar seguimiento»** y entra en **Partido**.

**Criterio de éxito:** partido en seguimiento en menos de 1 minuto, sin hacer zoom y con el entorno correcto tras corregir un toque equivocado.

---

### E5 · T5 Seguir la posición del balón — Andrés

**Sábado, 21:50, en el estadio, al empezar la segunda parte. Unos 95 dB, de noche.** Andrés ha seguido toda la primera parte con la mano izquierda sobre el accesorio. Sabía que su equipo atacaba hacia la derecha. Durante el descanso ha estado hablando con su amigo y ha quitado la mano.

La pantalla **Partido** no requiere que la mire ni que la toque. Cuando termina el descanso, el móvil da un toque de confirmación y la narración dice: «Empieza la segunda parte. Tu equipo ataca ahora hacia la izquierda». El mismo texto aparece en la zona de último aviso de la pantalla.

Andrés coloca la mano, localiza el centro del campo y las dos áreas por su relieve, y sigue con el dedo el punto táctil que marca el balón.

**Obstáculo.** Con el ruido del estadio no ha oído el aviso y, durante el primer minuto, cree que su equipo está defendiendo cuando en realidad ataca. Duda, saca el móvil y hace doble toque en **«Repetir último evento»**. La app responde: «Repetición: empieza la segunda parte. Tu equipo ataca ahora hacia la izquierda». Recoloca su mapa mental y sigue. Además, como el balón estuvo parado quince minutos, el aviso de inicio le confirma que el sistema no se había quedado colgado.

**Criterio de éxito:** tras el descanso, Andrés dice correctamente hacia qué lado ataca su equipo antes de que pase el minuto 47, con una sola consulta a la app como máximo.

---

### E6 · T6 Identificar un evento — Andrés

**Sábado, 22:10, en el estadio, minuto 63. Más de 95 dB: la grada está cantando.** Andrés sigue el balón con una mano. El auricular abierto apenas se oye con el ruido. Quiere enterarse de las jugadas al mismo tiempo que el resto de la grada.

El balón sale por la línea de fondo. El accesorio vibra corto y luego largo. Andrés reconoce el **córner** por el patrón, sin oír nada: es el único que empieza corto y acaba largo. La narración añade «Córner para el Atlético», pero el ruido la tapa. No la necesita.

Tres minutos después nota tres pulsos largos: **gol**. La grada estalla. Un minuto más tarde llega un pulso muy largo seguido de dos cortos.

**Obstáculo.** No está seguro: es el patrón que menos ha practicado. Hace doble toque en **«Repetir último evento»**, que está siempre en el mismo sitio de la pantalla **Partido**. El accesorio repite el patrón y la narración dice: «Repetición: gol anulado al Atlético por fuera de juego». La palabra «Repetición» le deja claro que no es una jugada nueva. El marcador en pantalla vuelve a 0-0 y el último evento muestra «Gol anulado», en texto.

**Criterio de éxito:** identifica el córner y el gol a la primera y solo por la vibración. Resuelve la duda del gol anulado con una única repetición, en menos de 10 segundos.

---

### E7 · T7 Realizar ajustes rápidos — Lucía

**Sábado, 21:25, en el bar, minuto 25. Luz tenue y unos 75 dB.** Lucía sigue el partido en la tele y lleva un solo auricular. Una amiga empieza a contarle algo importante y la narración se le mezcla con la conversación.

Mira el móvil. En la pantalla **Partido** los controles son botones grandes, con texto y siempre en el mismo orden. Con el pulgar pulsa **«Pausar narración»**. El móvil da un toque corto y el botón cambia a «Reanudar narración». Debajo aparece: «Narración en pausa. Las vibraciones siguen activas». Ha sido un solo toque y no ha tenido que abrir ningún menú.

**Obstáculo.** Diez minutos después quiere reanudarla, pero pulsa sin mirar el botón de al lado, **«Pausar vibraciones»**. La app lo confirma con voz y texto: «Vibraciones en pausa». Lucía no lo oye porque el volumen está bajo. Cuando llega una falta, el móvil no vibra, pero la pantalla muestra «Falta del Betis. Vibraciones en pausa» y lo dice por el auricular. Lucía entiende lo que ha pasado, pulsa **«Reanudar vibraciones»** y luego **«Reanudar narración»**. Para no molestar, baja un punto con **«Volumen −»** y la app confirma «Volumen 3 de 5».

**Criterio de éxito:** pausa la narración con un toque y en menos de 3 segundos. Detecta y corrige la pausa accidental de las vibraciones en el siguiente evento.

---

### E8 · T8 Ponerse al día en un partido empezado — Manuel

**Domingo, 18:35, en el sofá de su casa, con la televisión encendida a volumen medio.** La siesta se ha alargado y el partido empezó a las 18:00. Manuel no distingue el balón ni el marcador de la tele. Quiere saber cómo van antes de seguir el directo.

Conecta el accesorio, pulsa **«Elegir partido»** y elige el suyo. La app le avisa: «El partido ya ha empezado. Minuto 34». Llega a la pantalla **Ponerse al día**, con cuatro botones grandes. Pulsa **«Escuchar resumen»**.

La voz empieza: «Resumen. Minuto 12, gol de Griezmann, uno a cero…». El accesorio no vibra: el resumen nunca vibra, así que Manuel no lo confunde con algo que esté pasando ahora.

**Obstáculo.** A mitad del resumen hay una falta en el directo. El resumen se corta, el accesorio vibra con dos pulsos cortos y la voz dice «En directo: falta del Betis». Después la app pregunta: «¿Seguir con el resumen o ir al directo?». Manuel pulsa **«Escuchar resumen»** y continúa donde lo dejó. Luego pulsa **«Escuchar alineaciones»**, se cansa a la mitad y pulsa **«Ir al directo»**. Entra en **Partido**, donde lee en letra grande «Atlético 1 – Betis 0. Minuto 37».

**Criterio de éxito:** en menos de 90 segundos sabe el marcador y quién ha marcado, y no confunde el resumen con el directo.

---

### E9 · T9 Consultar el estado y recuperar la conexión — Andrés

**Sábado, 22:20, en el estadio, minuto 70. Hay 60 000 personas y la red móvil está saturada.** Andrés nota que el balón lleva un rato quieto en el centro del campo, pero la grada grita como si hubiera una ocasión. Duda si el sistema sigue funcionando.

No le hace falta consultarlo: el **móvil** vibra en el bolsillo con cuatro pulsos rápidos, distintos de cualquier evento del partido. Como el accesorio sigue conectado, repite el mismo aviso. La voz dice: «Sin conexión a internet. Los datos del partido no se están actualizando. Intentando reconectar».

Saca el móvil. VoiceOver lee el **Aviso de conexión**: «Falla internet. El accesorio sigue conectado», con los botones **«Reintentar»** y **«Finalizar sesión»**. La pantalla **Partido** marca los datos como «Sin actualizar desde el minuto 70».

**Obstáculo.** Pulsa **«Reintentar»** y falla: «Todavía sin conexión». No pierde el partido elegido ni sus ajustes. Abre **«Estado»** y confirma: accesorio conectado, batería 62 %, vibraciones activas, datos del partido detenidos. Espera. A los dos minutos la app reconecta sola y anuncia una sola vez: «Conexión recuperada. Marcador: uno a uno, minuto 72». No reproduce el patrón del gol que se perdió, así que no cree que acaban de marcar.

**Criterio de éxito:** sabe en menos de 10 segundos que el fallo es de internet y no del accesorio. Tras la reconexión conoce el marcador real sin recibir avisos atrasados.

---

### E10 · T10 Finalizar: resumen y desconexión — Manuel

**Domingo, 19:50, en el salón de su casa. Su hija ha llegado y están hablando.** Es el minuto 88. Manuel quiere bajar el volumen para oír a su hija, pero su visión central no le deja ver bien dónde toca.

**Obstáculo.** Pulsa **«Finalizar sesión»** por error. La app no cierra nada. Muestra dos botones grandes y dice: «El partido sigue en juego. ¿Quieres salir?». Las opciones son **«Seguir viendo el partido»** y **«Finalizar sesión»**. Manuel pulsa la primera y vuelve a **Partido** tal como estaba. No ha estropeado nada.

Tras el pitido final, el accesorio no vibra y la voz anuncia: «Final del partido. Atlético 2 – Betis 1». La pantalla **Final del partido** ofrece **«Escuchar resumen»** y **«Omitir»**. Manuel escucha el resumen, que empieza por «Resumen» y no vibra, y lo comenta con su hija.

Después pulsa **«Finalizar sesión»**. Esta vez la app pide una confirmación sencilla y cierra. En **Sesión finalizada** lee y escucha: «Sesión cerrada. El accesorio está desconectado; recuerda apagarlo. Tus ajustes quedan guardados para el próximo partido». Pulsa **«Volver al inicio»**.

**Criterio de éxito:** cierra la sesión sin ayuda, sin salir del partido por accidente, y sabe que sus ajustes se han guardado.

---

### Trazabilidad de los escenarios

| Escenario | Tarea | Perfil | Requisitos R9.x | Pantallas |
|---|---|---|---|---|
| E1 | T1 Configurar el perfil inicial | Lucía (TalkBack, texto al 200 %) | 9.1.1, 9.1.2, 9.1.4, 9.2.3, 9.4.3 | P01, P02, P03, P04 |
| E2 | T2 Emparejar y conectar el accesorio | Andrés (VoiceOver, estadio) | 9.1.1, 9.1.3, 9.2.1, 9.2.3, 9.5.1 | P04, P05 |
| E3 | T3 Calibrar y practicar los patrones | Manuel (sin lector, casa) | 9.3.2, 9.3.3, 9.4.1, 9.2.3, 9.4.3 | P04, P17, P06, P07 |
| E4 | T4 Seleccionar partido y entorno | Lucía (alto contraste, bar) | 9.1.2, 9.4.2, 9.2.1, 9.2.3 | P04, P08, P09, P11 |
| E5 | T5 Seguir la posición del balón | Andrés (estadio) | 9.3.1, 9.2.2, 9.5.4 | P11, SIM |
| E6 | T6 Identificar un evento | Andrés (estadio) | 9.3.1, 9.3.2, 9.5.4, 9.1.3 | P11, SIM |
| E7 | T7 Realizar ajustes rápidos | Lucía (bar) | 9.2.2, 9.2.4, 9.4.1, 9.6.1, 9.1.2 | P11 |
| E8 | T8 Ponerse al día en un partido empezado | Manuel (casa) | 9.3.1, 9.2.3, 9.2.4 | P08, P10, P11 |
| E9 | T9 Consultar el estado y recuperar la conexión | Andrés (estadio) | 9.5.1, 9.5.2, 9.5.3, 9.3.2 | P11, P14, P13 |
| E10 | T10 Finalizar: resumen y desconexión | Manuel (casa) | 9.2.3, 9.4.3, 9.1.2 | P11, P15, P16 |

**Cobertura:** las diez tareas tienen escenario; cada perfil aparece al menos en tres. Los requisitos 9.3.4 (latencia), 9.3.5 (batería) y 9.7.1 (validación) no se pueden demostrar en un escenario narrativo: se tratan en el prototipo y en el análisis.

## 12. Sistema visual y de patrones

### 12.1 Sistema visual

El sistema visual es mínimo y la prioridad es la accesibilidad: si la estética choca con ella, gana la accesibilidad.

#### Temas

| Token | Tema estándar (perfil ceguera total) | Tema alto contraste (perfil baja visión) |
|---|---|---|
| Fondo de pantalla | `#F3F6F2` | `#000000` |
| Tarjetas y botones secundarios | `#FFFFFF` | `#000000` |
| Texto | `#10231A` (15,09:1) | `#FFFFFF` (21:1) |
| Acción principal y tablero del marcador | `#0B4A2D` (verde césped), texto blanco (10,34:1) | Botón `#FFD400`, texto negro (14,67:1). Tablero negro con borde amarillo |
| Acción secundaria | fondo blanco, borde 2 px `#0B4A2D`, texto `#10231A` | borde 3 px `#FFFFFF`, texto `#FFFFFF` |
| Error | `#9B1C1C` (7,48:1) | `#FF8A80` (9,20:1) |
| Correcto | `#0B4A2D` (9,49:1) | `#7CFC9A` (16,25:1) |
| Foco | contorno 3 px azul `#1746A2` + separación 3 px (7,92:1) | contorno 4 px `#00E5FF` + separación 3 px |

- El tema estándar existe porque un acompañante puede mirar la pantalla y porque Andrés puede enseñar el móvil. Cumple también 7:1 en texto.
- Las relaciones de contraste se han medido con la fórmula de WCAG sobre los colores del prototipo (apartado 15).
- Los dos temas se pueden cambiar en Configuración. La app respeta también `prefers-contrast` y `prefers-color-scheme` como valor inicial.

#### Tipografía
- Fuente: **Atkinson Hyperlegible** (diseñada para baja visión), con `system-ui` como alternativa.
- Tamaños en `rem`: texto 1,125; botones 1,25; título de pantalla (h1) 1,75; marcador 2,5. Interlineado 1,5.
- Tamaño de texto de la app: Normal / Grande (×1,25) / Muy grande (×1,5), además del zoom del sistema.
- **Soporte del 200 %:** una sola columna, sin alturas fijas, sin texto truncado ni puntos suspensivos. Los botones crecen en alto y el texto pasa a varias líneas. Nunca hay desplazamiento horizontal.

#### Controles
- Objetivo táctil mínimo **48×48 px**. Botones principales: ancho completo y 56 px de alto como mínimo. Separación mínima entre controles: 12 px.
- **Máximo 3–4 acciones principales por pantalla.** Excepciones justificadas: Partido (controles rápidos fijos, D-05) y Configuración (lista de apartados).
- **Posiciones fijas:** «Volver» siempre arriba a la izquierda; «Estado» siempre arriba a la derecha. Inicio y Partido no tienen «Volver» (son pantallas raíz) y ese hueco queda vacío. La acción principal va siempre la última, abajo, a ancho completo.
- **Estados con texto e icono, nunca solo con color:** ✓ «Conectado», ⚠ «Sin conexión», ⏸ «En pausa», ● «Seleccionado». Los iconos son decorativos (`aria-hidden`); el texto lleva la información.
- Los botones de pausa cambian de texto («Pausar narración» ↔ «Reanudar narración») y usan `aria-pressed`.

#### Movimiento y foco
- Sin animaciones decorativas. Los cambios de pantalla son inmediatos. La única animación es el indicador «Buscando…», que se desactiva con `prefers-reduced-motion` y siempre lleva texto.
- Al cambiar de pantalla, el foco va al **título (h1)**, que el lector lee como «Nombre de la pantalla».
- Dos regiones de avisos en todas las pantallas: `aria-live="polite"` para confirmaciones y `role="alert"` para fallos de conexión.
- Cada pantalla tiene `<title>` propio: «Partido · Football Vibration».

### 12.2 Sistema de patrones de vibración

Esta tabla es la misma en la memoria, en los mockups y en el código. Los valores están en milisegundos (vibra, pausa, vibra…).

**Reglas de diseño**
- Los patrones se distinguen por el **ritmo y la duración**, no por la intensidad. La API web no permite controlar la intensidad.
- **Ningún patrón es el principio de otro.** Los dos primeros pulsos ya identifican el evento (L = largo, C = corto, XL = muy largo).
- La repetición de un evento se anuncia siempre como **«Repetición: …»**. **El resumen nunca vibra.**
- **Pulsos reforzados** (para quien tiene poca sensibilidad táctil, como Manuel): los pulsos duran ×1,5 y las pausas no cambian.

| Evento | Patrón (ms) | Ritmo | Total | Con pulsos reforzados | Quién lo emite |
|---|---|---|---|---|---|
| Gol | `[600,150,600,150,600]` | L-L-L | 2,1 s | `[900,150,900,150,900]` | Accesorio (o móvil en beta) |
| Gol anulado | `[1200,200,150,100,150]` + voz «Gol anulado» | XL-C-C | 1,8 s | `[1800,200,225,100,225]` | Accesorio (o móvil en beta) |
| Falta | `[150,100,150]` | C-C | 0,4 s | `[225,100,225]` | Accesorio (o móvil en beta) |
| Córner | `[150,100,500]` | C-L | 0,75 s | `[225,100,750]` | Accesorio (o móvil en beta) |
| Penalti | `[500,150,150,150,500]` | L-C-L | 1,45 s | `[750,150,225,150,750]` | Accesorio (o móvil en beta) |
| Aviso técnico | `[80,80,80,80,80,80,80]` | 4 pulsos rápidos | 0,56 s | `[120,80,120,80,120,80,120]` | **Siempre el móvil**. Además el accesorio, solo si sigue conectado y lo que falla es internet |
| Confirmación de ajuste | `[60]` | 1 toque | 0,06 s | `[100]` | Móvil |

El patrón de gol anulado de nuestra propuesta inicial, `[600,150,600]`, coincidía con el principio del patrón de gol: para distinguirlos había que notar que faltaba el último pulso. Se sustituyó por uno que empieza de forma distinta.

## 13. Mockups

### 13.1 Estado de los mockups

Los mockups se generan en Google Stitch a partir de la especificación de pantallas (Anexo A) y de los prompts preparados (Anexo B). **[PENDIENTE: generar los mockups en Stitch e insertar las capturas en los huecos siguientes]**. Deben aplicar ya los cambios de la Iteración 2 (apartado 18).

Cubren los mínimos del enunciado: pantalla de inicio o acceso (Bienvenida e Inicio), pantallas de flujo crítico (Conectar accesorio, Práctica, Entorno, Partido, Aviso de conexión) y pantalla de confirmación o cierre (Sesión finalizada).

### 13.2 Pantallas y texto alternativo

Cada hueco indica la imagen que falta y el texto alternativo que debe llevar en el PDF.

| Pantalla | Imagen | Texto alternativo |
|---|---|---|
| P01 Bienvenida | [CAPTURA: Bienvenida] | Pantalla de bienvenida con el título «Bienvenida a Football Vibration», una frase que explica que son tres preguntas y un único botón, «Empezar», en la parte inferior. |
| P02 Cuestionario | [CAPTURA: Cuestionario, paso 1] | Paso 1 de 3 del cuestionario. Pregunta «¿Cuál es tu grado de visión?» con tres opciones grandes; «Veo con dificultad» está elegida, con borde grueso y la palabra «Seleccionado». Debajo, el botón «Siguiente». |
| P02 Cuestionario (error) | [CAPTURA: Cuestionario con error] | El mismo paso sin ninguna opción elegida. Bajo las opciones, un mensaje con icono de aviso: «Elige una opción para continuar». |
| P03 Perfil propuesto | [CAPTURA: Perfil propuesto] | Pantalla «Tu perfil propuesto: baja visión» con el resumen de las tres respuestas, una frase que explica qué cambiará en la app y los botones «Personalizar» y «Aceptar y guardar». |
| P04 Inicio (sin conectar) | [CAPTURA: Inicio sin accesorio] | Pantalla Inicio. Arriba a la derecha, el botón «Estado». Un aviso con icono indica «Accesorio sin conectar». Botones «Conectar accesorio», «Seguir solo con el móvil» con la etiqueta «Beta · en desarrollo» y «Configuración». |
| P04 Inicio (conectado) | [CAPTURA: Inicio con accesorio] | Pantalla Inicio con el mensaje «Accesorio conectado. Batería al 90 %» y el botón principal «Elegir partido». |
| P05 Conectar: buscando | [CAPTURA: Conectar, buscando] | Pantalla «Conectar accesorio» con el texto «Buscando tu accesorio. Enciéndelo y déjalo cerca del móvil» y el botón «Cancelar». |
| P05 Conectar: prueba | [CAPTURA: Conectar, vibración de prueba] | Pregunta «Tu accesorio acaba de vibrar. ¿La has notado?» con los botones «Sí, la he notado», «No la he notado» y «Repetir vibración». |
| P05 Conectar: conectado | [CAPTURA: Conectar, conectado] | Mensaje con icono de correcto «Accesorio conectado. Batería al 90 %. Aún no has practicado los patrones de vibración» y el botón principal «Practicar los patrones (recomendado)». |
| P05 Conectar: error | [CAPTURA: Conectar, error] | Mensaje con icono de aviso «No encuentro tu accesorio. Comprueba que está encendido y cerca del móvil» y los botones «Reintentar» y «Volver». |
| P06 Vibración y narración | [CAPTURA: Vibración y narración] | Ajustes con botones de menos y más para la intensidad («3 de 5») y el volumen, el interruptor «Pulsos reforzados», tres opciones de nivel de narración y los botones «Practicar patrones» y «Guardar ajustes». |
| P07 Práctica | [CAPTURA: Práctica de patrones] | Pantalla «Práctica: patrón 2 de 5» con el botón grande «Reproducir patrón», la pregunta «¿Qué evento es?» y cinco botones: Gol, Gol anulado, Falta, Córner y Penalti. |
| P07 Resultado | [CAPTURA: Resultado de la práctica] | Pantalla «Resultado: 4 de 5 aciertos» con el texto «Has fallado: córner» y los botones «Repetir los fallados», «Notar todos los patrones» y «Terminar». |
| P08 Elegir partido | [CAPTURA: Elegir partido] | Lista con dos botones grandes: «Atlético contra Betis. Hoy a las 21:00. Aún no ha empezado» y «Sevilla contra Valencia. En juego, minuto 34». |
| P09 Entorno y canales | [CAPTURA: Entorno] | Pregunta «¿Dónde vas a seguir el partido?» con las opciones estadio, casa y bar; «En un bar» está elegida. Un recuadro muestra la propuesta de canales y debajo están «Ajustar» e «Iniciar seguimiento». |
| P10 Ponerse al día | [CAPTURA: Ponerse al día] | Pantalla «El partido ya ha empezado: minuto 34» con el marcador «Sevilla 1, Valencia 0» y los botones «Escuchar resumen», «Escuchar alineaciones» e «Ir al directo». |
| P11 Partido | [CAPTURA: Partido] | Pantalla Partido. Arriba, el marcador en grande y el minuto. Debajo, los controles rápidos: «Repetir último evento», «Pausar vibraciones», «Pausar narración», volumen con botones de menos y más y «Nivel de narración». Después, el último evento, el estado de los datos, «Ajustes del partido» y «Finalizar sesión». |
| P12 Ajustes del partido | [CAPTURA: Ajustes del partido] | Opciones de entorno (estadio, casa, bar), la propuesta de canales y los botones «Vibración y narración», «Recordar los patrones» y «Guardar y volver al partido». |
| P13 Estado del sistema | [CAPTURA: Estado del sistema] | Lista de cinco estados con icono y texto: accesorio conectado, batería 62 %, vibraciones activas, narración activa y datos del partido sin actualizar desde el minuto 70. Debajo, «Reintentar conexión». |
| P14 Aviso de conexión | [CAPTURA: Aviso sin internet] | Pantalla Partido con un recuadro de aviso al final: «Sin conexión a internet. Los datos del partido no se están actualizando. Intentando reconectar. El accesorio sigue conectado», con los botones «Reintentar» y «Finalizar sesión». |
| P14 Conexión recuperada | [CAPTURA: Conexión recuperada] | Recuadro con icono de correcto: «Conexión recuperada. Marcador: Atlético 1, Betis 1, minuto 72» y el botón «Cerrar aviso». |
| P15 Final del partido | [CAPTURA: Final del partido] | Pantalla «Final del partido» con el marcador «Atlético 2, Betis 1» y los botones «Escuchar resumen» y «Finalizar sesión». |
| Diálogo de salida | [CAPTURA: Confirmación de salida] | Diálogo «El partido sigue en juego. ¿Quieres salir?» con el botón destacado «Seguir viendo el partido» y, debajo, «Finalizar sesión». |
| P16 Sesión finalizada | [CAPTURA: Sesión finalizada] | Pantalla de cierre con el mensaje «Ajustes guardados. El accesorio está desconectado. Recuerda apagarlo» y el botón «Volver al inicio». |
| P17 Configuración | [CAPTURA: Configuración] | Lista de cinco apartados con su valor actual: Mi perfil, Vibración y narración, Practicar patrones, Accesorio y Repetir el cuestionario. |

De las pantallas Inicio, Partido, Conectar accesorio y Sesión finalizada se entregan los dos temas (estándar y alto contraste). **[PENDIENTE: capturas de los dos temas]**

## 14. Prototipo navegable

### 14.1 Enlace

- Prototipo navegable en Figma o Stitch: **[PENDIENTE: enlace público]**
- Versión web publicada del prototipo funcional: **[PENDIENTE: enlace de GitHub Pages]**
- Además, el prototipo funcional en HTML (apartado 15) es navegable de principio a fin y cubre las diez tareas. Se entrega en la carpeta `prototipo`.

### 14.2 Mapa de navegación

Cada fila es un enlace del prototipo: pantalla de origen, acción, pantalla de destino y respuesta que recibe el usuario.

| Origen | Acción | Destino | Feedback |
|---|---|---|---|
| P01 | «Empezar» | P02 paso 1 | foco en la pregunta |
| P02 paso n | «Siguiente» con opción elegida | P02 paso n+1 (o P03 tras el paso 3) | — |
| P02 paso n | «Siguiente» sin opción | P02 paso n | «Elige una opción para continuar» |
| P02 paso n | «Volver» | paso anterior (o P01) | respuestas conservadas |
| P03 | «Aceptar y guardar» / «Guardar preferencias» | P04 | vibración + «Preferencias guardadas» |
| P03 | «Volver» | P02 paso 3 | — |
| P04 | «Conectar accesorio» | P05 buscando | «Buscando tu accesorio» |
| P04 | «Elegir partido» (accesorio conectado) | P08 | — |
| P04 | «Seguir solo con el móvil (beta)» → «Continuar» | P08 | aviso de función en desarrollo |
| P04 | «Configuración» | P17 | — |
| cualquiera | «Estado» | P13 | «Volver» regresa al origen |
| P05 buscando | encontrado, primera vez | P05 lista → P05 prueba | el accesorio vibra |
| P05 prueba | «Sí, la he notado» | P05 conectado | vibración + «Accesorio conectado» |
| P05 prueba | «No la he notado» | P05 ayuda | «Sube la intensidad o prueba otra vez» |
| P05 buscando | encontrado, ya emparejado | P05 conectado | vibración + «Accesorio conectado» |
| P05 buscando | no encontrado (10 s) | P05 error | «No encuentro tu accesorio…» |
| P05 error | «Reintentar» | P05 buscando | — |
| P05 error | «Volver» | P04 | — |
| P05 conectado | «Usar mis ajustes y elegir partido» | P08 | — |
| P05 conectado | «Ajustar vibración y narración» | P06 | — |
| P06 | «Practicar patrones» | P07 | — |
| P06 | «Guardar ajustes» | pantalla de origen (P05, P09, P12 o P17) | «Ajustes guardados» |
| P06 | «Volver» con cambios | diálogo de guardar | «Tienes cambios sin guardar» |
| P07 | «Terminar» | P06 | resultado guardado |
| P08 | elegir partido → «Confirmar partido» | P09 | «Has elegido…» |
| P09 | «Ajustar» | P06 | — |
| P09 | «Iniciar seguimiento» (partido sin empezar) | P11 | «Seguimiento iniciado» |
| P09 | «Iniciar seguimiento» (partido empezado) | P10 | «El partido ya ha empezado» |
| P10 | «Ir al directo» | P11 | — |
| P11 | controles rápidos | P11 | vibración + mensaje de confirmación |
| P11 | «Ajustes del partido» | P12 | el seguimiento continúa |
| P12 | «Guardar y volver al partido» | P11 | «Ajustes guardados» |
| P11 | fallo de internet o del accesorio | P11 + P14 | aviso técnico en el móvil + voz + texto |
| P14 | «Reintentar» | P11 (o P14 «Todavía sin conexión») | «Conexión recuperada. Marcador…» |
| P14 | «Volver a conectar el accesorio» | P05 buscando → P11 | se conserva el partido |
| P11 | «Finalizar sesión» (en juego) | diálogo → P11 o P15 | «El partido sigue en juego» |
| P11 | final del partido | P15 | «Final del partido. Atlético 2, Betis 1» |
| P15 | «Finalizar sesión» → «Finalizar» | P16 | vibración + «Sesión finalizada» |
| P16 | «Volver al inicio» | P04 | accesorio sin conectar |
| P17 | cada apartado | P03 / P06 / P07 / P05 / P02 | — |

**Recorridos mínimos del prototipo navegable:** primer acceso (P01 → P04), uso habitual (P04 → P05 → P08 → P09 → P11), partido empezado (P09 → P10 → P11), fallo y recuperación (P11 → P14 → P11) y cierre (P11 → P15 → P16).

Recorridos mínimos: primer acceso (P01 → P04), uso habitual (P04 → P05 → P08 → P09 → P11), partido empezado (P09 → P10 → P11), fallo y recuperación (P11 → P14 → P11) y cierre (P11 → P15 → P16).

Cambios de la Iteración 2 que afectan a la navegación:

- **P11 Partido, nuevo orden:** título → marcador → minuto → «Repetir último evento» → «Pausar vibraciones» y «Pausar narración» → volumen → «Nivel de narración: normal · Pulsa para cambiar» → último evento → estado de los datos → línea «⏸ Vibraciones en pausa» (si aplica) → «Ajustes del partido» → «Finalizar sesión» (sola y separada).
- **P14 Aviso de conexión:** aparece **debajo** de la pantalla, no encima. No se cierra solo. Nueva variante: «Batería del accesorio baja: 15 %. Puede apagarse antes de que acabe el partido.»
- **P05 Conectar accesorio, estado Conectado (primera vez):** mensaje «Aún no has practicado los patrones de vibración.» y botones «Ajustar vibración y narración», «Elegir partido sin practicar» y «Practicar los patrones (recomendado)» como principal.
- **P07 Práctica:** si se responde sin reproducir: «Primero pulsa «Reproducir patrón».»
- **P08 Elegir partido:** el equipo elegido la última vez viene marcado.
- **P12 Ajustes del partido:** nuevo botón «Recordar los patrones».
- **P14, reintento fallido:** «Todavía sin conexión. Sigo intentándolo; te avisaré cuando vuelva.»
- **Botón «atrás» del sistema:** equivale a «Volver»; en Partido abre la confirmación de salida.

### 14.3 Capturas del prototipo

Capturas del prototipo funcional (Iteración 2), tomadas a 412 × 915 px. **[PENDIENTE: añadir las capturas del prototipo de Figma o Stitch]**

![Pantalla de bienvenida en el tema estándar: título, frase de presentación y botón «Empezar».](capturas/iter3/01-bienvenida-estandar.png)

![Paso 1 del cuestionario con el error «Elige una opción para continuar» bajo las tres opciones, que aparecen con borde discontinuo.](capturas/iter3/02-cuestionario-error.png)

![Pantalla Inicio en alto contraste: fondo negro, texto blanco, marca de la app arriba, aviso «Accesorio sin conectar» y botón amarillo «Conectar accesorio» con icono.](capturas/iter3/04-inicio-contraste.png)

![Pantalla Conectar accesorio con el mensaje «No encuentro tu accesorio. Comprueba que está encendido y cerca del móvil» y los botones «Reintentar» y «Volver».](capturas/iter3/05-conectar-error.png)

![Práctica de patrones: tras responder, aparece la corrección con icono y texto y el botón «Siguiente».](capturas/iter3/07-practica-test.png)

![Pantalla Partido en alto contraste: tablero negro con borde amarillo y el marcador «Atlético 0, Betis 0», minuto 8, controles rápidos con icono y, debajo, el último evento «Falta del Betis».](capturas/iter3/11-partido-contraste.png)

![Pantalla Partido sin conexión: los controles siguen en su sitio, el estado indica «Sin actualizar desde el minuto 69» y al final hay un recuadro de aviso con «Reintentar» y «Finalizar sesión».](capturas/iter3/14-aviso-sin-internet.png)

![Recuadro de aviso con icono de correcto: «Conexión recuperada. Marcador: Atlético 1, Betis 1, minuto 72».](capturas/iter3/14-aviso-recuperada.png)

![Diálogo «El partido sigue en juego. ¿Quieres salir?» con el foco en «Seguir viendo el partido».](capturas/iter3/15-dialogo-partido-en-juego.png)

![Pantalla Sesión finalizada: «Ajustes guardados. El accesorio está desconectado. Recuerda apagarlo» y botón «Volver al inicio».](capturas/iter3/16-sesion-finalizada.png)

## 15. Desarrollo funcional

### 15.1 Qué se ha construido

Un prototipo web móvil en HTML, CSS y JavaScript, sin dependencias ni compilación. Se abre con doble clic en `index.html` o con un servidor local (`node servidor.js`, puerto 8080). Las instrucciones están en `prototipo/README.md`.

Cumple lo que pide el enunciado: tiene un **formulario real con validaciones** (el cuestionario de perfil) y una **pantalla con datos simulados** (el partido, con marcador, eventos y estado de la conexión).

| Requisito del encargo | Dónde está |
|---|---|
| Formulario de perfil con validación, error asociado (`aria-describedby`), foco en el primer error y resumen antes de guardar | `js/pantallas-perfil.js` (P02, P03) y `FV.validar` en `js/app.js` |
| Persistencia en `localStorage` con `try/catch` | `js/almacen.js` |
| Partido con datos simulados: balón, goles, faltas, córners, penalti, gol anulado, descanso con cambio de campo, corte de conexión y recuperación | `js/partido.js` y `data/partido-simulado.json` |
| Controles rápidos con confirmación por voz y texto | `js/pantallas-partido.js` (P11) |
| Narración con `speechSynthesis`, región `aria-live="polite"` y `role="alert"` solo para fallos | `js/voz.js`, `index.html` |
| Vibración con comprobación de compatibilidad | `js/patrones.js` |
| Dos temas, `prefers-reduced-motion` y `prefers-contrast` | `css/estilos.css`, arranque en `js/app.js` |
| Simulador del accesorio | `js/simulador.js` |
| HTML semántico, un `h1` por pantalla, gestión del foco, teclado, `lang="es"` | `index.html`, `js/app.js` |

### 15.2 Simulador del accesorio

El simulador es una herramienta de prueba y no forma parte del producto. Va en un panel separado, con borde discontinuo y la etiqueta «HERRAMIENTA DE PRUEBA · no forma parte de la app». Muestra un mini campo con la posición del balón y su descripción en texto, lleva un registro de los patrones emitidos y permite lanzar eventos y provocar fallos (cortar internet, desconectar el accesorio, batería baja).

La vibración usa `navigator.vibrate()`, que funciona en Chrome para Android. En iPhone no existe: allí el patrón solo se ve en el registro.

### 15.3 Verificación

Se ha ejecutado un recorrido automático de las diez tareas **solo con teclado** (Tab, Enter, Espacio, flechas y Escape) en Chromium, con ventana de 412 × 915 px.

- Tras la Iteración 2: **126 comprobaciones superadas y ninguna fallida**. Sin errores ni avisos en la consola.
- Al entrar en cada pantalla, el foco va al título. Los diálogos reciben el foco y se cierran con Escape.
- Ningún botón ni opción mide menos de 48 × 48 px.
- Sin desplazamiento horizontal al 200 % de zoom.

**Contraste medido**

| Par | Tema estándar | Tema alto contraste |
|---|---|---|
| Texto sobre el fondo | 15,09 : 1 | 21,00 : 1 |
| Texto sobre tarjetas | 16,44 : 1 | 21,00 : 1 |
| Texto del botón principal y del tablero | 10,34 : 1 | 14,67 : 1 |
| Bordes de los controles | 9,49 : 1 | 21,00 : 1 |
| Mensajes de error | 7,48 : 1 | 9,20 : 1 |
| Mensajes de estado correcto | 9,49 : 1 | 16,25 : 1 |
| Indicador de foco sobre el fondo | 7,92 : 1 | 13,65 : 1 |

Todos superan 7 : 1.

**Comportamientos comprobados**

- La validación del cuestionario muestra el error, marca el grupo como no válido y lleva el foco a la primera opción. «Volver» conserva las respuestas.
- La palabra «conectado» no aparece hasta que el accesorio lo está. El error de conexión no usa tecnicismos.
- Con «Pulsos reforzados», el gol se emite como `[900,150,900,150,900]` y la falta como `[225,100,225]`.
- Con las vibraciones en pausa, el córner no vibra y se avisa: «Córner para el Atlético. Vibraciones en pausa.»
- La repetición empieza por «Repetición:». Sin eventos responde «Aún no hay ningún evento.»
- En la segunda parte se anuncia: «Tu equipo ataca ahora hacia la izquierda.»
- Al perder internet, el aviso técnico se emite en el móvil y en el accesorio. Si se desconecta el accesorio, solo en el móvil.
- El gol que ocurre durante el corte no vibra. Al reconectar solo hay una confirmación y el mensaje «Conexión recuperada. Marcador: Atlético 1, Betis 1, minuto 72.»
- El resumen empieza por «Resumen», se muestra en pantalla y no vibra. Un evento lo interrumpe con «En directo:» y el botón pasa a «Continuar resumen».
- «Finalizar sesión» con el partido en juego pone el foco en «Seguir viendo el partido».

### 15.4 Lo que no se ha verificado

- **No se ha probado con VoiceOver ni TalkBack reales**, ni en un móvil físico. **[PENDIENTE: prueba en un Android con TalkBack y en un iPhone con VoiceOver]**
- La vibración y la voz se han comprobado por el registro del simulador y por el código, no notándolas ni oyéndolas.
- El rendimiento solo se ha medido en una **simulación** de móvil modesto (procesador 6 veces más lento y red 3G rápida), no en un móvil real: 167 KB transferidos, primer contenido en 1,0 s, página cargada en 1,6 s y cambios de pantalla de entre 0,2 y 0,5 s. No se encontró ningún cuello de botella claro.
- Se hizo una revisión de código propia que corrigió dos problemas: un diálogo que quedaba abierto al terminar el partido y dos valores guardados que se insertaban en la página sin escapar.

## 16. Uso de IA generativa

### Tabla de prompts y resultados

| # | Herramienta | Prompt exacto usado | Resultado obtenido (fragmento) | Qué modificamos nosotros y por qué |
|---|---|---|---|---|
| 1 | Claude Code (extensión de VS Code) | «Actúa como diseñador/a de interacción especializado en accesibilidad y como desarrollador/a front-end. […] FASE 0 — Revisión de coherencia de la P1 (hazla primero y entrégamela como lista). Detecta y propone la corrección de las incoherencias. Como mínimo: 1. Tarea 6: el evento se reconoce PRINCIPALMENTE por el patrón de vibración […]» | Lista de 24 incoherencias en `fase0.md`, con el texto de sustitución. Ejemplo: *«9.5.2 […] el **móvil** avisa al momento con su propia vibración (patrón de aviso técnico), un mensaje de voz y un texto en pantalla […]. El aviso nunca depende del accesorio háptico.»* | Indicamos que las correcciones fueran en un documento aparte y no en la memoria de la P1 («si debes modificar o añadir documentacion hazlo en un documento a parte no en la memoria de la practica 1»). **[PENDIENTE: qué correcciones trasladamos finalmente a la memoria]** |
| 2 | Claude Code | «SISTEMA DE PATRONES […] Deben ser claramente distinguibles en ritmo y duración, no solo en intensidad, porque Manuel tiene menos sensibilidad táctil. Propuesta de partida (puedes justificar ajustes): Gol: [600,150,600,150,600] · Gol anulado: [600,150,600] […]» | La IA detectó que nuestro patrón de gol anulado era el principio exacto del de gol y propuso otro: `golAnulado: { nombre: 'Gol anulado', ms: [1200, 200, 150, 100, 150], ritmo: 'muy largo, corto, corto' }` | Aceptamos el cambio y la opción «Pulsos reforzados» («Y la tercera si»). Decidimos nosotros que «Seguir solo con el móvil» apareciera como beta: «puedes poner en desarrollo beta o algo parecido indicando que no esta hecha al 100%». |
| 3 | Claude Code | «FASE 1 — Escenarios enriquecidos (uno por cada tarea T1–T10). Para cada tarea, redacta un escenario narrativo realista (150–250 palabras) usando los perfiles de la P1 […] al menos un obstáculo o error y cómo lo resuelve la interfaz, y el criterio de éxito medible […]» | Diez escenarios en `fase1.md` y tabla de trazabilidad. Ejemplo de criterio: *«identifica el córner y el gol a la primera y solo por la vibración»*. | **[PENDIENTE: cambios de redacción hechos por el grupo]** |
| 4 | Claude Code | «FASE 2 — Especificación de pantallas y mockups. 1. Define un sistema visual mínimo: dos temas […] contraste mínimo 7:1 en texto, tipografía escalable (rem, con soporte para 200 %), objetivos táctiles ≥ 48×48 dp, estados comunicados con texto + icono […] 4. Para cada pantalla, escribe un PROMPT listo para pegar en Google Stitch […]» | `spec-pantallas.md`: 17 fichas de pantalla con orden de foco y etiquetas, mapa de navegación y un prompt de Stitch por pantalla. | Elegimos el nombre y los datos: «Football Vibration es el nombre», «equipos reales evidentemente». Decidimos generar primero el código y después los mockups. |
| 5 | Claude Code | «FASE 3 — Primer desarrollo funcional (código). Construye un prototipo web móvil en HTML + CSS + JavaScript vanilla, sin build, que se abra con index.html. […] Formulario funcional de perfil con validaciones (campos obligatorios, mensajes de error asociados con aria-describedby, foco al primer error, resumen antes de guardar), con persistencia en localStorage envuelta en try/catch. […]» | Carpeta `/prototipo`. Ver los fragmentos del apartado 2. | **[PENDIENTE: cambios manuales en el código, si los hay]** |
| 6 | Claude Code | «FASE 5 — Iteraciones y análisis heurístico. Iteración 1: evalúa los mockups y el prototipo inicial con: las 10 heurísticas de Nielsen […] Sé crítico: busca problemas reales, no rellenes. Iteración 2: aplica las correcciones al diseño y al código […]» | `fase5.md` y los cambios de código de la Iteración 2 (17 correcciones). | **[PENDIENTE: correcciones añadidas por el grupo tras el feedback]** |
| 7 | Google Stitch | **[PENDIENTE: prompt pegado; los prompts preparados están en `spec-pantallas.md`, apartado 3]** | **[PENDIENTE: captura del mockup generado]** | **[PENDIENTE: qué se ajustó a mano y por qué (p. ej. contraste, tamaño de botones, textos)]** |
| 8 | Figma (prototipado) | **[PENDIENTE]** | **[PENDIENTE: enlace público al prototipo navegable]** | **[PENDIENTE]** |
| 9 | GitHub Copilot / ChatGPT | **[PENDIENTE: prompt, si se usa]** | **[PENDIENTE: fragmento de código]** | **[PENDIENTE]** |

### Fragmentos de código obtenidos

**Validación del formulario** (`prototipo/js/app.js`): campo obligatorio, error asociado y foco en el primer error.

```js
FV.validar = function (formulario) {
  var primero = null;
  formulario.querySelectorAll('fieldset[data-obligatorio]').forEach(function (grupo) {
    var valido = !!grupo.querySelector('input:checked');
    marcarGrupo(grupo, valido);
    if (!valido && !primero) primero = grupo.querySelector('input');
  });
  // Foco en el primer campo con error: el lector lee la opción y, por aria-describedby, el mensaje.
  if (primero) primero.focus();
  return !primero;
};
```

**Persistencia con `try/catch`** (`prototipo/js/almacen.js`):

```js
FV.guardarPrefs = function () {
  try {
    localStorage.setItem(CLAVE, JSON.stringify(FV.prefs));
    return true;
  } catch (e) {
    return false;
  }
};
```

**Vibración con comprobación de compatibilidad** (`prototipo/js/patrones.js`):

```js
/* Comprobación de compatibilidad: en iOS (Safari) navigator.vibrate no existe. */
FV.vibracionDisponible = typeof navigator !== 'undefined' && typeof navigator.vibrate === 'function';
...
if (origen === 'accesorio') {
  if (s.soloMovil) origen = 'movil';          // modo beta: los eventos vibran en el móvil
  else if (!conectado) return false;          // un accesorio desconectado no puede vibrar (R9.5.2)
}
```

**Reconexión sin avisos acumulados** (`prototipo/js/partido.js`):

```js
/* Sin internet los eventos no llegan: no vibran ni se narran.
   Al recuperar la conexión NO se reproducen (R9.5.3); solo se anuncia el marcador actual (D-07). */
if (!e.internet) return;
```

### Reflexión

#### Ventajas
- **Rapidez para pasar de requisitos a algo que se puede probar.** En una sesión se obtuvieron la revisión de la P1, los escenarios, la especificación y un prototipo navegable.
- **Coherencia entre documentos.** La IA trabajó siempre contra los mismos archivos (`patrones.md`, `spec-pantallas.md`), así que la memoria, las pantallas y el código usan los mismos nombres y textos.
- **Revisión crítica de nuestras propias propuestas.** Detectó que el patrón de gol anulado que propusimos se confundía con el de gol, y que `navigator.vibrate()` no permite regular la intensidad ni funciona en iPhone.
- **Verificación automática.** La IA escribió y ejecutó un recorrido con teclado de las diez tareas, que sirvió para encontrar errores que no se veían leyendo el código.

#### Errores de la IA detectados
Todos estos errores estaban en el código generado y se encontraron al probarlo o al evaluarlo, no al generarlo:

1. **Recuadro de aviso vacío siempre visible.** Un `display: flex` anulaba el atributo `hidden`.
2. **La vista previa del perfil no aplicaba el tema** hasta guardar.
3. **El resumen no se podía continuar** si un evento lo interrumpía en la primera frase.
4. **Los controles rápidos se movían de sitio** cada vez que cambiaba el texto del último evento o aparecía el aviso de conexión. Contradecía el requisito de usarlos sin mirar (R9.2.2), aunque el requisito estaba en el prompt.
5. **El botón «atrás» de Android sacaba de la app**, porque la IA solo programó el botón «Volver» de la pantalla.
6. **Doble anuncio en el lector de pantalla:** el interruptor «Pulsos reforzados» decía el estado en el texto y otra vez con `aria-checked`.
7. **El aviso de «conexión recuperada» se cerraba solo a los 8 segundos**, sin dar tiempo a quien lee despacio.
8. **Las confirmaciones por voz esperaban a que acabase la narración**, así que la respuesta a un botón podía llegar con retraso.
9. **Contrastes calculados «a mano» en la especificación.** Eran aproximados y hubo que medirlos con la fórmula de WCAG (resultaron correctos).
10. **Dos falsos fallos en las pruebas automáticas**, debidos al propio guion de prueba y no a la app.

#### Limitaciones
- **La IA no puede notar una vibración ni oír la voz.** Comprobó los patrones por el registro del simulador. Que se distingan de verdad solo se sabrá con personas (P3).
- **No se ha probado con VoiceOver ni TalkBack.** La IA revisa el marcado y el orden de foco, pero no sabe cómo suena una pantalla con un lector real.
- **Accesibilidad que no aplicó por defecto.** Lo que estaba escrito en el prompt (contraste, tamaños, `aria-live`, foco) lo aplicó. Lo que no estaba escrito, o exigía pensar en el uso real, falló: la estabilidad de la posición de los controles, el botón «atrás» del sistema, los tiempos de lectura y la cola de voz. Una lista de requisitos de accesibilidad no sustituye a la evaluación.
- **Datos inventados con apariencia real.** Las alineaciones y los eventos de los partidos son inventados aunque usen nombres reales. Están marcados como simulados en el JSON y en el README.
- **No inventa lo que no sabe, si se le pide.** Los resultados de la encuesta y el feedback de usuarios se dejaron como pendientes porque el prompt lo exigía; sin esa instrucción, el riesgo de que los rellenase existía.
- **[PENDIENTE: limitaciones observadas por el grupo al usar Stitch, Figma o Copilot]**

## 17. Iteración 1 y análisis

La Iteración 1 comprende la especificación de pantallas y el primer prototipo funcional (carpeta `prototipo-iteracion1`). La evaluación se hizo por inspección, sin usuarios, con las heurísticas de Nielsen, los principios del Diseño Universal, los principios de usabilidad de Dix et al. y la WCAG 2.2 nivel AA. **[PENDIENTE: repetir la evaluación sobre los mockups de Stitch cuando estén generados]**

Escala de gravedad: 0 no es un problema · 1 cosmético · 2 menor · 3 mayor · 4 catástrofe de usabilidad.

### Heurísticas de Nielsen

| Id | Heurística | Pantalla | Problema | Gravedad | Propuesta |
|---|---|---|---|---|---|
| N-01 | 4. Consistencia y estándares · 6. Reconocer antes que recordar | Partido | Los controles rápidos **cambian de posición**: el bloque «Último evento» está encima y ocupa de 1 a 3 líneas según el evento. Quien los usa sin mirar pulsa otro botón. | **4** | Poner encima solo lo que no cambia de tamaño (marcador y minuto) y debajo la información variable. |
| N-02 | 4. Consistencia | Partido + Aviso de conexión | El aviso aparece **encima** de la pantalla y empuja todos los controles varios cientos de píxeles hacia abajo, justo en un momento de confusión. | **3** | Mostrar el aviso debajo de los controles; se sigue anunciando por vibración, voz y `role="alert"`. |
| N-03 | 3. Control y libertad del usuario | Todas | El botón **«atrás» de Android** o del navegador saca de la app y se pierde el partido. Manuel teme «tocar algo y estropearlo». | **3** | Que «atrás» haga lo mismo que «Volver» y, en Partido, pida confirmación. |
| N-04 | 1. Visibilidad del estado | Partido | Con las vibraciones en pausa, lo único que lo indica es que el botón dice «Reanudar vibraciones». El estado hay que deducirlo de la acción. | **3** | Línea de estado fija: «⏸ Vibraciones en pausa». |
| N-05 | 10. Ayuda · Facilidad de aprendizaje | Conectar accesorio | Tras el primer emparejamiento, la acción principal es «Usar mis ajustes y elegir partido». Se puede empezar un partido **sin haber practicado nunca** los patrones, que son el canal principal. | **3** | La primera vez, la acción principal es «Practicar los patrones (recomendado)». |
| N-06 | 5. Prevención de errores | Partido | «Finalizar sesión» está pegado a «Ajustes del partido», con el mismo tamaño y aspecto. | 2 | Separarlo, dejarlo solo y el último. Se mantiene la confirmación. |
| N-07 | 1. Visibilidad del estado | Partido | Las confirmaciones por voz se ponen **en cola** detrás de la narración: se pulsa «Bajar volumen» y la respuesta llega segundos después. | 2 | La confirmación de una acción interrumpe la voz en curso. |
| N-08 | 3. Control y libertad | Aviso de conexión | «Conexión recuperada» **se cierra solo a los 8 s**. Quien lee despacio no llega a leer el marcador. | 2 | No cerrarlo automáticamente. |
| N-09 | 10. Ayuda y documentación | Partido | Si se olvida qué significa un patrón durante el partido, la práctica está a tres pantallas. | 2 | Botón «Recordar los patrones» en Ajustes del partido. |
| N-10 | 5. Prevención de errores | Práctica | Se puede responder sin haber pulsado «Reproducir patrón»: cuenta como fallo y falsea el resultado. | 2 | Pedir que se reproduzca antes de responder. |
| N-11 | 1. Visibilidad del estado | Estado del sistema | La batería del accesorio no baja nunca y **no hay aviso de batería baja**. El requisito R9.3.5 queda sin reflejo. | 2 | Simular el consumo y avisar al bajar del 20 %. |
| N-12 | 3. Control y libertad | Inicio | Tras entrar en «Seguir solo con el móvil» y volver atrás, el modo beta **se queda activado** sin que nada lo indique. | 2 | Desactivarlo al volver a Inicio sin partido. |
| N-13 | 7. Flexibilidad y eficiencia | Elegir partido | «¿Con qué equipo vas?» se pregunta en cada partido, aunque sea siempre el mismo equipo. | 2 | Recordar el equipo y dejarlo marcado. |
| N-14 | 6. Reconocer antes que recordar | Partido | «Nivel de narración: normal» no parece un botón que cambia de valor al pulsarlo; la pista solo estaba para el lector de pantalla. | 1 | Añadir el texto visible «Pulsa para cambiar». |
| N-15 | 9. Ayudar a recuperarse de errores | Aviso de conexión | «Todavía sin conexión» no dice qué pasará después. | 1 | «Sigo intentándolo; te avisaré cuando vuelva.» |
| N-16 | 4. Consistencia | Vibración y narración | El interruptor «Pulsos reforzados» anuncia el estado dos veces con lector de pantalla. | 1 | Dejar el estado escrito solo como información visual. |
| N-17 | 4. Consistencia | Conectar accesorio | Hay dos «Volver»: el de la barra y el del mensaje de error. | 1 | **No se cambia:** la redundancia ayuda a Manuel y la exige el flujo de la P1 («Reintentar» y «Volver»). |
| N-18 | 8. Diseño minimalista | Partido | Diez controles en una pantalla. Supera el máximo de 3–4 acciones fijado en el sistema visual. | 1 | **No se cambia:** es una excepción razonada (D-05). Agruparlos en un menú costaría un toque más a Lucía. |
| N-19 | 2. Relación con el mundo real | Cuestionario | «Otra situación» asigna el perfil de baja visión sin explicarlo hasta el resumen. | 1 | **No se cambia:** el resumen lo explica y se puede personalizar. A validar con usuarios. |

Heurísticas sin problemas destacables: la 2 (lenguaje sin tecnicismos: «No encuentro tu accesorio», no «Bluetooth LE no disponible») y la 9 en los mensajes de error del formulario y de conexión.

### Principios del Diseño Universal

| Principio | Valoración en la Iteración 1 | Problema |
|---|---|---|
| 1. Uso equitativo | Bien. Mismo flujo para los tres perfiles; el modo sin accesorio evita excluir a quien no lo tiene. | — |
| 2. Flexibilidad en el uso | Bien. Dos temas, tres tamaños de texto, tres niveles de narración, voz de la app opcional. | No recuerda el equipo (N-13). |
| 3. Uso simple e intuitivo | Regular. | Se puede empezar sin practicar (N-05). El botón de nivel no se entiende (N-14). |
| 4. Información perceptible | Bien. Cada evento llega por vibración, voz y texto. Estados con texto e icono. | El estado de pausa no es perceptible directamente (N-04). |
| 5. Tolerancia al error | Regular. Hay confirmaciones y «Volver». | El botón «atrás» del sistema (N-03) y la cercanía de «Finalizar sesión» (N-06). |
| 6. Bajo esfuerzo físico | Regular. | Los controles se mueven (N-01, N-02): obliga a mirar y recolocar el dedo. «Estado» queda arriba a la derecha, lejos del pulgar; se mantiene por consistencia. |
| 7. Tamaño y espacio para el uso | Bien. Todos los objetivos miden 48 px o más (medido), con 12 px de separación. | — |

### Principios de usabilidad (Dix et al.)

| Principio | Aspecto | Valoración en la Iteración 1 |
|---|---|---|
| **Facilidad de aprendizaje** | Predictibilidad | Mala en Partido: los controles cambian de sitio (N-01, N-02). Buena en el resto: «Volver» y «Estado» siempre en el mismo lugar. |
| | Sintetizabilidad | Buena: cada acción se confirma con texto, voz y un toque de vibración. Falla con la cola de voz (N-07). |
| | Familiaridad | Buena: botones y opciones estándar, sin gestos propios. Falla el botón «atrás» (N-03). |
| | Consistencia | Buena: la acción principal va siempre la última. |
| **Flexibilidad** | Iniciativa del diálogo | Del usuario casi siempre. El sistema solo interrumpe por eventos y fallos. |
| | Multitarea | Se puede consultar el Estado o cambiar ajustes sin detener el seguimiento. |
| | Sustitutividad | Buena: cada evento tiene tres representaciones equivalentes. |
| | Adaptabilidad | Buena: perfil, entorno y ajustes. Falta recordar el equipo (N-13). |
| **Robustez** | Observabilidad | Regular: no se ve el estado de pausa (N-04) ni hay aviso de batería (N-11). |
| | Recuperabilidad | Buena en ajustes («Descartar») y conexión. Mala ante el botón «atrás» (N-03). |
| | Tiempo de respuesta | Bueno, salvo las confirmaciones en cola (N-07). |
| | Conformidad con la tarea | Buena para T1–T10. T5 depende del accesorio y solo se puede simular. |

### WCAG 2.2 nivel AA

| Criterio | Resultado en la Iteración 1 | Cómo se ha comprobado |
|---|---|---|
| 1.3.1 Información y relaciones | Cumple | Revisión del marcado: `h1` único, `fieldset`, grupos etiquetados. |
| 1.4.1 Uso del color | Cumple | Estados con icono y texto; opción elegida con borde grueso y «Seleccionado». |
| 1.4.3 / 1.4.6 Contraste | Cumple (y alcanza AAA, 7:1) | Medido con la fórmula de WCAG: de 8,15:1 a 21:1. |
| 1.4.4 Cambio de tamaño del texto | Cumple | Texto en `rem`; probado al 200 %. |
| 1.4.10 Reajuste | **Cumple con una reserva** | Sin desplazamiento horizontal a 320 px. Con «Muy grande» y 200 % a la vez sí lo había. |
| 1.4.11 Contraste de elementos no textuales | Cumple | Bordes y foco con los mismos colores que el texto. |
| 2.1.1 Teclado | Cumple | Recorrido automático T1–T10 solo con teclado. |
| 2.2.1 Tiempo ajustable | **No cumple** | El aviso «Conexión recuperada» desaparecía a los 8 s (N-08). |
| 2.3.3 / animaciones | Cumple | Una sola animación, desactivada con `prefers-reduced-motion`. |
| 2.4.3 Orden del foco | Cumple | Orden registrado en Inicio, Vibración y narración y Partido. |
| 2.4.7 / 2.4.11 Foco visible y no oculto | Cumple | Contorno de 3–4 px; no hay elementos fijos que lo tapen. |
| 2.5.8 Tamaño del objetivo | Cumple | Medido: ningún objetivo por debajo de 48 × 48 px. |
| 3.2.2 Al introducir datos | Cumple | Elegir una opción no cambia de pantalla. |
| 3.2.3 Navegación coherente | **Cumple con una reserva** | Los controles de Partido se desplazaban (N-01, N-02). |
| 3.3.1 / 3.3.3 Errores | Cumple | Error en texto, asociado al grupo y con foco en él. |
| 3.3.7 Entrada redundante | **Mejorable** | El equipo se preguntaba cada vez (N-13). |
| 4.1.2 Nombre, función, valor | **Cumple con una reserva** | Doble anuncio en el interruptor (N-16). |
| 4.1.3 Mensajes de estado | Cumple | Regiones `aria-live` y `role="alert"`. |
| Alternativas de entrada | Parcial | Teclado y lector de pantalla. No hay control por voz ni con los botones físicos del móvil. |

**No comprobado:** el comportamiento real con VoiceOver y TalkBack. Los criterios que dependen de ello (1.3.1, 4.1.2, 4.1.3) están evaluados sobre el marcado, no sobre lo que se oye.

## 18. Iteración 2 y análisis

### 18.1 Cambios aplicados

La Iteración 2 corrige los problemas de la evaluación. Los cambios están aplicados en el código (carpeta `prototipo`) y deben reflejarse en los mockups.

| # | Antes (Iteración 1) | Después (Iteración 2) | Heurística o principio | Requisito |
|---|---|---|---|---|
| 1 | En Partido, «Último evento» y el estado de los datos estaban encima de los controles y los desplazaban. | Arriba solo quedan el marcador y el minuto. La información variable va debajo de los controles. | Nielsen 4 y 6 · Predictibilidad · DU 6 | R9.2.2 |
| 2 | El aviso de conexión aparecía encima de la pantalla y empujaba los controles. | Aparece debajo de la pantalla. Comprobado: «Repetir último evento» no se mueve al cortarse internet. | Nielsen 4 · Predictibilidad | R9.2.2, R9.5.2 |
| 3 | El botón «atrás» del móvil sacaba de la app. | Hace lo mismo que «Volver». En Partido abre «El partido sigue en juego. ¿Quieres salir?». | Nielsen 3 · Recuperabilidad · DU 5 | R9.2.3 |
| 4 | El estado de pausa solo se deducía del texto del botón. | Línea fija «⏸ Vibraciones en pausa. Narración en pausa». | Nielsen 1 · Observabilidad · DU 4 | R9.5.1 |
| 5 | Tras el primer emparejamiento se podía ir directo al partido. | Si nunca se ha practicado, la acción principal es «Practicar los patrones (recomendado)». Se puede saltar con «Elegir partido sin practicar». | Nielsen 10 · Facilidad de aprendizaje · DU 3 | R9.3.3, R9.3.2 |
| 6 | «Finalizar sesión» compartía fila con «Ajustes del partido». | Va sola, la última y separada. | Nielsen 5 · DU 5 | R9.2.3 |
| 7 | Las confirmaciones por voz esperaban a que acabase la narración. | La confirmación interrumpe la voz en curso. | Nielsen 1 · Tiempo de respuesta | R9.2.3 |
| 8 | «Conexión recuperada» se cerraba sola a los 8 s. | Permanece hasta que se pulsa «Cerrar aviso». | Nielsen 3 · WCAG 2.2.1 | R9.5.3 |
| 9 | Para recordar un patrón había que ir a Configuración. | «Recordar los patrones» en Ajustes del partido. | Nielsen 10 y 6 | R9.3.3 |
| 10 | Se podía responder en la práctica sin notar el patrón. | Aviso «Primero pulsa "Reproducir patrón"». | Nielsen 5 | R9.3.3 |
| 11 | La batería no cambiaba ni avisaba. | Baja durante el partido y, por debajo del 20 %, el móvil avisa con vibración, voz y texto. Botón «Batería baja» en el simulador. | Nielsen 1 · Observabilidad | R9.3.5, R9.5.1 |
| 12 | El modo beta se quedaba activado al volver a Inicio. | Se desactiva al volver a Inicio sin partido. | Nielsen 3 | R9.2.3 |
| 13 | «¿Con qué equipo vas?» siempre vacío. | Si el equipo de la última vez juega el partido, viene marcado. | Nielsen 7 · Adaptabilidad · WCAG 3.3.7 | R9.4.3, R9.2.1 |
| 14 | «Nivel de narración: normal», sin pista visible. | Añade «Pulsa para cambiar». | Nielsen 6 · DU 3 | R9.4.1 |
| 15 | «Todavía sin conexión.» | «Todavía sin conexión. Sigo intentándolo; te avisaré cuando vuelva.» | Nielsen 9 | R9.5.2 |
| 16 | El interruptor decía el estado dos veces. | El estado escrito es solo visual; el lector usa `aria-checked`. | Nielsen 4 · WCAG 4.1.2 | R9.1.1 |
| 17 | Filas de dos botones con rejilla fija; se desbordaban con el texto muy ampliado. | Filas flexibles que pasan a una columna cuando no caben. | WCAG 1.4.10 · DU 2 | R9.1.2 |

Cambios correspondientes en el diseño (para los mockups): en la pantalla Partido, el orden pasa a ser marcador → minuto → controles rápidos → último evento → estado de datos y pausas → «Ajustes del partido» → «Finalizar sesión» → aviso de conexión. En Conectar accesorio (primera vez), el botón principal es «Practicar los patrones (recomendado)».

### 18.2 Problemas que quedan abiertos

| Id | Problema | Por qué no se ha resuelto |
|---|---|---|
| N-17 | Dos «Volver» en Conectar accesorio. | Decisión de diseño: redundancia útil. |
| N-18 | Diez controles en Partido. | Excepción razonada (D-05). A validar con usuarios. |
| N-19 | «Otra situación» en el cuestionario. | A validar con usuarios. |
| — | «Estado» queda lejos del pulgar. | Se prioriza la posición fija. A validar en la P3. |
| — | Sin prueba con VoiceOver ni TalkBack reales. | Requiere un móvil y una persona. **[PENDIENTE]** |
| — | Caso extremo de zoom: «Muy grande» + 200 % en 412 px. | Resuelto con el acabado visual (apartado 18.4): ya no hay desplazamiento horizontal en las pantallas medidas. |
| — | Alternativas de entrada (voz, botones físicos). | Fuera del alcance de la web del prototipo. |

### 18.3 Verificación tras la Iteración 2

Se repitió el recorrido automático con teclado, ampliado con comprobaciones nuevas: los controles no se mueven al aparecer el aviso de conexión, el estado de pausa es visible, la práctica exige reproducir el patrón antes de responder, el aviso de batería baja sale del móvil y el botón «atrás» pide confirmación en Partido. Resultado: 126 comprobaciones superadas, ninguna fallida.

### 18.4 Acabado visual

Después de la Iteración 2 se mejoró el aspecto del prototipo sin tocar la estructura, los textos ni el orden de foco.

| Qué cambia | Por qué no reduce la accesibilidad |
|---|---|
| Tema estándar en verde césped sobre fondo claro, con tarjetas blancas. | Contraste medido por encima de 7:1 en todos los pares (apartado 15.3). |
| Tablero destacado para el marcador y el minuto. | Mismo texto y misma posición. En alto contraste es negro con borde amarillo. |
| Iconos de línea en los botones. | Son decorativos: el lector de pantalla no los lee y el texto sigue presente. |
| Emblema y marca de la app. | Ocultos al lector de pantalla, no interactivos y sin desplazar ningún botón. |
| Barra de progreso en el cuestionario. | Decorativa; el paso se lee en el título. |
| Radios grandes dibujados a medida. | Siguen siendo controles nativos. |
| Tipografía Atkinson Hyperlegible incluida en el proyecto. | Diseñada para baja visión; ya no depende de que esté instalada. |
| Canto inferior en los botones, que bajan 2 px al pulsar. | No es una animación; con movimiento reducido no se mueven. |

Tras el cambio se repitió la verificación: 126 comprobaciones superadas, ninguna fallida, y sin desplazamiento horizontal ni siquiera con texto «Muy grande» y 200 % de zoom a la vez. **[PENDIENTE: opinión de usuarios con baja visión sobre los dos temas]**

### 18.5 Criterios de éxito de la Práctica 1

| Criterio de la P1 | Estado en la P2 | Qué falta |
|---|---|---|
| **Puesta en marcha autónoma en menos de 2 minutos** (uso habitual, D-04) | El diseño lo permite con **5 pulsaciones**: «Conectar accesorio» → «Usar mis ajustes y elegir partido» → partido → «Confirmar partido» (equipo ya marcado) → «Iniciar seguimiento» (entorno ya marcado). La búsqueda del accesorio se ha estimado en 10 s como máximo. | **No se ha medido con personas.** Con lector de pantalla hay más gestos por pantalla. Medir el tiempo real en la P3 con los tres perfiles. |
| **Reconocimiento de patrones superior al 95 %** | Es un **objetivo a validar en la P3**, no un resultado. El diseño lo favorece: ningún patrón es el principio de otro, hay práctica guiada con repetición de los fallados, «Pulsos reforzados» y repetición del último evento. | Prueba con usuarios: porcentaje de aciertos tras la práctica, por patrón y por perfil. Prestar atención a falta frente a córner y a gol frente a penalti. |
| **Control y retorno seguro** | Cumplido en el prototipo: «Volver» y «Estado» en posición fija, botón «atrás» del sistema, confirmación al salir sin guardar y al finalizar con el partido en juego, opción segura con el foco inicial, estado consultable en cualquier momento. | Comprobar con Manuel que entiende los diálogos de confirmación. |

### 18.6 Feedback recibido

No se ha inventado ninguna opinión. Estos apartados se rellenan con el feedback real.

#### Feedback del profesor
- Fecha: **[PENDIENTE]**
- Comentarios: **[PENDIENTE: feedback del profesor]**
- Cambios que provoca: **[PENDIENTE]**

#### Feedback de compañeros
- Fecha y quién: **[PENDIENTE]**
- Comentarios: **[PENDIENTE: feedback de compañeros]**
- Cambios que provoca: **[PENDIENTE]**

#### Prueba informal

| Dato | Valor |
|---|---|
| Fecha y lugar | **[PENDIENTE]** |
| Participante (perfil, sin datos personales) | **[PENDIENTE]** |
| Dispositivo y lector de pantalla | **[PENDIENTE]** |
| Tareas probadas (T1–T10) | **[PENDIENTE]** |
| Tiempo de puesta en marcha habitual | **[PENDIENTE]** |
| Aciertos en la práctica de patrones (X de 5) | **[PENDIENTE]** |
| Problemas observados | **[PENDIENTE: prueba informal]** |
| Cambios que provoca | **[PENDIENTE]** |

#### Cambios derivados del feedback (Iteración 2 bis)

| Feedback | Cambio aplicado | Heurística o principio | Requisito |
|---|---|---|---|
| **[PENDIENTE]** | **[PENDIENTE]** | **[PENDIENTE]** | **[PENDIENTE]** |

## 19. Conclusiones y próximos pasos hacia la Práctica 3

### 19.1 Conclusiones

- **La P1 se sostiene, con correcciones.** La revisión inicial sacó 24 incoherencias. Las dos más importantes afectaban al núcleo del proyecto: el evento se reconoce por la vibración y no por la narración, y el aviso de desconexión sale del móvil.
- **Los patrones se distinguen por ritmo y duración.** Ninguno es el principio de otro y hay una variante de pulsos reforzados para quien tiene menos sensibilidad táctil. Que se reconozcan de verdad está por demostrar.
- **La lista de requisitos no bastó.** El primer prototipo cumplía contraste, tamaños, foco y regiones vivas, y aun así la evaluación encontró 19 problemas. El más grave no aparecía en ninguna lista de comprobación: los controles rápidos cambiaban de sitio con cada evento, lo que impedía usarlos sin mirar.
- **La IA aceleró el trabajo, pero hubo que verificarla.** Generó la especificación y el código con rapidez, pero los errores se encontraron al probar y al evaluar, no al generar.
- **El diseño está listo para probarse con personas**, que es lo que falta.

### 19.2 Próximos pasos hacia la Práctica 3

1. **Probar el prototipo con usuarios de los tres perfiles**, con VoiceOver y TalkBack reales y en móviles físicos.
2. **Medir los criterios de éxito:** tiempo de puesta en marcha habitual (objetivo: menos de 2 minutos) y porcentaje de reconocimiento de patrones tras la práctica (objetivo: más del 95 %), por patrón y por perfil.
3. **Validar las decisiones dudosas:** diez controles en la pantalla Partido, la posición del botón «Estado», la opción «Otra situación» del cuestionario y la recomendación de practicar antes del primer partido.
4. **Completar los pendientes de esta práctica:** resultados de la encuesta, mockups en Stitch, enlace del prototipo navegable y feedback del profesor y de los compañeros.
5. **Decidir el futuro del modo «Seguir solo con el móvil»**, hoy en beta.
6. **Comprobar el rendimiento en un Android de gama baja real**; hasta ahora solo se ha simulado.

### 19.3 Pendientes de esta memoria

| Pendiente | Apartado |
|---|---|
| Resultados de la encuesta (nº de respuestas y canal) | 10.2, fila 5 |
| Mockups de Stitch y sus capturas, en los dos temas | 13 |
| Enlace público del prototipo navegable y sus capturas | 14.1, 14.3 |
| Filas de Stitch, Figma y Copilot en la tabla de IA; cambios manuales del grupo | 16 |
| Evaluación heurística de los mockups | 17 |
| Feedback del profesor, de compañeros y prueba informal | 18.6 |
| Prueba con lector de pantalla y móvil físico | 15.4 |

## Cobertura de los criterios de evaluación

| Criterio del enunciado | Dónde se cumple | Estado |
|---|---|---|
| 1. Calidad narrativa de los escenarios | Apartado 11: diez escenarios, uno por tarea, con contexto, obstáculo, criterio medible y tabla de trazabilidad | Completo |
| 2. Coherencia y completitud de los mockups | Apartado 12 (sistema visual), apartado 13 (pantallas y textos alternativos), Anexo A (especificación) y Anexo B (prompts) | **Faltan las imágenes de los mockups** |
| 3. Funcionamiento y navegabilidad del prototipo | Apartado 14 (mapa de navegación y capturas) y apartado 15 (prototipo funcional verificado) | **Falta el enlace de Figma o Stitch** |
| 4. Evidencia del uso de IA generativa | Apartado 16: tabla de prompts, fragmentos de código y reflexión | Faltan las filas de Stitch, Figma y Copilot |
| 5. Profundidad del análisis heurístico y de accesibilidad | Apartados 17 y 18: Nielsen, Diseño Universal, Dix, WCAG 2.2 AA, tabla antes → después y criterios de la P1 | Falta el feedback real y la prueba con lector de pantalla |
| 6. Calidad y estructura de la memoria | Estructura continua con la P1, tablas con encabezado, textos alternativos, lista de pendientes y lista de comprobación del PDF | Falta maquetar y exportar el PDF |

Entregables del enunciado: memoria en PDF accesible (este documento, por exportar), archivo o enlace del prototipo navegable (**[PENDIENTE]**) y carpeta con el código funcional (`prototipo`, con `prototipo-iteracion1` como versión anterior).

## Lista de comprobación para exportar un PDF accesible

- [ ] **Títulos con estilos reales.** Usar Título 1, Título 2 y Título 3 de Word o Google Docs, no texto en negrita. Sin saltos de nivel.
- [ ] **Idioma del documento:** español (España). Marcar aparte los fragmentos en inglés (prompts de Stitch).
- [ ] **Título del documento** en las propiedades del archivo: «Memoria IPO — Football Vibration».
- [ ] **Texto alternativo en todas las imágenes**, con los textos del apartado 13.2 y 14.3. Marcar como decorativas las que no aporten información.
- [ ] **Tablas con fila de encabezado** marcada como tal y «repetir como fila de encabezado». Sin celdas combinadas ni tablas usadas para maquetar.
- [ ] **PDF etiquetado.** En Word: Guardar como PDF → Opciones → «Etiquetas de la estructura del documento para accesibilidad». No usar «Imprimir a PDF».
- [ ] **Orden de lectura** comprobado en el panel de etiquetas o con un lector de pantalla.
- [ ] **Contraste** de texto de 4,5:1 como mínimo, también en tablas y pies de imagen. No transmitir información solo con el color.
- [ ] **Enlaces con texto descriptivo** («prototipo navegable en Figma»), no «pincha aquí» ni la dirección suelta.
- [ ] **Listas reales** (viñetas y numeración del procesador), no guiones escritos a mano.
- [ ] **Índice generado automáticamente** y marcadores del PDF activados.
- [ ] **Fuente legible** de 11 pt o más, interlineado de 1,15 o superior y texto alineado a la izquierda.
- [ ] **Comprobador de accesibilidad** de Word (Revisar → Comprobar accesibilidad) sin errores, y revisión del PDF con PAC o con el comprobador de Acrobat.
- [ ] **Sustituir todos los [PENDIENTE] y [CAPTURA]** antes de exportar.

## Anexo A. Especificación de pantallas

Fichas de la Iteración 1. Los cambios de la Iteración 2 están en el apartado 18.1 y prevalecen sobre estas fichas. En el orden de foco, [b] es un botón, [r] una opción de selección única, [t] un texto y [h1] el título.

### P01 · Bienvenida
- **Objetivo:** explicar en una frase qué hace la app y empezar el cuestionario. **Tareas:** T1.
- **Contenido:** nombre de la app · frase de bienvenida · botón principal.
- **Foco:**
  1. `[h1]` «Bienvenida a Football Vibration»
  2. `[t]` «Vamos a adaptar la app a tu forma de ver. Son tres preguntas y tardarás menos de un minuto.»
  3. `[b]` «Empezar»
- **Estados:** solo normal. Si ya hay un perfil guardado, esta pantalla no aparece y se abre Inicio.

### P02 · Cuestionario inicial (una pregunta por pantalla)
- **Objetivo:** recoger las tres respuestas que determinan el perfil. **Tareas:** T1. **Es el formulario real con validación del prototipo.**
- **Contenido:** indicador de paso · pregunta · opciones · «Siguiente».
- **Preguntas y opciones:**
  1. «¿Cuál es tu grado de visión?» → «No veo nada» / «Veo con dificultad» / «Otra situación»
  2. «¿Dónde sueles seguir los partidos?» → «En el estadio» / «En casa» / «En un bar» / «En varios sitios»
  3. «¿Usas lector de pantalla, como VoiceOver o TalkBack?» → «Sí, siempre» / «A veces» / «No»
- **Foco:**
  1. `[b]` «Volver» (en el paso 1 vuelve a Bienvenida; en los demás, al paso anterior con la respuesta conservada)
  2. `[h1]` «Paso 1 de 3. ¿Cuál es tu grado de visión?»
  3. `[r]` «No veo nada, opción 1 de 3» … (grupo con `fieldset` y `legend`)
  4. `[b]` «Siguiente»
- **Estados:**
  - Error (pulsar «Siguiente» sin elegir): el foco va al mensaje «⚠ Elige una opción para continuar», que queda asociado al grupo (`aria-describedby`, `aria-invalid`).
  - Éxito: pasa al siguiente paso. No hay avance automático al elegir.

### P03 · Perfil propuesto
- **Objetivo:** revisar el resumen, aceptar el perfil o personalizarlo, y guardar. **Tareas:** T1.
- **Contenido:** nombre del perfil propuesto · resumen de respuestas · qué cambia en la app · acciones.
- **Foco:**
  1. `[b]` «Volver» (al paso 3)
  2. `[h1]` «Tu perfil propuesto: baja visión»
  3. `[t]` «Tus respuestas: veo con dificultad; en un bar; lector de pantalla a veces.»
  4. `[t]` «La app usará alto contraste, letra grande, narración normal y vibración para los eventos.»
  5. `[b]` «Aceptar y guardar»
  6. `[b]` «Personalizar»
- **Personalizar** (misma pantalla, ampliada): tema (Estándar / Alto contraste), tamaño de texto (Normal / Grande / Muy grande), voz de la app (Activada / Desactivada), y «Guardar preferencias».
- **Estados:** éxito → vibración de confirmación + «Preferencias guardadas» y pasa a Inicio.

### P04 · Inicio
- **Objetivo:** punto de partida de cada uso; muestra el estado del accesorio y el siguiente paso. **Tareas:** T2, T4, T9.
- **Contenido:** estado del accesorio · acción principal (cambia según el estado) · acciones secundarias.
- **Foco:**
  1. `[b]` «Estado del sistema»
  2. `[h1]` «Inicio»
  3. `[t]` «Accesorio sin conectar» o «✓ Accesorio conectado. Batería al 90 %»
  4. `[b]` «Conectar accesorio» (si está conectado, este botón pasa a ser «Elegir partido» y es el principal)
  5. `[b]` «Seguir solo con el móvil, beta, función en desarrollo»
  6. `[b]` «Configuración»
- **Estados:** sin conectar / conectado. Con el accesorio conectado, «Elegir partido» ocupa el primer lugar.
- **Beta:** al pulsar «Seguir solo con el móvil» se muestra el aviso «Función en desarrollo. Notarás los eventos en el móvil. La posición del balón necesita el accesorio.» con «Continuar» y «Volver».

### P05 · Conectar accesorio
- **Objetivo:** emparejar (primera vez) o conectar (usos siguientes) sin tecnicismos. **Tareas:** T2.
- **Estados y foco** (el h1 es siempre «Conectar accesorio»; «Volver» siempre primero):

| Estado | Lo que lee el lector, en orden | Acciones |
|---|---|---|
| Buscando | «Buscando tu accesorio. Enciéndelo y déjalo cerca del móvil.» | «Cancelar» |
| Lista (solo la primera vez) | «He encontrado 2 accesorios. Elige el tuyo.» · «Accesorio Táctil 4F21» · «Accesorio Táctil 9A03» | uno por botón |
| Vibración de prueba (solo la primera vez) | «Tu accesorio acaba de vibrar. ¿La has notado?» | «Sí, la he notado» · «No la he notado» · «Repetir vibración» |
| Conectado | «✓ Accesorio conectado. Batería al 90 %.» + vibración de confirmación | «Usar mis ajustes y elegir partido» · «Ajustar vibración y narración» |
| Error: no encontrado | «⚠ No encuentro tu accesorio. Comprueba que está encendido y cerca del móvil.» | «Reintentar» · «Volver» |
| Error: Bluetooth apagado | «⚠ El móvil no puede buscar accesorios. Activa el Bluetooth en los ajustes del móvil.» | «Reintentar» · «Volver» |
| «No la he notado» | «Sube la intensidad o prueba otra vez.» | «Repetir vibración» · «Subir intensidad» · «Volver» |

- **Regla:** la palabra «conectado» no aparece hasta el estado Conectado. En los usos siguientes se pasa de Buscando a Conectado sin lista ni prueba.
- Cada cambio de estado mueve el foco al mensaje del nuevo estado.

### P06 · Vibración y narración (calibración)
- **Objetivo:** ajustar los canales y entrar en la práctica. **Tareas:** T3.
- **Contenido:** intensidad · pulsos reforzados · volumen · nivel de narración · práctica · guardar.
- **Foco:**
  1. `[b]` «Volver»  2. `[b]` «Estado del sistema»
  3. `[h1]` «Vibración y narración»
  4. Intensidad: `[b]` «Bajar intensidad» · `[t]` «Intensidad 3 de 5» · `[b]` «Subir intensidad» · `[b]` «Probar vibración»
  5. `[b]` «Pulsos reforzados, desactivado» (interruptor; ayuda: «Vibraciones más largas, para notarlas mejor»)
  6. Volumen: `[b]` «Bajar volumen» · `[t]` «Volumen 3 de 5» · `[b]` «Subir volumen»
  7. Nivel de narración: `[r]` «Mínima: solo los eventos» / «Normal» / «Detallada»
  8. `[b]` «Practicar patrones»
  9. `[b]` «Guardar ajustes»
- Se usan botones − y + en lugar de deslizadores: son más fáciles con lector de pantalla y con poca precisión.
- **Estados:** cada cambio → vibración de confirmación + «Intensidad 4 de 5». Guardar → «Ajustes guardados».
- **Salir sin guardar:** diálogo «Tienes cambios sin guardar» con «Guardar», «Descartar» y «Seguir editando».

### P07 · Práctica de patrones
- **Objetivo:** aprender a distinguir los cinco patrones. **Tareas:** T3 (y prepara T6).
- **Contenido:** progreso · reproducir · cinco respuestas · resultado.
- **Foco (durante la práctica):**
  1. `[b]` «Volver»
  2. `[h1]` «Práctica. Patrón 2 de 5»
  3. `[b]` «Reproducir patrón»
  4. `[t]` «¿Qué evento es?»
  5. `[b]` «Gol» · «Gol anulado» · «Falta» · «Córner» · «Penalti»
- **Feedback por respuesta:** «✓ Correcto, era córner» o «✗ Era córner. Has elegido falta.» y botón «Siguiente».
- **Resultado:** `[h1]` «Resultado: 4 de 5 aciertos» · `[t]` «Has confundido falta y córner.» (si el fallo se repite: «Puedes activar Pulsos reforzados.») · `[b]` «Repetir los fallados» · `[b]` «Escuchar todos los patrones» · `[b]` «Terminar».
- Antes de practicar hay un modo de aprendizaje: lista de los cinco eventos, cada uno con su botón «Notar el patrón de gol», etc.

### P08 · Elegir partido
- **Objetivo:** elegir el encuentro y confirmar equipos y hora. **Tareas:** T4, T8.
- **Foco:**
  1. `[b]` «Volver»  2. `[b]` «Estado del sistema»
  3. `[h1]` «Elegir partido»
  4. `[b]` «Atlético contra Betis. Hoy a las 21:00. Aún no ha empezado.»
  5. `[b]` «Sevilla contra Valencia. En juego, minuto 34.»
- **Confirmación** (al elegir): «Has elegido Atlético contra Betis, hoy a las 21:00.» · «¿Con qué equipo vas?» `[r]` «Atlético» / «Betis» / «Ninguno» · `[b]` «Confirmar partido» · `[b]` «Elegir otro».
- **Estados:** cargando («Cargando partidos…»), vacío («Hoy no hay partidos disponibles»), error («⚠ No puedo cargar los partidos. Comprueba tu conexión.» + «Reintentar»).

### P09 · Entorno y canales
- **Objetivo:** indicar dónde se ve el partido y aceptar la configuración propuesta. **Tareas:** T4.
- **Foco:**
  1. `[b]` «Volver»  2. `[b]` «Estado del sistema»
  3. `[h1]` «¿Dónde vas a seguir el partido?»
  4. `[r]` «En el estadio» / «En casa» / «En un bar» (preseleccionado el lugar habitual del perfil)
  5. `[t]` «Propuesta para el estadio: vibración fuerte, narración mínima, volumen alto.»
  6. `[b]` «Ajustar»
  7. `[b]` «Iniciar seguimiento»
- **Propuestas:** Estadio → intensidad 5, narración Mínima, volumen 5. Casa → intensidad 3, narración Detallada, volumen 3. Bar → intensidad 4, narración Mínima, volumen 2.
- **Estados:** al cambiar de entorno, la propuesta se actualiza y se anuncia (`aria-live`). No se avanza sola.

### P10 · Ponerse al día
- **Objetivo:** resumen y alineaciones opcionales cuando el partido ya ha empezado. **Tareas:** T8.
- **Foco:**
  1. `[b]` «Volver»  2. `[b]` «Estado del sistema»
  3. `[h1]` «El partido ya ha empezado. Minuto 34»
  4. `[t]` «Sevilla 1, Valencia 0.»
  5. `[b]` «Escuchar resumen»
  6. `[b]` «Escuchar alineaciones»
  7. `[b]` «Ir al directo»
- **Estados:**
  - Reproduciendo: el botón pasa a «Detener resumen». La voz empieza por «Resumen». **No vibra.** El texto del resumen se muestra también en pantalla.
  - Interrupción: si hay un evento, el resumen se detiene, suena el patrón y la voz dice «En directo: falta del Valencia». El botón pasa a «Continuar resumen».

### P11 · Partido
- **Objetivo:** pantalla principal durante el encuentro; ajustes rápidos sin mirar. **Tareas:** T5, T6, T7, T9.
- **Contenido:** marcador y minuto · estado de los datos · último evento · controles rápidos en rejilla fija de 2 columnas · acciones de salida.
- **Foco:**
  1. `[b]` «Estado del sistema»
  2. `[h1]` «Partido. Atlético 1, Betis 0. Minuto 63»
  3. `[t]` «Datos en directo» o «⚠ Sin actualizar desde el minuto 70»
  4. `[t]` «Último evento: córner para el Atlético, minuto 63»
  5. `[b]` «Repetir último evento» (ancho completo, el más grande)
  6. `[b]` «Pausar vibraciones» ↔ «Reanudar vibraciones»
  7. `[b]` «Pausar narración» ↔ «Reanudar narración»
  8. `[b]` «Bajar volumen» · `[b]` «Subir volumen» (entre ambos, «Volumen 3 de 5»)
  9. `[b]` «Nivel de narración: normal. Cambiar»
  10. `[b]` «Ajustes del partido»
  11. `[b]` «Finalizar sesión»
- **Avisos (`aria-live`):**
  - Evento: «Córner para el Atlético» + patrón. Con vibraciones en pausa: «Córner para el Atlético. Vibraciones en pausa.»
  - Repetición: «Repetición: córner para el Atlético» + patrón. Sin eventos: «Aún no hay ningún evento.»
  - Pausas: «Narración en pausa. Las vibraciones siguen activas.» / «Vibraciones en pausa.»
  - Descanso: «Descanso.» · «Empieza la segunda parte. Tu equipo ataca ahora hacia la izquierda.»
- El marcador **no** se anuncia cada minuto: solo cambia el texto. Así el lector no interrumpe continuamente.
- **Modo beta:** bajo el título aparece «Beta: solo móvil. Sin posición del balón.»
- **Finalizar con el partido en juego:** diálogo «El partido sigue en juego. ¿Quieres salir?» con «Seguir viendo el partido» (foco inicial) y «Finalizar sesión».

### P12 · Ajustes del partido
- **Objetivo:** cambios menos frecuentes durante el partido, separados de los controles rápidos. **Tareas:** T4, T7.
- **Foco:** `[b]` «Volver» · `[b]` «Estado del sistema» · `[h1]` «Ajustes del partido» · `[r]` entorno: «En el estadio» / «En casa» / «En un bar» · `[b]` «Vibración y narración» · `[b]` «Guardar y volver al partido».
- **Estados:** el seguimiento no se detiene mientras se está aquí. Guardar → «Ajustes guardados» y vuelve a Partido.

### P13 · Estado del sistema
- **Objetivo:** saber en cualquier momento si todo funciona. **Tareas:** T9.
- **Foco:**
  1. `[b]` «Volver»
  2. `[h1]` «Estado del sistema»
  3. `[t]` «Accesorio: ✓ conectado»
  4. `[t]` «Batería del accesorio: 62 %»
  5. `[t]` «Vibraciones: activas»
  6. `[t]` «Datos del partido: ⚠ sin actualizar desde el minuto 70»
  7. `[b]` «Reintentar conexión» (solo si algo falla)
- **Estados:** todo correcto / fallo de internet / accesorio desconectado («Accesorio: ⚠ desconectado» + «Volver a conectar el accesorio») / sin partido activo. Batería por debajo del 20 %: «⚠ Batería baja: 15 %».

### P14 · Aviso de conexión
- **Objetivo:** avisar del fallo sin que el usuario lo consulte y ofrecer la recuperación. **Tareas:** T9.
- **Forma:** bloque fijo en la parte superior de Partido (`role="alert"`), no una pantalla aparte. No roba el foco, pero queda el primero en el orden de lectura tras el título.

| Variante | Texto que se anuncia | Vibración | Acciones |
|---|---|---|---|
| Falla internet | «⚠ Sin conexión a internet. Los datos del partido no se están actualizando. Intentando reconectar. El accesorio sigue conectado.» | Aviso técnico en el **móvil** y en el accesorio | «Reintentar» · «Finalizar sesión» |
| Falla el accesorio | «⚠ El accesorio se ha desconectado. Seguirás oyendo la narración.» | Aviso técnico **solo en el móvil** | «Volver a conectar el accesorio» · «Seguir solo con el móvil (beta)» · «Finalizar sesión» |
| Reintento fallido | «Todavía sin conexión.» | ninguna | las mismas |
| Recuperada | «✓ Conexión recuperada. Marcador: uno a uno, minuto 72.» | Confirmación | el aviso se cierra solo a los 8 s o con «Cerrar aviso» |

- No se reproducen los patrones atrasados (D-07). Se conservan el partido y los ajustes.

### P15 · Final del partido
- **Objetivo:** anunciar el final y ofrecer el resumen. **Tareas:** T10.
- **Foco:** `[b]` «Estado del sistema» · `[h1]` «Final del partido. Atlético 2, Betis 1» · `[b]` «Escuchar resumen» · `[b]` «Finalizar sesión».
- **Estados:** resumen reproduciéndose («Detener resumen»; empieza por «Resumen»; no vibra; texto visible). «Finalizar sesión» → diálogo «¿Finalizar la sesión?» con «Finalizar» y «Cancelar».

### P16 · Sesión finalizada
- **Objetivo:** confirmar el cierre. **Tareas:** T10. **Es la pantalla de confirmación de cierre de tarea.**
- **Foco:** `[h1]` «Sesión finalizada» · `[t]` «✓ Ajustes guardados. El accesorio está desconectado. Recuerda apagarlo.» · `[b]` «Volver al inicio».
- **Estados:** solo éxito. Vibración de confirmación al entrar.

### P17 · Configuración
- **Objetivo:** ajustes avanzados, separados de los controles rápidos. **Tareas:** T1, T3.
- **Foco:** `[b]` «Volver» · `[b]` «Estado del sistema» · `[h1]` «Configuración» · `[b]` «Mi perfil: baja visión» (→ P03 Personalizar) · `[b]` «Vibración y narración» (→ P06) · `[b]` «Practicar patrones» (→ P07) · `[b]` «Accesorio: Táctil 4F21» (olvidar o emparejar otro) · `[b]` «Repetir el cuestionario».
- **Estados:** «Repetir el cuestionario» pide confirmación: «Se sustituirá tu perfil actual.»

### SIM · Simulador del accesorio (herramienta de prueba)
- **Objetivo:** probar sin hardware. **No forma parte del producto** y no se incluye en los mockups de la app.
- **Forma:** panel separado, debajo de la app en móvil y al lado en escritorio, con borde discontinuo y la etiqueta fija «HERRAMIENTA DE PRUEBA · no forma parte de la app». Plegable. Va **después** de la app en el orden de foco.
- **Contenido:**
  - Mini campo con la posición del balón (dibujo decorativo) y su equivalente en texto: «Balón: campo rival, banda derecha».
  - Registro textual de patrones (`role="log"`): «22:10:05 · Accesorio · Córner · [150,100,500]».
  - Botones para lanzar eventos: «Gol», «Gol anulado», «Falta», «Córner», «Penalti».
  - Botones de fallos: «Cortar internet», «Recuperar internet», «Desconectar accesorio», «Apagar accesorio antes de conectar».
  - «Reproducir partido» / «Pausar partido» y «Borrar registro».
- Reproduce cada patrón con la vibración del móvil cuando el navegador lo permite. Si no, lo indica: «Este navegador no vibra; mira el registro».

## Anexo B. Prompts para Google Stitch

Cada prompt se pega precedido del bloque base del tema que se quiera generar. Están en inglés, con los textos de la interfaz en español.

### Bloque base — tema alto contraste
```
Design a mobile app screen (Android, 412x915) for "Football Vibration", an accessible app that lets blind and low-vision football fans follow a match through a haptic accessory, vibration patterns and audio description. All UI text must be in Spanish (Spain), exactly as given.
Style: accessibility-first, extremely simple, no decoration. Pure black background #000000, white text #FFFFFF, primary buttons filled yellow #FFD400 with black text, secondary buttons black with a 3px white outline. Font: Atkinson Hyperlegible, body 18px, buttons 20px bold, screen title 28px bold. Single column, generous spacing, no cards inside cards, no images, no gradients, no shadows.
Every button is full width, at least 56px tall, with a text label (icons only as a small complement, never alone). Never use colour alone to show a state: always text plus an icon.
Fixed top bar: "Volver" button with left arrow at top left, "Estado" button at top right, both at least 48x48px with visible text. The main action is always the last button at the bottom. Maximum 4 main actions.
```

### Bloque base — tema estándar
```
Same as above, but with this palette: very light green-grey background #F3F6F2, text #10231A, primary buttons filled dark pitch green #0B4A2D with white text, secondary buttons white with a 2px #0B4A2D outline and #10231A text, information cards white with a thin #C3D0C7 border. The score is shown in a dark green #0B4A2D rounded card with white text. Rounded corners (14px), simple line icons next to the button labels.
```
(Pegar el bloque de alto contraste y, a continuación, este párrafo.)

### Prompts por pantalla
```
P01 Bienvenida — No top bar. Title "Bienvenida a Football Vibration". Paragraph "Vamos a adaptar la app a tu forma de ver. Son tres preguntas y tardarás menos de un minuto." One primary button at the bottom: "Empezar".
```
```
P02 Cuestionario — Top bar with "Volver" only. Small text "Paso 1 de 3" with a 3-step text indicator. Title "¿Cuál es tu grado de visión?". Three large radio options as full-width rows with a big radio circle and text: "No veo nada", "Veo con dificultad" (selected, shown with a thick border, filled radio and the word "Seleccionado"), "Otra situación". Primary button "Siguiente". Also generate an error variant: no option selected and a message with a warning icon "Elige una opción para continuar" above the options.
```
```
P03 Perfil propuesto — Top bar with "Volver". Title "Tu perfil propuesto: baja visión". Section "Tus respuestas" with three lines: "Veo con dificultad", "En un bar", "Lector de pantalla: a veces". Paragraph "La app usará alto contraste, letra grande, narración normal y vibración para los eventos." Primary button "Aceptar y guardar", secondary button "Personalizar".
```
```
P04 Inicio — Top bar with only "Estado" at top right (no "Volver"). Title "Inicio". Status line with warning icon: "Accesorio sin conectar". Primary button "Conectar accesorio". Secondary button "Seguir solo con el móvil" with a small text tag "Beta · en desarrollo". Secondary button "Configuración". Also generate a variant where the status line is "Accesorio conectado · Batería 90 %" with a check icon and the primary button is "Elegir partido".
```
```
P05 Conectar accesorio — Top bar "Volver" and "Estado". Title "Conectar accesorio". Generate five state variants of the same screen:
(1) Searching: text "Buscando tu accesorio…" and "Enciéndelo y déjalo cerca del móvil.", secondary button "Cancelar".
(2) Test vibration: text "Tu accesorio acaba de vibrar. ¿La has notado?", primary button "Sí, la he notado", secondary buttons "No la he notado" and "Repetir vibración".
(3) Connected: check icon and text "Accesorio conectado. Batería al 90 %.", primary button "Usar mis ajustes y elegir partido", secondary "Ajustar vibración y narración".
(4) Error: warning icon and text "No encuentro tu accesorio. Comprueba que está encendido y cerca del móvil.", primary button "Reintentar", secondary "Volver".
(5) List: text "He encontrado 2 accesorios. Elige el tuyo." and two full-width buttons "Accesorio Táctil 4F21" and "Accesorio Táctil 9A03".
```
```
P06 Vibración y narración — Top bar "Volver" and "Estado". Title "Vibración y narración". Row "Intensidad" with a large minus button, the text "3 de 5" and a large plus button, and a secondary button "Probar vibración". A large toggle row "Pulsos reforzados" showing the text "Desactivado" and helper text "Vibraciones más largas, para notarlas mejor". Row "Volumen" with minus button, "3 de 5", plus button. Radio group "Nivel de narración": "Mínima: solo los eventos", "Normal" (selected, with the word "Seleccionado"), "Detallada". Secondary button "Practicar patrones". Primary button "Guardar ajustes". No sliders.
```
```
P07 Práctica de patrones — Top bar "Volver". Title "Práctica · Patrón 2 de 5". Large primary button "Reproducir patrón". Text "¿Qué evento es?". Five full-width secondary buttons: "Gol", "Gol anulado", "Falta", "Córner", "Penalti". Also generate a result variant: title "Resultado: 4 de 5 aciertos", text "Has confundido falta y córner.", secondary buttons "Repetir los fallados" and "Escuchar todos los patrones", primary button "Terminar".
```
```
P08 Elegir partido — Top bar "Volver" and "Estado". Title "Elegir partido". Two large full-width buttons, each with two lines of text: "Atlético – Betis" / "Hoy, 21:00 · Aún no ha empezado" and "Sevilla – Valencia" / "En juego · Minuto 34". No club logos. Also generate a confirmation variant: text "Has elegido Atlético – Betis, hoy a las 21:00.", radio group "¿Con qué equipo vas?" with "Atlético", "Betis", "Ninguno", primary button "Confirmar partido", secondary "Elegir otro".
```
```
P09 Entorno y canales — Top bar "Volver" and "Estado". Title "¿Dónde vas a seguir el partido?". Three large radio rows with text and a small icon: "En el estadio" (selected, thick border and the word "Seleccionado"), "En casa", "En un bar". Bordered text block "Propuesta para el estadio: vibración fuerte, narración mínima, volumen alto." Secondary button "Ajustar". Primary button "Iniciar seguimiento".
```
```
P10 Ponerse al día — Top bar "Volver" and "Estado". Title "El partido ya ha empezado · Minuto 34". Large score text "Sevilla 1 – Valencia 0". Secondary buttons "Escuchar resumen" and "Escuchar alineaciones". Primary button "Ir al directo". Also a variant while playing: the first button reads "Detener resumen" and a text block shows "Resumen. Minuto 12: gol de Isaac Romero, uno a cero."
```
```
P11 Partido — Top bar with only "Estado" at top right. Title "Partido". Very large score "Atlético 1 – Betis 0" and "Minuto 63". Status line with check icon "Datos en directo". Bordered block "Último evento: córner para el Atlético, minuto 63". Then the quick controls, always in this order: one full-width primary button "Repetir último evento"; a 2-column row with "Pausar vibraciones" and "Pausar narración"; a row with a large minus button, the text "Volumen 3 de 5" and a large plus button; a full-width secondary button "Nivel de narración: Normal". At the bottom two smaller secondary buttons side by side: "Ajustes del partido" and "Finalizar sesión". Also generate a variant with narration paused: the button reads "Reanudar narración" with a pause icon and a message "Narración en pausa. Las vibraciones siguen activas."
```
```
P12 Ajustes del partido — Top bar "Volver" and "Estado". Title "Ajustes del partido". Radio group "Entorno": "En el estadio", "En casa", "En un bar" (selected, with the word "Seleccionado"). Secondary button "Vibración y narración". Primary button "Guardar y volver al partido".
```
```
P13 Estado del sistema — Top bar "Volver" only. Title "Estado del sistema". Four large rows, each with label, icon and status text: "Accesorio: conectado" (check icon), "Batería del accesorio: 62 %", "Vibraciones: activas", "Datos del partido: sin actualizar desde el minuto 70" (warning icon). Primary button "Reintentar conexión".
```
```
P14 Aviso de conexión — Same layout as the P11 Partido screen, but with a bordered alert block at the top, under the title, with a warning icon and the text "Sin conexión a internet. Los datos del partido no se están actualizando. Intentando reconectar. El accesorio sigue conectado." and two buttons inside it: "Reintentar" (primary) and "Finalizar sesión" (secondary). The status line reads "Sin actualizar desde el minuto 70" with a warning icon. Also generate two variants of the alert: (a) "El accesorio se ha desconectado. Seguirás oyendo la narración." with buttons "Volver a conectar el accesorio" and "Finalizar sesión"; (b) a success alert with check icon "Conexión recuperada. Marcador: 1 – 1, minuto 72." and a button "Cerrar aviso".
```
```
P15 Final del partido — Top bar with only "Estado". Title "Final del partido". Very large score "Atlético 2 – Betis 1". Secondary button "Escuchar resumen". Primary button "Finalizar sesión". Also generate a confirmation dialog variant: text "¿Finalizar la sesión?" with primary button "Finalizar" and secondary "Cancelar", and a second dialog "El partido sigue en juego. ¿Quieres salir?" with primary button "Seguir viendo el partido" and secondary "Finalizar sesión".
```
```
P16 Sesión finalizada — No top bar. Large check icon. Title "Sesión finalizada". Text "Ajustes guardados. El accesorio está desconectado. Recuerda apagarlo." Primary button "Volver al inicio".
```
```
P17 Configuración — Top bar "Volver" and "Estado". Title "Configuración". A simple list of five full-width rows, each a button with a title and a second line with the current value: "Mi perfil" / "Baja visión", "Vibración y narración" / "Intensidad 3 · Narración normal", "Practicar patrones" / "Última práctica: 5 de 5", "Accesorio" / "Táctil 4F21", "Repetir el cuestionario". No toggles on this screen.
```

## Anexo C. Registro de decisiones de diseño

| Id | Fecha | Decisión | Alternativa descartada y motivo | Relación |
|---|---|---|---|---|
| D-01 | 2026-11-14 | Se ofrece **«Seguir solo con el móvil»**: los eventos vibran en el móvil y se mantiene la narración, sin posición táctil del balón. En esta entrega se marca como **«Beta · en desarrollo»**. | Exigir siempre el accesorio. Se descarta porque deja fuera a Lucía, para quien T2 solo es «relevante». | R9.3.1, R9.4.2, diseño universal (flexibilidad) |
| D-02 | 2026-11-14 | Gol anulado → `[1200,200,150,100,150]`. | `[600,150,600]`: es el principio del patrón de gol y obliga a notar la ausencia de un pulso. | R9.3.2, perfil de Manuel |
| D-03 | 2026-11-14 | La intensidad se simula con la duración. Se añade la opción **«Pulsos reforzados»** (pulsos ×1,5). | Un control de intensidad real: `navigator.vibrate()` no lo admite. | R9.4.1, R9.3.2 |
| D-04 | 2026-11-14 | El objetivo de **< 2 min** se aplica al **uso habitual** (abrir → conectar → partido → iniciar). El primer acceso se mide aparte. | Incluir el primer acceso: no es realista y contradice el §3 de la P1. | R9.2.1 |
| D-05 | 2026-11-14 | «Pausar vibraciones», «Pausar narración», volumen, nivel de narración y «Repetir último evento» están **siempre visibles** en la pantalla Partido, sin menú intermedio. | Un panel desplegable de «Controles rápidos»: supone dos toques e incumple el criterio de Lucía. | R9.2.2, R9.2.4, R9.6.1 |
| D-06 | 2026-11-14 | El entorno se cambia en «Ajustes del partido», no en los controles rápidos. | Añadirlo a los controles rápidos: más opciones durante el juego, mal para Manuel. | R9.2.4 |
| D-07 | 2026-11-14 | Al reconectar no se reproducen los patrones atrasados, pero se anuncia **una vez** el estado actual (marcador y minuto). | Silencio total: el usuario podría perderse un gol ocurrido durante el corte. | R9.5.3 |
| D-09 | 2026-11-14 | Los mensajes de la interfaz van a regiones `aria-live` (los lee el lector de pantalla). La app solo los lee con su propia voz si el usuario contestó que **no usa lector**. | Leerlos siempre con la voz de la app: con VoiceOver o TalkBack activos se oirían dos voces a la vez. | R9.1.1, R9.3.1 |
| D-10 | 2026-11-14 | Intensidad y volumen se ajustan con botones − y +, no con deslizadores. | Deslizadores: difíciles con lector de pantalla y con poca precisión (Manuel). | R9.1.1, R9.2.2 |
| D-11 | 2026-11-14 | El aviso de conexión es un bloque dentro de Partido (`role="alert"`), no una pantalla aparte, y no mueve el foco. | Pantalla o diálogo modal: saca al usuario del partido y es un cambio de pantalla inesperado. | R9.2.3, R9.5.2 |
| D-12 | 2026-11-14 | La práctica incluye 5 patrones (se añade el gol anulado). | Mantener 4: el gol anulado es el patrón menos intuitivo y quedaría sin practicar. | R9.3.3 |
| D-13 | 2026-11-14 | Los botones de pausa cambian de texto («Pausar» ↔ «Reanudar») y **no** llevan `aria-pressed`. | Texto cambiante más `aria-pressed`: el lector diría «Reanudar narración, pulsado», que es contradictorio. | Nielsen 1 (visibilidad del estado), R9.1.1 |
| D-14 | 2026-11-14 | La narración se muestra además como **subtítulo** visible, sin ser región viva. | Región viva: el lector de pantalla repetiría lo que ya dice la voz. Sin texto: quien tiene el volumen bajo (Lucía en el bar) no se entera. | R9.6.1, R9.1.2 |
| D-15 | 2026-11-14 | El marcador y el minuto **no** se anuncian en cada cambio; solo se actualiza el texto. | Región viva en el marcador: interrumpiría al usuario cada minuto. | R9.3.1 (sin sobrecarga) |
| D-16 | 2026-11-14 | Prototipo sin compilación ni módulos, con una copia del JSON en `datos-respaldo.js`. | Módulos ES y `fetch` únicamente: no funcionan al abrir `index.html` con doble clic. | Requisito de entrega de la Fase 3 |
| D-17 | 2026-11-14 | **Iteración 2.** En Partido, la información de tamaño variable (último evento, estado de datos, pausas) y el aviso de conexión van **debajo** de los controles rápidos. | Mantenerlos arriba (más visibles): desplazaban los controles en cada evento y rompían el uso sin mirar. | Nielsen 4 y 6, R9.2.2 |
| D-18 | 2026-11-14 | **Iteración 2.** El botón «atrás» del sistema equivale a «Volver» y en Partido pide confirmación. | Ignorarlo: sacaba de la app y se perdía el partido. | Nielsen 3, R9.2.3 |
| D-19 | 2026-11-14 | **Iteración 2.** La primera vez, tras emparejar, la acción principal es practicar los patrones; se puede saltar. | Obligar a practicar: quita control al usuario. No recomendarlo: se llega al partido sin conocer el canal principal. | Nielsen 10, R9.3.3 |
| D-20 | 2026-11-14 | **Iteración 2.** Las confirmaciones por voz interrumpen la narración en curso. | Ponerlas en cola: la respuesta a una acción llegaba tarde. | Nielsen 1, R9.2.3 |
| D-21 | 2026-11-14 | **Iteración 2.** Los avisos de conexión no se cierran solos. | Cierre a los 8 s: quien lee despacio no llega a leerlos (WCAG 2.2.1). | R9.5.3 |
| D-22 | 2026-11-14 | **Acabado visual.** Tema estándar en verde césped con tarjetas, tablero para el marcador, iconos decorativos junto al texto y tipografía Atkinson Hyperlegible incluida. El tema de alto contraste no cambia de colores. | Dejar el aspecto mínimo inicial: era accesible pero parecía un formulario sin identidad. Usar iconos sin texto o fondos con degradado: empeoran la lectura con baja visión. | Nielsen 8 (estética), Diseño Universal 4, R9.1.2 |
| D-08 | 2026-11-14 | Un evento se repite reproduciendo **el patrón y la narración**, que empieza por «Repetición:». | Repetir solo la narración: no sirve para resolver dudas sobre el patrón (T6). | R9.5.4 |
