# Fase 5 — Iteraciones y análisis heurístico

## 0. Qué se ha evaluado

- **Iteración 1:** la especificación de pantallas (`spec-pantallas.md`) y el primer prototipo funcional (copia en `/prototipo-iteracion1`, capturas en `capturas/iter1`).
- **Iteración 2:** el prototipo corregido (`/prototipo`, capturas en `capturas/iter2`).
- **Los mockups de Stitch aún no existen.** Cuando se generen hay que repasarlos con la misma tabla. **[PENDIENTE: evaluación de los mockups de Stitch/Figma]**
- La evaluación la ha hecho la IA como evaluador experto, sin usuarios. **Debe revisarla el grupo** y completarse con el feedback real (apartado 5).

Escala de gravedad de Nielsen: 0 no es un problema · 1 cosmético · 2 menor · 3 mayor · 4 catástrofe de usabilidad.

## 1. Iteración 1 — Evaluación

### 1.1 Heurísticas de Nielsen

| Id | Heurística | Pantalla | Problema | Gravedad | Propuesta |
|---|---|---|---|---|---|
| N-01 | 4. Consistencia y estándares · 6. Reconocer antes que recordar | Partido | Los controles rápidos **cambian de posición**: el bloque «Último evento» está encima y ocupa de 1 a 3 líneas según el evento. Quien los usa sin mirar pulsa otro botón. | **4** | Poner encima solo lo que no cambia de tamaño (marcador y minuto) y debajo la información variable. |
| N-02 | 4. Consistencia | Partido + Aviso de conexión | El aviso aparece **encima** de la pantalla y empuja todos los controles varios cientos de píxeles hacia abajo, justo en un momento de confusión. | **3** | Mostrar el aviso debajo de los controles; se sigue anunciando por vibración, voz y `role="alert"`. |
| N-03 | 3. Control y libertad del usuario | Todas | El botón **«atrás» de Android** o del navegador saca de la app y se pierde el partido. Manuel teme «tocar algo y estropearlo». | **3** | Que «atrás» haga lo mismo que «Volver» y, en Partido, pida confirmación. |
| N-04 | 1. Visibilidad del estado | Partido | Con las vibraciones en pausa, lo único que lo indica es que el botón dice «Reanudar vibraciones». El estado hay que deducirlo de la acción. | **3** | Línea de estado fija: «⏸ Vibraciones en pausa». |
| N-05 | 10. Ayuda · Facilidad de aprendizaje | Conectar accesorio | Tras el primer emparejamiento, la acción principal es «Usar mis ajustes y elegir partido». Se puede empezar un partido **sin haber practicado nunca** los patrones, que son el canal principal. | **3** | La primera vez, la acción principal es «Practicar los patrones (recomendado)». |
| N-06 | 5. Prevención de errores | Partido | «Finalizar sesión» está pegado a «Ajustes del partido», con el mismo tamaño y aspecto. | 2 | Separarlo, dejarlo solo y el último. Se mantiene la confirmación. |
| N-07 | 1. Visibilidad del estado | Partido | Las confirmaciones por voz se ponen **en cola** detrás de la narración: se pulsa «Bajar volumen» y la respuesta llega segundos después. | 2 | La confirmación de una acción interrumpe la voz en curso. |
| N-08 | 3. Control y libertad | Aviso de conexión | «Conexión recuperada» **se cierra solo a los 8 s**. Quien lee despacio no llega a leer el marcador. | 2 | No cerrarlo automáticamente. |
| N-09 | 10. Ayuda y documentación | Partido | Si se olvida qué significa un patrón durante el partido, la práctica está a tres pantallas. | 2 | Botón «Recordar los patrones» en Ajustes del partido. |
| N-10 | 5. Prevención de errores | Práctica | Se puede responder sin haber pulsado «Reproducir patrón»: cuenta como fallo y falsea el resultado. | 2 | Pedir que se reproduzca antes de responder. |
| N-11 | 1. Visibilidad del estado | Estado del sistema | La batería del accesorio no baja nunca y **no hay aviso de batería baja**. El requisito R9.3.5 queda sin reflejo. | 2 | Simular el consumo y avisar al bajar del 20 %. |
| N-12 | 3. Control y libertad | Inicio | Tras entrar en «Seguir solo con el móvil» y volver atrás, el modo beta **se queda activado** sin que nada lo indique. | 2 | Desactivarlo al volver a Inicio sin partido. |
| N-13 | 7. Flexibilidad y eficiencia | Elegir partido | «¿Con qué equipo vas?» se pregunta en cada partido, aunque sea siempre el mismo equipo. | 2 | Recordar el equipo y dejarlo marcado. |
| N-14 | 6. Reconocer antes que recordar | Partido | «Nivel de narración: normal» no parece un botón que cambia de valor al pulsarlo; la pista solo estaba para el lector de pantalla. | 1 | Añadir el texto visible «Pulsa para cambiar». |
| N-15 | 9. Ayudar a recuperarse de errores | Aviso de conexión | «Todavía sin conexión» no dice qué pasará después. | 1 | «Sigo intentándolo; te avisaré cuando vuelva.» |
| N-16 | 4. Consistencia | Vibración y narración | El interruptor «Pulsos reforzados» anuncia el estado dos veces con lector de pantalla. | 1 | Dejar el estado escrito solo como información visual. |
| N-17 | 4. Consistencia | Conectar accesorio | Hay dos «Volver»: el de la barra y el del mensaje de error. | 1 | **No se cambia:** la redundancia ayuda a Manuel y la exige el flujo de la P1 («Reintentar» y «Volver»). |
| N-18 | 8. Diseño minimalista | Partido | Diez controles en una pantalla. Supera el máximo de 3–4 acciones fijado en el sistema visual. | 1 | **No se cambia:** es una excepción razonada (D-05). Agruparlos en un menú costaría un toque más a Lucía. |
| N-19 | 2. Relación con el mundo real | Cuestionario | «Otra situación» asigna el perfil de baja visión sin explicarlo hasta el resumen. | 1 | **No se cambia:** el resumen lo explica y se puede personalizar. A validar con usuarios. |

Heurísticas sin problemas destacables: la 2 (lenguaje sin tecnicismos: «No encuentro tu accesorio», no «Bluetooth LE no disponible») y la 9 en los mensajes de error del formulario y de conexión.

### 1.2 Principios del Diseño Universal

| Principio | Valoración en la Iteración 1 | Problema |
|---|---|---|
| 1. Uso equitativo | Bien. Mismo flujo para los tres perfiles; el modo sin accesorio evita excluir a quien no lo tiene. | — |
| 2. Flexibilidad en el uso | Bien. Dos temas, tres tamaños de texto, tres niveles de narración, voz de la app opcional. | No recuerda el equipo (N-13). |
| 3. Uso simple e intuitivo | Regular. | Se puede empezar sin practicar (N-05). El botón de nivel no se entiende (N-14). |
| 4. Información perceptible | Bien. Cada evento llega por vibración, voz y texto. Estados con texto e icono. | El estado de pausa no es perceptible directamente (N-04). |
| 5. Tolerancia al error | Regular. Hay confirmaciones y «Volver». | El botón «atrás» del sistema (N-03) y la cercanía de «Finalizar sesión» (N-06). |
| 6. Bajo esfuerzo físico | Regular. | Los controles se mueven (N-01, N-02): obliga a mirar y recolocar el dedo. «Estado» queda arriba a la derecha, lejos del pulgar; se mantiene por consistencia. |
| 7. Tamaño y espacio para el uso | Bien. Todos los objetivos miden 48 px o más (medido), con 12 px de separación. | — |

### 1.3 Principios de usabilidad (Dix et al.)

| Principio | Aspecto | Valoración en la Iteración 1 |
|---|---|---|
| **Facilidad de aprendizaje** | Predictibilidad | Mala en Partido: los controles cambian de sitio (N-01, N-02). Buena en el resto: «Volver» y «Estado» siempre en el mismo lugar. |
| | Sintetizabilidad | Buena: cada acción se confirma con texto, voz y un toque de vibración. Falla con la cola de voz (N-07). |
| | Familiaridad | Buena: botones y opciones estándar, sin gestos propios. Falla el botón «atrás» (N-03). |
| | Consistencia | Buena: la acción principal va siempre la última. |
| **Flexibilidad** | Iniciativa del diálogo | Del usuario casi siempre. El sistema solo interrumpe por eventos y fallos. |
| | Multitarea | Se puede consultar el Estado o cambiar ajustes sin detener el seguimiento. |
| | Sustitutividad | Buena: cada evento tiene tres representaciones equivalentes. |
| | Adaptabilidad | Buena: perfil, entorno y ajustes. Falta recordar el equipo (N-13). |
| **Robustez** | Observabilidad | Regular: no se ve el estado de pausa (N-04) ni hay aviso de batería (N-11). |
| | Recuperabilidad | Buena en ajustes («Descartar») y conexión. Mala ante el botón «atrás» (N-03). |
| | Tiempo de respuesta | Bueno, salvo las confirmaciones en cola (N-07). |
| | Conformidad con la tarea | Buena para T1–T10. T5 depende del accesorio y solo se puede simular. |

### 1.4 WCAG 2.2 nivel AA

| Criterio | Resultado en la Iteración 1 | Cómo se ha comprobado |
|---|---|---|
| 1.3.1 Información y relaciones | Cumple | Revisión del marcado: `h1` único, `fieldset`, grupos etiquetados. |
| 1.4.1 Uso del color | Cumple | Estados con icono y texto; opción elegida con borde grueso y «Seleccionado». |
| 1.4.3 / 1.4.6 Contraste | Cumple (y alcanza AAA, 7:1) | Medido con la fórmula de WCAG: de 8,15:1 a 21:1. |
| 1.4.4 Cambio de tamaño del texto | Cumple | Texto en `rem`; probado al 200 %. |
| 1.4.10 Reajuste | **Cumple con una reserva** | Sin desplazamiento horizontal a 320 px. Con «Muy grande» y 200 % a la vez sí lo había. |
| 1.4.11 Contraste de elementos no textuales | Cumple | Bordes y foco con los mismos colores que el texto. |
| 2.1.1 Teclado | Cumple | Recorrido automático T1–T10 solo con teclado. |
| 2.2.1 Tiempo ajustable | **No cumple** | El aviso «Conexión recuperada» desaparecía a los 8 s (N-08). |
| 2.3.3 / animaciones | Cumple | Una sola animación, desactivada con `prefers-reduced-motion`. |
| 2.4.3 Orden del foco | Cumple | Orden registrado en Inicio, Vibración y narración y Partido. |
| 2.4.7 / 2.4.11 Foco visible y no oculto | Cumple | Contorno de 3–4 px; no hay elementos fijos que lo tapen. |
| 2.5.8 Tamaño del objetivo | Cumple | Medido: ningún objetivo por debajo de 48 × 48 px. |
| 3.2.2 Al introducir datos | Cumple | Elegir una opción no cambia de pantalla. |
| 3.2.3 Navegación coherente | **Cumple con una reserva** | Los controles de Partido se desplazaban (N-01, N-02). |
| 3.3.1 / 3.3.3 Errores | Cumple | Error en texto, asociado al grupo y con foco en él. |
| 3.3.7 Entrada redundante | **Mejorable** | El equipo se preguntaba cada vez (N-13). |
| 4.1.2 Nombre, función, valor | **Cumple con una reserva** | Doble anuncio en el interruptor (N-16). |
| 4.1.3 Mensajes de estado | Cumple | Regiones `aria-live` y `role="alert"`. |
| Alternativas de entrada | Parcial | Teclado y lector de pantalla. No hay control por voz ni con los botones físicos del móvil. |

**No comprobado:** el comportamiento real con VoiceOver y TalkBack. Los criterios que dependen de ello (1.3.1, 4.1.2, 4.1.3) están evaluados sobre el marcado, no sobre lo que se oye.

## 2. Iteración 2 — Cambios aplicados

| # | Antes (Iteración 1) | Después (Iteración 2) | Heurística o principio | Requisito |
|---|---|---|---|---|
| 1 | En Partido, «Último evento» y el estado de los datos estaban encima de los controles y los desplazaban. | Arriba solo quedan el marcador y el minuto. La información variable va debajo de los controles. | Nielsen 4 y 6 · Predictibilidad · DU 6 | R9.2.2 |
| 2 | El aviso de conexión aparecía encima de la pantalla y empujaba los controles. | Aparece debajo de la pantalla. Comprobado: «Repetir último evento» no se mueve al cortarse internet. | Nielsen 4 · Predictibilidad | R9.2.2, R9.5.2 |
| 3 | El botón «atrás» del móvil sacaba de la app. | Hace lo mismo que «Volver». En Partido abre «El partido sigue en juego. ¿Quieres salir?». | Nielsen 3 · Recuperabilidad · DU 5 | R9.2.3 |
| 4 | El estado de pausa solo se deducía del texto del botón. | Línea fija «⏸ Vibraciones en pausa. Narración en pausa». | Nielsen 1 · Observabilidad · DU 4 | R9.5.1 |
| 5 | Tras el primer emparejamiento se podía ir directo al partido. | Si nunca se ha practicado, la acción principal es «Practicar los patrones (recomendado)». Se puede saltar con «Elegir partido sin practicar». | Nielsen 10 · Facilidad de aprendizaje · DU 3 | R9.3.3, R9.3.2 |
| 6 | «Finalizar sesión» compartía fila con «Ajustes del partido». | Va sola, la última y separada. | Nielsen 5 · DU 5 | R9.2.3 |
| 7 | Las confirmaciones por voz esperaban a que acabase la narración. | La confirmación interrumpe la voz en curso. | Nielsen 1 · Tiempo de respuesta | R9.2.3 |
| 8 | «Conexión recuperada» se cerraba sola a los 8 s. | Permanece hasta que se pulsa «Cerrar aviso». | Nielsen 3 · WCAG 2.2.1 | R9.5.3 |
| 9 | Para recordar un patrón había que ir a Configuración. | «Recordar los patrones» en Ajustes del partido. | Nielsen 10 y 6 | R9.3.3 |
| 10 | Se podía responder en la práctica sin notar el patrón. | Aviso «Primero pulsa "Reproducir patrón"». | Nielsen 5 | R9.3.3 |
| 11 | La batería no cambiaba ni avisaba. | Baja durante el partido y, por debajo del 20 %, el móvil avisa con vibración, voz y texto. Botón «Batería baja» en el simulador. | Nielsen 1 · Observabilidad | R9.3.5, R9.5.1 |
| 12 | El modo beta se quedaba activado al volver a Inicio. | Se desactiva al volver a Inicio sin partido. | Nielsen 3 | R9.2.3 |
| 13 | «¿Con qué equipo vas?» siempre vacío. | Si el equipo de la última vez juega el partido, viene marcado. | Nielsen 7 · Adaptabilidad · WCAG 3.3.7 | R9.4.3, R9.2.1 |
| 14 | «Nivel de narración: normal», sin pista visible. | Añade «Pulsa para cambiar». | Nielsen 6 · DU 3 | R9.4.1 |
| 15 | «Todavía sin conexión.» | «Todavía sin conexión. Sigo intentándolo; te avisaré cuando vuelva.» | Nielsen 9 | R9.5.2 |
| 16 | El interruptor decía el estado dos veces. | El estado escrito es solo visual; el lector usa `aria-checked`. | Nielsen 4 · WCAG 4.1.2 | R9.1.1 |
| 17 | Filas de dos botones con rejilla fija; se desbordaban con el texto muy ampliado. | Filas flexibles que pasan a una columna cuando no caben. | WCAG 1.4.10 · DU 2 | R9.1.2 |

Cambios correspondientes en el diseño (para los mockups): en la pantalla Partido, el orden pasa a ser marcador → minuto → controles rápidos → último evento → estado de datos y pausas → «Ajustes del partido» → «Finalizar sesión» → aviso de conexión. En Conectar accesorio (primera vez), el botón principal es «Practicar los patrones (recomendado)».

### Problemas que quedan abiertos

| Id | Problema | Por qué no se ha resuelto |
|---|---|---|
| N-17 | Dos «Volver» en Conectar accesorio. | Decisión de diseño: redundancia útil. |
| N-18 | Diez controles en Partido. | Excepción razonada (D-05). A validar con usuarios. |
| N-19 | «Otra situación» en el cuestionario. | A validar con usuarios. |
| — | «Estado» queda lejos del pulgar. | Se prioriza la posición fija. A validar en la P3. |
| — | Sin prueba con VoiceOver ni TalkBack reales. | Requiere un móvil y una persona. **[PENDIENTE]** |
| — | Caso extremo de zoom: «Muy grande» + 200 % en 412 px. | Resuelto con el acabado visual (apartado 6): ya no hay desplazamiento horizontal en las pantallas medidas. |
| — | Alternativas de entrada (voz, botones físicos). | Fuera del alcance de la web del prototipo. |

## 3. Verificación tras la Iteración 2

Mismo recorrido automático con teclado (Chromium, 412 × 915 px), ampliado con las comprobaciones nuevas:

- **126 comprobaciones superadas, ninguna fallida.** Sin errores ni avisos en la consola, con servidor local y abriendo `index.html` directamente.
- Nuevas comprobaciones: los controles no se mueven al aparecer el aviso; el estado de pausa es visible; la práctica exige reproducir antes de responder; aviso de batería baja desde el móvil; el botón «atrás» vuelve en Ajustes y pide confirmación en Partido.
- Objetivos táctiles: ninguno por debajo de 48 × 48 px. Contrastes: sin cambios, todos por encima de 7:1.
- **No verificado:** lector de pantalla real, vibración y voz en un móvil físico, y rendimiento en un Android modesto. El prototipo pesa unos 114 KB, sin dependencias ni imágenes.

## 6. Acabado visual (después de la Iteración 2)

A petición del grupo se mejoró el aspecto del prototipo **sin tocar la estructura, los textos ni el orden de foco**. Capturas en `capturas/iter3`.

| Qué cambia | Por qué no reduce la accesibilidad |
|---|---|
| Tema estándar en verde césped (`#0B4A2D`) sobre fondo claro, con tarjetas blancas. | Contraste medido: texto 15,09:1, botón principal 10,34:1, error 7,48:1, foco 7,92:1. Todos por encima de 7:1. |
| Tablero destacado para el marcador y el minuto. | Mismo texto y misma posición. En alto contraste es negro con borde amarillo. |
| Iconos de línea en los botones. | Son pseudo-elementos decorativos: el lector de pantalla no los lee y el texto sigue presente. |
| Emblema y marca de la app. | Llevan `aria-hidden`, no son interactivos y no desplazan ningún botón. |
| Barra de progreso en el cuestionario. | Decorativa; el paso se lee en el título («Paso 1 de 3»). |
| Radios grandes dibujados a medida. | Siguen siendo `<input type="radio">` nativos. Con colores forzados por el sistema se usa el control nativo. |
| Tipografía Atkinson Hyperlegible incluida en el proyecto. | Diseñada para baja visión. Antes solo se veía si estaba instalada en el dispositivo. |
| Canto inferior en los botones, que bajan 2 px al pulsar. | No es una animación; con `prefers-reduced-motion` no hay movimiento. |

**Verificación:** el mismo recorrido con teclado, con 126 comprobaciones superadas y ninguna fallida, sin errores en la consola. Ningún objetivo táctil por debajo de 48 × 48 px. Sin desplazamiento horizontal al 200 % de zoom, ni con texto «Muy grande» y 200 % a la vez (el caso que quedaba abierto en la Iteración 2).

**No verificado:** cómo perciben el nuevo aspecto las personas con baja visión. **[PENDIENTE: opinión de usuarios sobre el tema estándar y el de alto contraste]**

## 4. Criterios de éxito de la P1

| Criterio de la P1 | Estado en la P2 | Qué falta |
|---|---|---|
| **Puesta en marcha autónoma en menos de 2 minutos** (uso habitual, D-04) | El diseño lo permite con **5 pulsaciones**: «Conectar accesorio» → «Usar mis ajustes y elegir partido» → partido → «Confirmar partido» (equipo ya marcado) → «Iniciar seguimiento» (entorno ya marcado). La búsqueda del accesorio se ha estimado en 10 s como máximo. | **No se ha medido con personas.** Con lector de pantalla hay más gestos por pantalla. Medir el tiempo real en la P3 con los tres perfiles. |
| **Reconocimiento de patrones superior al 95 %** | Es un **objetivo a validar en la P3**, no un resultado. El diseño lo favorece: ningún patrón es el principio de otro, hay práctica guiada con repetición de los fallados, «Pulsos reforzados» y repetición del último evento. | Prueba con usuarios: porcentaje de aciertos tras la práctica, por patrón y por perfil. Prestar atención a falta frente a córner y a gol frente a penalti. |
| **Control y retorno seguro** | Cumplido en el prototipo: «Volver» y «Estado» en posición fija, botón «atrás» del sistema, confirmación al salir sin guardar y al finalizar con el partido en juego, opción segura con el foco inicial, estado consultable en cualquier momento. | Comprobar con Manuel que entiende los diálogos de confirmación. |

## 5. Feedback recibido

No se ha inventado ninguna opinión. Rellenar con el feedback real.

### 5.1 Feedback del profesor
- Fecha: **[PENDIENTE]**
- Comentarios: **[PENDIENTE: feedback del profesor]**
- Cambios que provoca: **[PENDIENTE]**

### 5.2 Feedback de compañeros
- Fecha y quién: **[PENDIENTE]**
- Comentarios: **[PENDIENTE: feedback de compañeros]**
- Cambios que provoca: **[PENDIENTE]**

### 5.3 Prueba informal

| Dato | Valor |
|---|---|
| Fecha y lugar | **[PENDIENTE]** |
| Participante (perfil, sin datos personales) | **[PENDIENTE]** |
| Dispositivo y lector de pantalla | **[PENDIENTE]** |
| Tareas probadas (T1–T10) | **[PENDIENTE]** |
| Tiempo de puesta en marcha habitual | **[PENDIENTE]** |
| Aciertos en la práctica de patrones (X de 5) | **[PENDIENTE]** |
| Problemas observados | **[PENDIENTE: prueba informal]** |
| Cambios que provoca | **[PENDIENTE]** |

### 5.4 Cambios derivados del feedback (Iteración 2 bis)

| Feedback | Cambio aplicado | Heurística o principio | Requisito |
|---|---|---|---|
| **[PENDIENTE]** | **[PENDIENTE]** | **[PENDIENTE]** | **[PENDIENTE]** |
