# Sistema de patrones de vibración (referencia única)

Esta tabla es la que deben usar la memoria, los mockups y el código (`navigator.vibrate()`, valores en ms: vibra, pausa, vibra…).

**Reglas de diseño**
- Los patrones se distinguen por el **ritmo y la duración**, no por la intensidad. La API web no permite controlar la intensidad.
- **Ningún patrón es el principio de otro.** Los dos primeros pulsos ya identifican el evento (L = largo, C = corto, XL = muy largo).
- La repetición de un evento se anuncia siempre como **«Repetición: …»**. **El resumen nunca vibra.**
- **Pulsos reforzados** (para quien tiene poca sensibilidad táctil, como Manuel): los pulsos duran ×1,5 y las pausas no cambian.

| Evento | Patrón (ms) | Ritmo | Total | Con pulsos reforzados | Quién lo emite |
|---|---|---|---|---|---|
| Gol | `[600,150,600,150,600]` | L-L-L | 2,1 s | `[900,150,900,150,900]` | Accesorio (o móvil en beta) |
| Gol anulado | `[1200,200,150,100,150]` + voz «Gol anulado» | XL-C-C | 1,8 s | `[1800,200,225,100,225]` | Accesorio (o móvil en beta) |
| Falta | `[150,100,150]` | C-C | 0,4 s | `[225,100,225]` | Accesorio (o móvil en beta) |
| Córner | `[150,100,500]` | C-L | 0,75 s | `[225,100,750]` | Accesorio (o móvil en beta) |
| Penalti | `[500,150,150,150,500]` | L-C-L | 1,45 s | `[750,150,225,150,750]` | Accesorio (o móvil en beta) |
| Aviso técnico | `[80,80,80,80,80,80,80]` | 4 pulsos rápidos | 0,56 s | `[120,80,120,80,120,80,120]` | **Siempre el móvil**. Además el accesorio, solo si sigue conectado y lo que falla es internet |
| Confirmación de ajuste | `[60]` | 1 toque | 0,06 s | `[100]` | Móvil |

*Cambio respecto a la propuesta inicial:* el gol anulado era `[600,150,600]`, que coincide con el principio del patrón de gol. Se sustituye (ver decisión D-02 en `decisiones.md`).
