# Guion de prueba en un móvil real

Sirve para comprobar lo único que no se ha podido verificar desde el ordenador: cómo se usa el prototipo con un lector de pantalla y si las vibraciones se notan y se distinguen. Los resultados van a los apartados 15.4 y 18.6 de la memoria.

Duración: unos 25 minutos por persona. No hace falta el accesorio.

## 1. Preparación

1. En el ordenador: doble clic en `prototipo/iniciar-servidor.bat` y abrir el túnel al puerto 8080. Si el prototipo ya está publicado, usar la dirección pública.
2. En el móvil: abrir la dirección en **Chrome para Android**. En iPhone se puede probar todo menos la vibración.
3. Subir el volumen multimedia y quitar el modo silencio o «No molestar» (en algunos móviles bloquea la vibración).
4. En el simulador del final de la página, pulsar «Borrar perfil y reiniciar» antes de cada persona.

**Activar TalkBack (Android):** Ajustes → Accesibilidad → TalkBack. Gestos básicos: deslizar a la derecha o a la izquierda para moverse, doble toque para activar, deslizar con dos dedos para desplazar la pantalla.
**Activar VoiceOver (iPhone):** Ajustes → Accesibilidad → VoiceOver. Mismos gestos básicos.

## 2. Datos de la sesión

| Dato | Valor |
|---|---|
| Fecha | |
| Quién prueba (perfil, sin datos personales) | |
| Móvil y versión del sistema | |
| Navegador | |
| Lector de pantalla (TalkBack / VoiceOver / ninguno) | |
| Tema y tamaño de texto usados | |

## 3. Tareas

Leer la tarea en voz alta, no ayudar y anotar. «Hecho» es sí o no. En «Problemas» anotar lo que se ve y lo que la persona dice, sin interpretarlo.

| Nº | Tarea que se pide | Qué debe ocurrir | Hecho | Tiempo | Problemas observados |
|---|---|---|---|---|---|
| 1 | «Configura la app para ti.» (T1) | Tres preguntas, resumen y guardar. Llega a Inicio. | | | |
| 2 | En el paso 1, pulsar «Siguiente» sin elegir nada. | Se oye o se lee «Elige una opción para continuar» y el foco va a las opciones. | | | |
| 3 | «Conecta el accesorio.» (T2) | Buscar, elegir «Táctil 4F21», notar la vibración de prueba y confirmar. | | | |
| 4 | «Practica los patrones.» (T3) | Nota los cinco patrones y hace la práctica. Anotar el resultado: ___ de 5. | | | |
| 5 | Repetir la práctica con «Pulsos reforzados» activado. | Anotar el resultado: ___ de 5. | | | |
| 6 | «Empieza a seguir el Atlético – Betis desde un bar.» (T4) | Llega a Partido con el entorno correcto. | | | |
| 7 | Sin mirar la pantalla: «Dime qué ha pasado» en los tres primeros eventos. (T6) | Reconoce falta, córner y gol solo por la vibración. | | | |
| 8 | «Repite el último evento.» | Vuelve a vibrar y se oye «Repetición: …». | | | |
| 9 | «Pausa la narración sin mirar.» (T7) | Un toque; se confirma «Narración en pausa. Las vibraciones siguen activas». | | | |
| 10 | Esperar al minuto 46. «¿Hacia dónde ataca tu equipo?» (T5) | Responde «hacia la izquierda». | | | |
| 11 | Esperar al minuto 70 (corte de internet). «¿Qué ha pasado?» (T9) | Entiende que falla internet y no el accesorio. | | | |
| 12 | Esperar al minuto 72. «¿Cómo va el partido?» | Dice 1–1 y no cree que acaban de marcar. | | | |
| 13 | Pulsar el botón «atrás» del móvil durante el partido. | Sale la pregunta «El partido sigue en juego. ¿Quieres salir?». | | | |
| 14 | «Termina la sesión.» (T10) | Confirma y llega a «Sesión finalizada». | | | |
| 15 | Empezar de nuevo y elegir «Sevilla contra Valencia». (T8) | Escucha el resumen, distingue el resumen del directo y entra al partido. | | | |

Para no esperar, en el simulador se puede pulsar «Saltar al siguiente evento».

## 4. Mediciones para los criterios de la P1

| Medición | Cómo se mide | Resultado |
|---|---|---|
| Puesta en marcha habitual (objetivo: menos de 2 minutos) | Con el perfil ya guardado y el accesorio ya emparejado: cronometrar desde que se abre la app hasta que aparece la pantalla Partido. | |
| Reconocimiento de patrones (objetivo: más del 95 %) | Aciertos de las tareas 4, 5 y 7 sobre el total de patrones presentados. | |
| Patrones que se confunden | Anotar cada pareja confundida (p. ej. falta y córner). | |
| Control y retorno seguro | ¿Se ha perdido alguna vez o ha salido de la app sin querer? | |

## 5. Comprobaciones con el lector de pantalla

| Comprobación | Sí / No | Notas |
|---|---|---|
| Al cambiar de pantalla se anuncia el título. | | |
| Todos los botones se leen con un nombre comprensible. | | |
| Los iconos y la marca no se leen (son decorativos). | | |
| La opción elegida se anuncia como seleccionada. | | |
| Los avisos («Preferencias guardadas», «Volumen 3 de 5») se leen solos. | | |
| El aviso de «Sin conexión a internet» interrumpe y se lee al momento. | | |
| No se oyen dos voces a la vez (lector y narración). | | |
| El marcador no se lee solo cada minuto. | | |
| El simulador no interfiere mientras se usa la app. | | |

## 6. Comprobaciones sin lector de pantalla

| Comprobación | Sí / No | Notas |
|---|---|---|
| La vibración se nota con el móvil en la mano. | | |
| La vibración se nota con el móvil sobre la mesa. | | |
| La voz de la app lee las confirmaciones (si se contestó «No» al lector de pantalla). | | |
| Con el texto en «Muy grande» no hay que desplazarse en horizontal. | | |
| Los dos temas se leen bien con poca luz y con mucha luz. | | |
| La app va fluida: no se queda bloqueada al cambiar de pantalla. | | |

## 7. Después de la prueba

1. Pasar los problemas a la tabla del apartado 18.6 de la memoria (plantilla en `fase5.md`, apartado 5.3).
2. Si algún problema es de gravedad 3 o 4, corregirlo y anotarlo en la tabla «Cambios derivados del feedback».
3. Guardar una o dos fotos o capturas de la sesión, sin que se reconozca a la persona.
