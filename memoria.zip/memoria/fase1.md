# Fase 1 — Escenarios enriquecidos (T1–T10)

Los escenarios usan los perfiles de la P1 (Andrés, Lucía y Manuel), los nombres de tarea unificados en la Fase 0 y los patrones de `patrones.md`. Los datos del partido son simulados.

## Pantallas y botones a los que se refieren los escenarios

Este inventario es provisional y se detalla en `spec-pantallas.md` (Fase 2).

| Id | Pantalla | Botones y controles principales |
|---|---|---|
| P01 | Bienvenida | «Empezar» |
| P02 | Cuestionario inicial (3 preguntas) | opciones de respuesta, «Siguiente», «Atrás» |
| P03 | Perfil propuesto | «Aceptar perfil», «Personalizar», «Guardar preferencias», «Atrás» |
| P04 | Inicio | «Conectar accesorio», «Elegir partido», «Seguir solo con el móvil (beta)», «Estado del sistema», «Configuración» |
| P05 | Conectar accesorio | lista de accesorios, «Sí, la he notado», «No la he notado», «Reintentar», «Volver» |
| P06 | Vibración y narración | «Intensidad» (1–5), «Probar vibración», «Pulsos reforzados», «Volumen», «Nivel de narración» (Mínima / Normal / Detallada), «Practicar patrones», «Guardar ajustes» |
| P07 | Práctica de patrones | «Reproducir patrón», cinco respuestas (Gol, Gol anulado, Falta, Córner, Penalti), «Repetir los fallados», «Terminar» |
| P08 | Elegir partido | lista de partidos |
| P09 | Entorno y canales | «Estadio», «Casa», «Bar», «Ajustar», «Iniciar seguimiento» |
| P10 | Ponerse al día | «Escuchar resumen», «Omitir», «Escuchar alineaciones», «Ir al directo» |
| P11 | Partido | marcador y minuto, último evento, «Pausar vibraciones», «Pausar narración», «Volumen −» y «Volumen +», «Nivel de narración», «Repetir último evento», «Estado», «Ajustes del partido», «Finalizar sesión» |
| P12 | Ajustes del partido | entorno, intensidad, «Guardar y volver» |
| P13 | Estado del sistema | accesorio, batería, vibraciones, datos del partido, «Volver» |
| P14 | Aviso de conexión | «Reintentar», «Volver a conectar el accesorio», «Finalizar sesión» |
| P15 | Final del partido | «Escuchar resumen», «Omitir», «Finalizar sesión» |
| P16 | Sesión finalizada | «Volver al inicio» |
| P17 | Configuración | perfil, tema, tamaño de texto, «Repetir el cuestionario» |
| SIM | Simulador del accesorio | herramienta de prueba, no forma parte del producto |

---

## E1 · T1 Configurar el perfil inicial — Lucía

**Jueves, 22:40, en su habitación, con la luz apagada y en silencio.** Lucía acaba de instalar la app para el partido del sábado. De noche su retinosis le deja ver muy poco, así que ha activado TalkBack. Tiene el móvil con el texto al 200 % y alto contraste. Quiere dejar el perfil hecho sin pedir ayuda a su compañera de piso.

Abre la app y TalkBack lee: «Bienvenida. Vamos a adaptar la app a tu forma de ver. Son tres preguntas». Pulsa **«Empezar»**. En **Cuestionario inicial** escucha «Pregunta 1 de 3. ¿Cuál es tu grado de visión?» y elige «Baja visión». Pulsa **«Siguiente»**. En la segunda pregunta, «¿Dónde sueles seguir los partidos?», desliza demasiado rápido y marca «Estadio».

**Obstáculo.** Se da cuenta en la pantalla **Perfil propuesto**, que lee el resumen completo: «Perfil de baja visión. Lugar habitual: estadio. Lector de pantalla: a veces». Pulsa **«Atrás»**: la app vuelve a la pregunta 2 con las demás respuestas intactas. Cambia a «Bar» y regresa al resumen. Pulsa **«Aceptar perfil»** y luego **«Guardar preferencias»**. El móvil da un toque de confirmación y TalkBack anuncia: «Preferencias guardadas. Estás en Inicio».

Ningún texto se ha cortado al 200 % y no ha tenido que hacer zoom.

**Criterio de éxito:** perfil guardado en menos de 2 minutos, sin ayuda, corrigiendo un error sin volver a contestar las otras preguntas.

---

## E2 · T2 Emparejar y conectar el accesorio — Andrés

**Sábado, 20:45, en su asiento del estadio, quince minutos antes del inicio. Unos 85 dB de ambiente y megafonía.** Andrés lleva el accesorio sobre las rodillas y un auricular abierto en el oído derecho. Ya lo emparejó en casa. Hoy solo quiere conectarlo y tener el partido listo antes del saque inicial.

Abre la app. VoiceOver anuncia «Inicio. Accesorio sin conectar». Hace doble toque en **«Conectar accesorio»**. La pantalla **Conectar accesorio** dice «Buscando tu accesorio…» y, a los diez segundos: «No encuentro tu accesorio. Comprueba que está encendido y cerca del móvil».

**Obstáculo.** Con las prisas no lo había encendido. El mensaje no habla de Bluetooth ni de códigos de error y le ofrece dos botones: **«Reintentar»** y **«Volver»**. Enciende el accesorio y pulsa **«Reintentar»**. Esta vez el accesorio vibra una vez y VoiceOver lee «Accesorio conectado. Batería al 90 %». Como ya estaba emparejado, no tiene que elegirlo en la lista ni contestar a la vibración de prueba. La app no ha dicho «conectado» en ningún momento antes de que lo estuviera.

Vuelve a **Inicio**, donde el estado ha cambiado a «Accesorio conectado», y sigue con **«Elegir partido»**.

**Criterio de éxito:** accesorio conectado y partido en seguimiento en menos de 2 minutos desde que abre la app, sin ayuda de su amigo, incluido el reintento.

---

## E3 · T3 Calibrar y practicar los patrones — Manuel

**Domingo, 11:00, en el salón de su casa, con buena luz y la televisión apagada.** Su nieto le emparejó el accesorio ayer. Hoy Manuel quiere aprender las vibraciones él solo antes del partido de la tarde. Tiene menos sensibilidad en los dedos y teme «tocar algo y estropearlo».

En **Inicio** pulsa **«Configuración»** y después **«Vibración y narración»**. La pantalla tiene pocos controles y letra grande. Sube **«Intensidad»** a 4 y pulsa **«Probar vibración»**: la nota. Deja **«Nivel de narración»** en «Normal» y pulsa **«Practicar patrones»**.

En **Práctica de patrones** pulsa **«Reproducir patrón»**, nota la vibración y elige una de las cinco respuestas. Acierta el gol y el penalti, pero confunde la falta con el córner: las dos empiezan con un pulso corto que apenas percibe.

**Obstáculo.** Al terminar, la app dice en voz y texto: «3 de 5 aciertos. Has confundido falta y córner. Puedes activar Pulsos reforzados para notarlos mejor». Manuel vuelve atrás, activa **«Pulsos reforzados»** y pulsa **«Repetir los fallados»**. Ahora los pulsos duran más y distingue el final largo del córner. Resultado: «5 de 5 aciertos».

Pulsa **«Guardar ajustes»**. Antes ha intentado salir con «Atrás» y la app le ha preguntado: «Tienes cambios sin guardar. ¿Guardar o descartar?». Eso le tranquiliza: no ha perdido ni roto nada.

**Criterio de éxito:** al menos 4 de 5 aciertos en la segunda ronda y ajustes guardados sin ayuda en menos de 5 minutos.

---

## E4 · T4 Seleccionar partido y entorno — Lucía

**Sábado, 20:55, en un bar con luz tenue, reflejos en las mesas y unos 70 dB de conversación.** Lucía está con cuatro amigos. No tiene accesorio: quiere que el móvil, boca abajo en la mesa, le avise de los eventos que se le escapan en la tele. No quiere llamar la atención.

Abre la app con el tema de alto contraste. En **Inicio** pulsa **«Seguir solo con el móvil (beta)»**. Un texto breve le avisa: «Función en desarrollo. Notarás los eventos en el móvil. La posición del balón necesita el accesorio». Acepta y llega a **Elegir partido**. Cada partido es un botón grande con los dos equipos y la hora en texto. Elige el de las 21:00.

En **Entorno y canales** quiere pulsar «Bar», pero con el reflejo toca **«Casa»**.

**Obstáculo.** La app no avanza sola: muestra la propuesta para casa («Narración detallada, volumen medio») y Lucía ve que no es lo que quiere. La opción elegida se distingue por un borde grueso y el texto «Seleccionado», no solo por el color. Pulsa **«Bar»** y la propuesta cambia a «Narración mínima, volumen bajo, vibración en el móvil». Antes de empezar, la pantalla confirma «Vas a seguir: Atlético – Betis, hoy a las 21:00, en un bar». Pulsa **«Iniciar seguimiento»** y entra en **Partido**.

**Criterio de éxito:** partido en seguimiento en menos de 1 minuto, sin hacer zoom y con el entorno correcto tras corregir un toque equivocado.

---

## E5 · T5 Seguir la posición del balón — Andrés

**Sábado, 21:50, en el estadio, al empezar la segunda parte. Unos 95 dB, de noche.** Andrés ha seguido toda la primera parte con la mano izquierda sobre el accesorio. Sabía que su equipo atacaba hacia la derecha. Durante el descanso ha estado hablando con su amigo y ha quitado la mano.

La pantalla **Partido** no requiere que la mire ni que la toque. Cuando termina el descanso, el móvil da un toque de confirmación y la narración dice: «Empieza la segunda parte. Tu equipo ataca ahora hacia la izquierda». El mismo texto aparece en la zona de último aviso de la pantalla.

Andrés coloca la mano, localiza el centro del campo y las dos áreas por su relieve, y sigue con el dedo el punto táctil que marca el balón.

**Obstáculo.** Con el ruido del estadio no ha oído el aviso y, durante el primer minuto, cree que su equipo está defendiendo cuando en realidad ataca. Duda, saca el móvil y hace doble toque en **«Repetir último evento»**. La app responde: «Repetición: empieza la segunda parte. Tu equipo ataca ahora hacia la izquierda». Recoloca su mapa mental y sigue. Además, como el balón estuvo parado quince minutos, el aviso de inicio le confirma que el sistema no se había quedado colgado.

**Criterio de éxito:** tras el descanso, Andrés dice correctamente hacia qué lado ataca su equipo antes de que pase el minuto 47, con una sola consulta a la app como máximo.

---

## E6 · T6 Identificar un evento — Andrés

**Sábado, 22:10, en el estadio, minuto 63. Más de 95 dB: la grada está cantando.** Andrés sigue el balón con una mano. El auricular abierto apenas se oye con el ruido. Quiere enterarse de las jugadas al mismo tiempo que el resto de la grada.

El balón sale por la línea de fondo. El accesorio vibra corto y luego largo. Andrés reconoce el **córner** por el patrón, sin oír nada: es el único que empieza corto y acaba largo. La narración añade «Córner para el Atlético», pero el ruido la tapa. No la necesita.

Tres minutos después nota tres pulsos largos: **gol**. La grada estalla. Un minuto más tarde llega un pulso muy largo seguido de dos cortos.

**Obstáculo.** No está seguro: es el patrón que menos ha practicado. Hace doble toque en **«Repetir último evento»**, que está siempre en el mismo sitio de la pantalla **Partido**. El accesorio repite el patrón y la narración dice: «Repetición: gol anulado al Atlético por fuera de juego». La palabra «Repetición» le deja claro que no es una jugada nueva. El marcador en pantalla vuelve a 0-0 y el último evento muestra «Gol anulado», en texto.

**Criterio de éxito:** identifica el córner y el gol a la primera y solo por la vibración. Resuelve la duda del gol anulado con una única repetición, en menos de 10 segundos.

---

## E7 · T7 Realizar ajustes rápidos — Lucía

**Sábado, 21:25, en el bar, minuto 25. Luz tenue y unos 75 dB.** Lucía sigue el partido en la tele y lleva un solo auricular. Una amiga empieza a contarle algo importante y la narración se le mezcla con la conversación.

Mira el móvil. En la pantalla **Partido** los controles son botones grandes, con texto y siempre en el mismo orden. Con el pulgar pulsa **«Pausar narración»**. El móvil da un toque corto y el botón cambia a «Reanudar narración». Debajo aparece: «Narración en pausa. Las vibraciones siguen activas». Ha sido un solo toque y no ha tenido que abrir ningún menú.

**Obstáculo.** Diez minutos después quiere reanudarla, pero pulsa sin mirar el botón de al lado, **«Pausar vibraciones»**. La app lo confirma con voz y texto: «Vibraciones en pausa». Lucía no lo oye porque el volumen está bajo. Cuando llega una falta, el móvil no vibra, pero la pantalla muestra «Falta del Betis. Vibraciones en pausa» y lo dice por el auricular. Lucía entiende lo que ha pasado, pulsa **«Reanudar vibraciones»** y luego **«Reanudar narración»**. Para no molestar, baja un punto con **«Volumen −»** y la app confirma «Volumen 3 de 5».

**Criterio de éxito:** pausa la narración con un toque y en menos de 3 segundos. Detecta y corrige la pausa accidental de las vibraciones en el siguiente evento.

---

## E8 · T8 Ponerse al día en un partido empezado — Manuel

**Domingo, 18:35, en el sofá de su casa, con la televisión encendida a volumen medio.** La siesta se ha alargado y el partido empezó a las 18:00. Manuel no distingue el balón ni el marcador de la tele. Quiere saber cómo van antes de seguir el directo.

Conecta el accesorio, pulsa **«Elegir partido»** y elige el suyo. La app le avisa: «El partido ya ha empezado. Minuto 34». Llega a la pantalla **Ponerse al día**, con cuatro botones grandes. Pulsa **«Escuchar resumen»**.

La voz empieza: «Resumen. Minuto 12, gol de Griezmann, uno a cero…». El accesorio no vibra: el resumen nunca vibra, así que Manuel no lo confunde con algo que esté pasando ahora.

**Obstáculo.** A mitad del resumen hay una falta en el directo. El resumen se corta, el accesorio vibra con dos pulsos cortos y la voz dice «En directo: falta del Betis». Después la app pregunta: «¿Seguir con el resumen o ir al directo?». Manuel pulsa **«Escuchar resumen»** y continúa donde lo dejó. Luego pulsa **«Escuchar alineaciones»**, se cansa a la mitad y pulsa **«Ir al directo»**. Entra en **Partido**, donde lee en letra grande «Atlético 1 – Betis 0. Minuto 37».

**Criterio de éxito:** en menos de 90 segundos sabe el marcador y quién ha marcado, y no confunde el resumen con el directo.

---

## E9 · T9 Consultar el estado y recuperar la conexión — Andrés

**Sábado, 22:20, en el estadio, minuto 70. Hay 60 000 personas y la red móvil está saturada.** Andrés nota que el balón lleva un rato quieto en el centro del campo, pero la grada grita como si hubiera una ocasión. Duda si el sistema sigue funcionando.

No le hace falta consultarlo: el **móvil** vibra en el bolsillo con cuatro pulsos rápidos, distintos de cualquier evento del partido. Como el accesorio sigue conectado, repite el mismo aviso. La voz dice: «Sin conexión a internet. Los datos del partido no se están actualizando. Intentando reconectar».

Saca el móvil. VoiceOver lee el **Aviso de conexión**: «Falla internet. El accesorio sigue conectado», con los botones **«Reintentar»** y **«Finalizar sesión»**. La pantalla **Partido** marca los datos como «Sin actualizar desde el minuto 70».

**Obstáculo.** Pulsa **«Reintentar»** y falla: «Todavía sin conexión». No pierde el partido elegido ni sus ajustes. Abre **«Estado»** y confirma: accesorio conectado, batería 62 %, vibraciones activas, datos del partido detenidos. Espera. A los dos minutos la app reconecta sola y anuncia una sola vez: «Conexión recuperada. Marcador: uno a uno, minuto 72». No reproduce el patrón del gol que se perdió, así que no cree que acaban de marcar.

**Criterio de éxito:** sabe en menos de 10 segundos que el fallo es de internet y no del accesorio. Tras la reconexión conoce el marcador real sin recibir avisos atrasados.

---

## E10 · T10 Finalizar: resumen y desconexión — Manuel

**Domingo, 19:50, en el salón de su casa. Su hija ha llegado y están hablando.** Es el minuto 88. Manuel quiere bajar el volumen para oír a su hija, pero su visión central no le deja ver bien dónde toca.

**Obstáculo.** Pulsa **«Finalizar sesión»** por error. La app no cierra nada. Muestra dos botones grandes y dice: «El partido sigue en juego. ¿Quieres salir?». Las opciones son **«Seguir viendo el partido»** y **«Finalizar sesión»**. Manuel pulsa la primera y vuelve a **Partido** tal como estaba. No ha estropeado nada.

Tras el pitido final, el accesorio no vibra y la voz anuncia: «Final del partido. Atlético 2 – Betis 1». La pantalla **Final del partido** ofrece **«Escuchar resumen»** y **«Omitir»**. Manuel escucha el resumen, que empieza por «Resumen» y no vibra, y lo comenta con su hija.

Después pulsa **«Finalizar sesión»**. Esta vez la app pide una confirmación sencilla y cierra. En **Sesión finalizada** lee y escucha: «Sesión cerrada. El accesorio está desconectado; recuerda apagarlo. Tus ajustes quedan guardados para el próximo partido». Pulsa **«Volver al inicio»**.

**Criterio de éxito:** cierra la sesión sin ayuda, sin salir del partido por accidente, y sabe que sus ajustes se han guardado.

---

## Tabla de trazabilidad

| Escenario | Tarea | Perfil | Requisitos R9.x | Pantallas |
|---|---|---|---|---|
| E1 | T1 Configurar el perfil inicial | Lucía (TalkBack, texto al 200 %) | 9.1.1, 9.1.2, 9.1.4, 9.2.3, 9.4.3 | P01, P02, P03, P04 |
| E2 | T2 Emparejar y conectar el accesorio | Andrés (VoiceOver, estadio) | 9.1.1, 9.1.3, 9.2.1, 9.2.3, 9.5.1 | P04, P05 |
| E3 | T3 Calibrar y practicar los patrones | Manuel (sin lector, casa) | 9.3.2, 9.3.3, 9.4.1, 9.2.3, 9.4.3 | P04, P17, P06, P07 |
| E4 | T4 Seleccionar partido y entorno | Lucía (alto contraste, bar) | 9.1.2, 9.4.2, 9.2.1, 9.2.3 | P04, P08, P09, P11 |
| E5 | T5 Seguir la posición del balón | Andrés (estadio) | 9.3.1, 9.2.2, 9.5.4 | P11, SIM |
| E6 | T6 Identificar un evento | Andrés (estadio) | 9.3.1, 9.3.2, 9.5.4, 9.1.3 | P11, SIM |
| E7 | T7 Realizar ajustes rápidos | Lucía (bar) | 9.2.2, 9.2.4, 9.4.1, 9.6.1, 9.1.2 | P11 |
| E8 | T8 Ponerse al día en un partido empezado | Manuel (casa) | 9.3.1, 9.2.3, 9.2.4 | P08, P10, P11 |
| E9 | T9 Consultar el estado y recuperar la conexión | Andrés (estadio) | 9.5.1, 9.5.2, 9.5.3, 9.3.2 | P11, P14, P13 |
| E10 | T10 Finalizar: resumen y desconexión | Manuel (casa) | 9.2.3, 9.4.3, 9.1.2 | P11, P15, P16 |

**Cobertura:** las diez tareas tienen escenario; cada perfil aparece al menos en tres. Los requisitos 9.3.4 (latencia), 9.3.5 (batería) y 9.7.1 (validación) no se pueden demostrar en un escenario narrativo: se tratan en el prototipo y en el análisis.
