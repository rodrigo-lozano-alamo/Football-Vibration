# Guía técnica: lo que falta y cómo hacerlo

Pasos para cerrar la parte técnica de la Práctica 2. Lo que ya está hecho se indica como tal.

## 1. Publicar el prototipo con un enlace público (GitHub Pages)

Sirve para tener una dirección fija que abrir en el móvil y que poner en la memoria. **No sustituye** al prototipo de Figma o Stitch que pide el enunciado, pero lo complementa y permite evaluarlo sin instalar nada.

Ya está preparado: en la raíz del repositorio hay un `index.html` que lleva a `prototipo/`.

1. Subir los cambios pendientes: `git add -A`, `git commit -m "Publicación del prototipo"`, `git push`.
2. En GitHub: repositorio **Football-Vibration** → *Settings* → *Pages*.
3. En *Build and deployment*: *Source* = «Deploy from a branch», *Branch* = `main`, carpeta `/ (root)`. Guardar.
4. Esperar uno o dos minutos. La dirección será `https://rodrigo-lozano-alamo.github.io/Football-Vibration/`.
5. Abrirla en el móvil y comprobar que carga el prototipo.

A tener en cuenta:

- GitHub Pages en cuentas gratuitas exige que el repositorio sea **público**. Todo lo que hay en el repositorio quedará visible, incluido `memoria.zip` y la carpeta `Docuementacion` con la memoria de la P1 (aparecen los nombres del grupo). Si no queréis eso, sacad esos archivos del repositorio antes de hacerlo público.
- Alternativa sin publicar nada: el servidor local y el túnel (`prototipo/README.md`). La dirección cambia cada vez y solo funciona con el ordenador encendido.

## 2. Prototipo navegable en Figma (cuando estén los mockups)

1. Importar en Figma las pantallas generadas en Stitch (exportar a Figma o pegar las imágenes, una por *frame* de 412 × 915).
2. Nombrar cada *frame* con el identificador de la especificación: «P04 Inicio», «P11 Partido»…
3. En la pestaña *Prototype*, enlazar los botones siguiendo la tabla «Mapa de navegación» (apartado 14.2 de la memoria). Interacción *On tap* → *Navigate to*, animación *Instant* (sin transiciones decorativas).
4. Recorridos mínimos que deben funcionar:
   - Primer acceso: P01 → P02 (tres pasos) → P03 → P04.
   - Uso habitual: P04 → P05 → P08 → P09 → P11.
   - Partido empezado: P09 → P10 → P11.
   - Fallo y recuperación: P11 → P11 con aviso → P11 con «Conexión recuperada».
   - Cierre: P11 → diálogo → P15 → P16 → P04.
5. Feedback mínimo: usar las variantes de estado como pantallas aparte (error del cuestionario, «Narración en pausa», «Accesorio conectado»).
6. *Share* → «Anyone with the link can view» → copiar el enlace del prototipo (botón *Present*) y pegarlo en el apartado 14.1 de la memoria.
7. Hacer capturas de cuatro o cinco pantallas del prototipo para el apartado 14.3.

Recordatorio: Partido, Aviso de conexión y Conectar accesorio deben seguir el diseño de la Iteración 2 y la paleta verde (apartados 8 y 9 de `spec-pantallas.md`).

## 3. Ejemplo con GitHub Copilot

El enunciado cita Copilot, Cursor y ChatGPT. El código se generó con Claude Code, que también es IA generativa. Si queréis cubriros, añadid un ejemplo pequeño hecho con Copilot. Propuesta de tarea real y acotada:

**Tarea:** que la pantalla «Practicar patrones» muestre también cuánto dura cada patrón («Gol: 2,1 segundos»).

1. Abrir `prototipo/js/patrones.js` en VS Code.
2. En Copilot Chat, pegar este prompt:

```
En este archivo hay una tabla FV.PATRONES donde cada patrón tiene "ms": un array para
navigator.vibrate() (vibra, pausa, vibra…). Escribe una función FV.duracionPatron(clave)
que devuelva la duración total en segundos como texto en español, con una coma decimal y
un decimal como máximo (por ejemplo "2,1 segundos" o "0,4 segundos"). Debe usar
FV.patronMs(clave) para tener en cuenta los pulsos reforzados. JavaScript sin dependencias
y con el mismo estilo del archivo (var, funciones clásicas, comentarios en español).
```

3. Revisar lo que propone: que use `FV.patronMs`, que sume todos los valores y que el texto salga con coma.
4. Usarla en `prototipo/js/pantallas-accesorio.js`, en la lista de «Notar el patrón de…», dentro de la etiqueta `<small>`.
5. Anotar en la fila 9 de la tabla de IA (apartado 16 de la memoria): el prompt, el código que devolvió y **lo que cambiasteis a mano y por qué**.

Esa última columna es la que más valora el criterio 4: no basta con pegar el código.

## 4. Rendimiento (hecho)

Medido en Chromium simulando un móvil modesto: procesador 6 veces más lento y red 3G rápida. **Es una simulación, no un móvil real**, y las cifras varían de una ejecución a otra.

| Medida | Resultado |
|---|---|
| Peso total transferido | 167 KB en 15 peticiones (incluye las dos fuentes, 35 KB) |
| Primer contenido en pantalla | 1,0 s |
| Página cargada | 1,6 s |
| Elementos en la página | 90 |
| Memoria usada por el código | 5 MB |
| Cambio de pantalla | entre 0,2 y 0,5 s |
| Avance de un minuto de partido | 0,08 s de media; hasta 0,4 s cuando hay evento con voz y vibración |
| Cambio de tema y tamaño de texto | entre 1 y 2 s (ocurre una sola vez, en Configuración) |
| Desplazamiento de contenido durante la carga | ninguno |

Valoración:

- La carga es ligera: no hay imágenes, librerías ni peticiones a servidores externos.
- Con el procesador frenado, los cambios de pantalla tardan entre dos y cinco décimas. Es aceptable, pero conviene comprobarlo en un Android de gama baja (está en el guion de prueba).
- Se probó a quitar iconos, sombras y selectores costosos para buscar un cuello de botella y **ninguno destacó**, así que no se ha optimizado nada a ciegas.
- Durante el partido, el texto de «Último evento» cambia de tamaño y desplaza lo que tiene debajo («Ajustes del partido» y «Finalizar sesión»). Los controles rápidos, que están encima, no se mueven. Es una consecuencia asumida de la Iteración 2.

## 5. Revisión de código (hecha)

Revisión propia sobre el código del prototipo, tras el recorrido automático (126 comprobaciones, ninguna fallida).

**Corregido en esta revisión**

| Problema | Corrección |
|---|---|
| Si el partido terminaba con un diálogo abierto, el diálogo quedaba encima de la pantalla «Final del partido». | Al cambiar de pantalla se cierra cualquier diálogo abierto (`js/app.js`). |
| El nombre del accesorio y el resultado de la práctica se leían de `localStorage` y se insertaban como HTML sin escapar. | Se escapan con `FV.escapar` antes de insertarlos. Comprobado con un valor malicioso: se muestra como texto. |

**Conocido y sin corregir** (no afecta a la entrega)

| Punto | Por qué se deja |
|---|---|
| La pantalla «Estado del sistema» no se actualiza sola mientras está abierta. | Actualizarla quitaría el foco al lector de pantalla. Se refresca al volver a entrar. |
| Si la app cambia de pantalla por su cuenta mientras se editan los ajustes, los cambios sin guardar se quedan aplicados. | Caso raro (solo al acabar el partido). |
| «Borrar perfil y reiniciar» del simulador no pide confirmación. | Es una herramienta de prueba, no parte de la app. |
| «Reintentar» nunca recupera la conexión por sí mismo. | La conexión es simulada: vuelve con el guion del partido o desde el simulador. |
| Las pantallas se construyen concatenando texto HTML. | Suficiente para un prototipo; en un desarrollo real se usarían componentes. |
| No hay pruebas automáticas dentro del repositorio. | El guion de pruebas se ejecutó desde fuera. Sería el primer paso de un desarrollo real. |

**Lo que está bien resuelto:** sin dependencias externas, sin variables globales fuera de `FV`, acceso a `localStorage` protegido, comprobación de compatibilidad de voz y vibración, y comentarios que explican las decisiones de accesibilidad.

## 6. Pasar la memoria a Word y a PDF accesible

`memoria-P2.html` es la memoria de la P2 lista para abrir en Word: títulos reales (`h1` a `h4`), 24 tablas con fila de encabezado, las 10 capturas con su texto alternativo e idioma español. Los prompts en inglés están marcados como tales.

No se ha podido generar el `.docx` directamente: en este equipo no hay conversor instalado. El paso por Word es manual y corto:

1. Abrir Word → *Archivo → Abrir* → `memoria/memoria-P2.html`. (No mover el archivo: las imágenes están en `capturas/iter3`.)
2. *Archivo → Guardar como* → tipo **Documento de Word (.docx)**.
3. *Archivo → Información → Editar vínculos a archivos* → seleccionar todas las imágenes → «Guardar imagen en el documento» y **Romper vínculo**. Así las imágenes quedan dentro del `.docx`.
4. Comprobar que los títulos han entrado como *Título 1*, *Título 2*… (panel de navegación: *Vista → Panel de navegación*) y aplicar el tema o la plantilla de la P1.
5. En cada tabla: *Diseño de tabla → Repetir filas de título* y casilla «Fila de encabezado».
6. Unirla con la memoria de la P1: pegar los apartados 10 a 19 a continuación del 9 y aplicar al texto de la P1 las correcciones de `fase0.md`.
7. Sustituir los `[PENDIENTE]` y los `[CAPTURA]`.
8. Insertar el índice automático: *Referencias → Tabla de contenido*.
9. *Revisar → Comprobar accesibilidad* hasta que no queden errores.
10. Exportar: *Archivo → Guardar como → PDF → Opciones → «Etiquetas de la estructura del documento para accesibilidad»*. No usar «Imprimir a PDF».

Si después se cambia `memoria-P2.md`, el HTML no se actualiza solo; es más práctico seguir editando ya en Word.

`prueba-movil.html` es el guion de prueba en el mismo formato, por si se quiere imprimir.

## 7. Entrega

| Entregable del enunciado | Qué entregar |
|---|---|
| Memoria única en PDF accesible | El PDF exportado desde Word (P1 + P2). |
| Prototipo navegable con enlace público | Enlace de Figma o Stitch (apartado 2) y, como complemento, el de GitHub Pages (apartado 1). |
| Carpeta con el código funcional | `prototipo/` (versión final) y `prototipo-iteracion1/` (primera iteración). |

`memoria.zip` se ha regenerado con el contenido actual de la carpeta `memoria`.
