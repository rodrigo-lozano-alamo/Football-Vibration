# Fase 0 — Revisión de coherencia de la memoria de la Práctica 1

> Documento de trabajo de la Práctica 2. **No modifica la memoria de la P1**: recoge las incoherencias detectadas y el texto de corrección propuesto para usarlo como base de la P2.
> Las referencias de página son las del PDF `Docuementacion/Memoria_Practica_1_IPO.pdf`.

## A. Correcciones obligatorias del encargo

### 1. Tarea 6: el evento se reconoce por la vibración, no por la narración
- **Dónde:** §5, Tarea 6 (p. 13-14).
- **Problema:** la definición dice que el usuario reconoce el evento «mediante la narración y los efectos de sonido». Esto contradice los pasos de la propia tarea (primero se nota el patrón), el §2 (p. 4: «las vibraciones permiten distinguir los eventos [...] y el audio solo sirve como complemento»), el §3 (reparto de la carga sensorial) y R9.3.1/R9.3.2. Además, «efectos de sonido» no aparece en ningún otro apartado como canal.
- **Texto propuesto:**
  > **T6 – Identificar un evento (gol, gol anulado, falta, córner, penalti).** El usuario reconoce el acontecimiento **principalmente por su patrón de vibración**, que es único para cada evento. La narración (equipo y jugador) es complementaria: aporta el contexto, pero no hace falta para saber qué ha pasado. Si tiene dudas, puede pedir que se repita el último evento. Se realiza varias veces en cada partido.
  > **Precondiciones:** seguimiento activo y patrones practicados al menos una vez (T3).
  > **Pasos:** 1. Notar el patrón de vibración. 2. Reconocer el evento por el patrón. 3. Si la narración está activa, escuchar el complemento (equipo y jugador). 4. Si tiene dudas, pulsar «Repetir último evento».
  > **Errores y feedback:** la repetición reproduce otra vez el patrón y la narración, que empieza siempre por «Repetición:» para no confundirla con una jugada nueva. El gol anulado tiene su propio patrón y además el aviso de voz «Gol anulado». Si las vibraciones están en pausa, el evento se anuncia por voz y texto y se recuerda que la vibración está en pausa (coherente con T7).

### 2. R9.5.2: el aviso de desconexión sale del móvil
- **Dónde:** §9.5, R9.5.2 (p. 24) y también R9.3.2 (p. 23).
- **Problema:** R9.5.2 dice que la incidencia se notifica «mediante un patrón vibratorio específico», sin aclarar desde dónde. Contradice T9 (p. 15: «el aviso sale del móvil, porque un dispositivo desconectado no puede vibrar»), §7.6 y el storyboard de la Tarea 3. R9.3.2 pone «desconexión» como ejemplo de patrón del accesorio, lo cual es imposible.
- **Texto propuesto para R9.5.2:**
  > **9.5.2 Gestión proactiva de desconexiones.** Ante cualquier pérdida de conexión, el **móvil** avisa al momento con su propia vibración (patrón de aviso técnico), un mensaje de voz y un texto en pantalla, que se anuncia también al lector de pantalla. El aviso nunca depende del accesorio háptico. Solo cuando el accesorio sigue conectado y lo que falla es internet, el accesorio reproduce además el patrón de aviso técnico. Desde ese momento, los datos del partido se marcan como no actualizados y no se presentan como actuales.
- **Ajuste en R9.3.2:** cambiar «avisos del sistema (como fallos técnicos o desconexión)» por «avisos del sistema (como la pérdida de datos del partido), que el accesorio solo emite mientras sigue conectado; la desconexión del accesorio se avisa desde el móvil (R9.5.2)».

### 3. Nombre unificado de las tareas (T1 y el resto)
- **Dónde:** tabla §4.6 (p. 11) frente a los títulos de §5 (p. 12-15).
- **Problema:** las diez tareas tienen nombres distintos en la tabla y en el análisis. La T8, además, está redactada desde el punto de vista del sistema («Informar de lo sucedido») en lugar de desde el del usuario.

| Id | Tabla §4.6 | Título en §5 | **Nombre unificado propuesto** |
|---|---|---|---|
| T1 | Configurar el perfil inicial | Configurar la aplicación | **Configurar el perfil inicial** |
| T2 | Emparejar y conectar el dispositivo | Emparejar el dispositivo | **Emparejar y conectar el accesorio** |
| T3 | Calibrar y practicar patrones | Calibrar vibraciones y narración | **Calibrar y practicar los patrones** |
| T4 | Seleccionar partido y entorno | Seleccionar el partido y el lugar donde lo verá | **Seleccionar partido y entorno** |
| T5 | Seguir la posición del balón | (igual) | Seguir la posición del balón |
| T6 | Identificar un evento | (igual) | Identificar un evento |
| T7 | Realizar ajustes rápidos | (igual) | Realizar ajustes rápidos |
| T8 | Ponerse al día en un partido empezado | Informar de lo sucedido | **Ponerse al día en un partido empezado** |
| T9 | Consultar el estado y recuperar la conexión | Consultar el estado del sistema | **Consultar el estado y recuperar la conexión** |
| T10 | Finalizar: resumen y desconexión | (igual) | Finalizar: resumen y desconexión |

### 4. «autodescripción» → «audiodescripción»
- **Dónde:** §2, p. 4: «Una de las más famosas puede ser la ~~autodescripción~~ **audiodescripción**».

### 5. Marcador pendiente de la encuesta
- **Dónde:** §4.1, p. 8: «[encuesta: indicar número de respuestas y canal de difusión]».
- **Acción:** sustituir por **[PENDIENTE: nº respuestas y canal]**. No se inventan resultados. Mientras no haya datos, los perfiles se apoyan en los datos de la ONCE y del INE, y así se debe indicar.
- **Relacionado:** la numeración pasa de 4.1 a 4.3 sin 4.2. Seguramente la encuesta debería ser el apartado **4.2**.

## B. Otras incoherencias detectadas

### 6. Objetivo de «menos de 2 minutos»: qué incluye
- **Dónde:** §2 (p. 6: «configuración y enlace del sistema»), perfil de Andrés (p. 9: «sincronizar la Tablet háptica»), §6 Momentos de uso (p. 16: «enciende y **empareja** el dispositivo, **elige su perfil** y ajusta...»), R9.2.1 (p. 22: «conexión, **emparejamiento** y selección de partido»). En cambio, el §3 (tabla y «Puesta en marcha autónoma») habla de «conectar el accesorio **ya emparejado**» «en cada uso».
- **Problema:** el emparejamiento y el perfil se hacen una sola vez (T1, T2, storyboard p. 19). Si se incluyen el primer acceso y la práctica, el límite de 2 minutos no es realista.
- **Corrección:** fijar un único criterio: **uso habitual** (abrir la app → conectar el accesorio ya emparejado → elegir partido y entorno → iniciar seguimiento) **en menos de 2 minutos y sin ayuda**. El primer acceso (T1 + emparejamiento + práctica de T3) se mide aparte y no tiene ese límite. Hay que reescribir R9.2.1 y el párrafo «Antes del partido» del §6.

### 7. Criterio del 95 %: falta el penalti
- **Dónde:** §2, p. 6 («gol, falta, córner») frente a R9.3.2 («gol, falta, córner, penalti»).
- **Corrección:** usar los mismos eventos en todo el documento: gol, gol anulado, falta, córner y penalti.

### 8. Referencia cruzada errónea en el perfil de Manuel
- **Dónde:** p. 11: «intensidad de vibración ajustable (**R9.3.3**)».
- **Problema:** R9.3.3 es el módulo de aprendizaje. El ajuste de intensidad es **R9.4.1**.

### 9. Terminología del hardware sin unificar
- **Dónde:** se usan como sinónimos «dispositivo háptico», «accesorio háptico», «dispositivo táctil» y «Tablet háptica» (perfil de Andrés, p. 9).
- **Problema:** «Tablet háptica» describe una forma de hardware que **queda fuera del alcance**.
- **Corrección:** usar siempre **«accesorio háptico»** (o «el accesorio»), y «móvil» para el teléfono.

### 10. Contexto tecnológico que contradice a los perfiles
- **Dónde:** §6, p. 16: «Suponemos que el usuario tiene un móvil con lector de pantalla y que sabe manejarlo».
- **Problema:** Manuel no usa lector de pantalla y tiene poca experiencia. Lucía solo lo usa de noche.
- **Corrección:** «La app debe funcionar igual de bien con lector de pantalla (VoiceOver, TalkBack), respetando sus gestos, que sin él, con letra ampliada y alto contraste».

### 11. Tres perfiles de usuario frente a dos perfiles de la app
- **Dónde:** §4 (tres perfiles) frente a R9.1.4 y T1 (dos perfiles: ceguera total y baja visión).
- **Corrección:** aclarar que hay **3 personas** y **2 perfiles de accesibilidad**. Manuel parte del perfil de baja visión, sin lector de pantalla y con vibración reforzada (ver punto 18).

### 12. Precondición de T2 que contradice su primer paso
- **Dónde:** T2 (p. 12). La precondición dice «dispositivo encendido» y el paso 1 es «Encender el dispositivo».
- **Corrección:** quitar «dispositivo encendido» de las precondiciones.

### 13. Vibración de prueba: ¿siempre o solo la primera vez?
- **Dónde:** T2 («Nunca muestra conectado hasta que el usuario confirma la vibración de prueba») frente al storyboard de la Tarea 1, escena 2 (reconexión automática, sin prueba) y §7.2.
- **Corrección:** en el **emparejamiento inicial**, el usuario confirma la vibración de prueba. En las **conexiones posteriores**, la app confirma con el patrón de confirmación más voz y texto, sin pedir respuesta. Así se respeta el límite de 2 minutos.

### 14. Cambiar el entorno durante el partido
- **Dónde:** T4, Errores (p. 13): «puede cambiarlo desde los controles rápidos». Pero los controles rápidos de §7.4 y T7 no incluyen el entorno.
- **Corrección (recomendada):** el entorno se cambia desde «Ajustes del partido», accesible desde la pantalla de partido y separado de los controles rápidos (R9.2.4). Así los controles rápidos siguen teniendo pocas opciones, como necesita Manuel.

### 15. «Un toque» para la narración frente a «abrir controles rápidos»
- **Dónde:** criterio de éxito de Lucía (p. 10: «activar o pausar la narración en un toque») frente a T7, paso 1 («Abrir los controles rápidos»), que exige al menos dos toques.
- **Corrección:** «Pausar narración» y «Pausar vibraciones» están siempre visibles en la pantalla de partido y se activan con un solo toque. Volumen y nivel de narración están en el mismo bloque fijo, sin menú intermedio.

### 16. «Repetir último evento»: qué se repite
- **Dónde:** storyboard Tarea 2, escena 3 (p. 20: «repite la descripción») frente a T6 (repite el evento para resolver dudas sobre el patrón).
- **Corrección:** la repetición reproduce **el patrón y la narración**, que empieza por «Repetición:». Si no hay eventos todavía: «Aún no hay ningún evento» (§7.4).

### 17. T5: la posición del balón se describe como «vibración»
- **Dónde:** T5, paso 3 (p. 13): «Seguir con el dedo la vibración del dispositivo».
- **Problema:** choca con el reparto de canales de R9.3.1 (táctil = posición; vibración = eventos). Si la posición también se transmite con vibración, puede confundirse con los patrones de eventos.
- **Corrección:** «Seguir con el dedo el **punto táctil** que marca la posición del balón». Como no diseñamos el hardware, la app se limita a orientar al usuario (dirección de ataque, cambio de campo en el descanso). En el prototipo, la posición se muestra en el **Simulador del accesorio**.

### 18. Sistema de patrones: un patrón es prefijo de otro y no existe «intensidad» en la web
- **Dónde:** P1 (T6: «un gol anulado tiene su propio aviso») frente a la tabla de patrones de partida de la P2.
- **Problemas:**
  1. Gol anulado `[600,150,600]` es **el principio exacto** del gol `[600,150,600,150,600]`. Para distinguirlos hay que notar que «falta» el tercer pulso, algo difícil para Manuel y que obliga a esperar.
  2. `navigator.vibrate()` no permite regular la intensidad, solo la duración. La «intensidad» de R9.4.1 debe simularse alargando los pulsos.
  3. Confirmación `[60]` y aviso técnico (pulsos de 80 ms) pueden no notarse con poca sensibilidad táctil.
  4. `navigator.vibrate()` no funciona en iOS (Safari). En iPhone (Andrés, con VoiceOver), el simulador solo mostrará el registro textual.
- **Ajustes propuestos (para confirmar en la Fase 1):**
  - Gol anulado → `[1200,200,150,100,150]` (muy larga, corta, corta) + voz «Gol anulado». Así ningún patrón es prefijo de otro y los dos primeros pulsos ya identifican el evento: gol L-L-L, penalti L-C-L, gol anulado XL-C-C, falta C-C, córner C-L.
  - Nivel «Refuerzo» de intensidad (perfil de Manuel): multiplicar ×1,5 la duración de los pulsos sin cambiar las pausas, y elevar la confirmación a `[100]`.

### 19. T3: la práctica no sirve para «mejorar la narración»
- **Dónde:** T3, paso 3 (p. 13): «Esto nos ayuda a recibir feedback y mejorar la narración de eventos».
- **Corrección:** «La práctica sirve para que el usuario aprenda a distinguir los patrones (R9.3.3). El resultado se anuncia por voz y texto («4 de 5 aciertos») y se pueden repetir los patrones fallados». El total pasa de 4 a 5 al añadir el gol anulado.

### 20. Reconexión: qué pasa con los eventos ocurridos durante el corte
- **Dónde:** T9 y R9.5.3 («no reproduce avisos acumulados»).
- **Hueco:** si hay un gol durante el corte, el usuario no se entera.
- **Corrección:** al reconectar no se reproducen patrones atrasados, pero se anuncia una sola vez el estado actual: «Conexión recuperada. Marcador: 1-0, minuto 63».

### 21. Precondiciones que faltan
- **Dónde:** T7, T8 y T10 están incompletas: T7 y T8 no tienen precondiciones.
- **Corrección:** T7 → «seguimiento activo». T8 → «partido ya empezado al iniciar el seguimiento».

### 22. Storyboards: numeración confusa y T1 sin storyboard
- **Dónde:** §8. Los storyboards se llaman «Tarea 1…4», pero no corresponden a T1…T4 (el «Storyboard Tarea 1» cubre T2+T3+T4).
- **Corrección:** renombrarlos a **Escenario A–D** e indicar las tareas que cubre cada uno: A → T2, T3, T4, T5. B → T5, T6, T7. C → T9. D → T10. El §8 dice distinguir el primer acceso, pero T1 (crítica para los tres perfiles) solo aparece en una nota. Se propone añadir un escenario de primer acceso en la P2.

### 23. ¿Seguir sin accesorio? (decisión del equipo)
- **Dónde:** tabla §4.6 (T2 solo es «relevante» para Lucía) frente a la precondición de T4 («dispositivo conectado»).
- **Pregunta:** ¿Lucía puede seguir el partido solo con el móvil?
- **Propuesta:** permitir «Seguir sin accesorio»: los eventos vibran en el móvil y se mantiene la narración, pero no hay posición táctil del balón. Hay que confirmarlo antes de la Fase 2.

### 24. Erratas y formato
- Índice: falta **9.1 Requisitos de accesibilidad** y no aparece 4.2.
- §2, p. 4: el párrafo «Dejar claro también...» está fuera de lugar (corta el razonamiento entre el párrafo anterior y «Esto supone una barrera»). Además, «permiten» → «**permitan**».
- Ortografía: «lo vera» → «lo verá»; «donde este» → «donde esté»; «boton» → «botón»; «asi» → «así»; «Lucia» → «Lucía»; «está discapacidad» → «esta discapacidad»; «criterios de éxitos» → «criterios de éxito»; «futbol» → «fútbol»; «Calibrar Vibraciones» → «Calibrar vibraciones».

## C. Trazabilidad que conviene añadir en la P2
- Matriz **Tarea ↔ requisitos R9.x**: ahora solo los perfiles citan requisitos; las tareas no.
- Nuevo requisito de prototipo: el **Simulador del accesorio** es una herramienta de prueba, no forma parte del producto y está fuera del alcance funcional (R9.7.1).
